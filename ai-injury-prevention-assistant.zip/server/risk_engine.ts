// Rule-based Injury Risk Estimation Engine
// Implements Module 7 scoring rules and logic

import { WorkoutHistory, PainReport, FitnessProfile, RiskAssessment } from '../src/types.js';

export function calculateInjuryRisk(
  workouts: WorkoutHistory[],
  painReports: PainReport[],
  profile: FitnessProfile | null
): RiskAssessment {
  let score = 0;
  const factors: { factor: string; scoreContribution: number }[] = [];

  // 1. Pain Level Contribution
  if (painReports.length > 0) {
    const latestPain = painReports[0]; // Sorted by date desc
    const daysSincePain = (Date.now() - new Date(latestPain.ReportDate).getTime()) / (1000 * 60 * 60 * 24);
    
    // Only count pain reports from the last 7 days as active indicators
    if (daysSincePain <= 7) {
      const painScore = latestPain.PainLevel * 1.5;
      score += painScore;
      factors.push({
        factor: `Active ${latestPain.BodyPart} Pain (Level ${latestPain.PainLevel}/10)`,
        scoreContribution: Math.round(painScore * 10) / 10
      });

      // Sharp or burning pain represents higher tissue/nerve warning
      if (latestPain.PainType.toLowerCase().includes('sharp') || latestPain.PainType.toLowerCase().includes('burn')) {
        score += 3;
        factors.push({
          factor: `High-Risk Pain Type (${latestPain.PainType})`,
          scoreContribution: 3
        });
      }
    }
  }

  // 2. Workout Frequency (Sessions in last 7 days)
  const oneWeekAgo = new Date();
  oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
  const recentWorkouts = workouts.filter(w => new Date(w.WorkoutDate) >= oneWeekAgo);
  const frequency = recentWorkouts.length;

  if (frequency > 5) {
    score += 5;
    factors.push({
      factor: `Overtraining Frequency (${frequency} workouts/week)`,
      scoreContribution: 5
    });
  } else if (frequency >= 4) {
    score += 2;
    factors.push({
      factor: `High Training Frequency (${frequency} workouts/week)`,
      scoreContribution: 2
    });
  }

  // 3. Sudden Training Volume Spike (Last 3 days vs Previous 4 days)
  const threeDaysAgo = new Date();
  threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);

  const last3DaysWorkouts = recentWorkouts.filter(w => new Date(w.WorkoutDate) >= threeDaysAgo);
  const prev4DaysWorkouts = recentWorkouts.filter(w => new Date(w.WorkoutDate) < threeDaysAgo);

  const volLast3 = last3DaysWorkouts.reduce((sum, w) => sum + (w.Weight * w.Sets * w.Reps), 0);
  const volPrev4 = prev4DaysWorkouts.reduce((sum, w) => sum + (w.Weight * w.Sets * w.Reps), 0);

  const avgVolLast3 = volLast3 / 3;
  const avgVolPrev4 = volPrev4 / 4;

  if (avgVolPrev4 > 0 && avgVolLast3 / avgVolPrev4 > 1.3) {
    const spikePercent = Math.round((avgVolLast3 / avgVolPrev4 - 1) * 100);
    score += 4;
    factors.push({
      factor: `Sudden Volume Spike (+${spikePercent}% in last 3 days)`,
      scoreContribution: 4
    });
  }

  // 4. Consecutive Workout Days (Lack of Rest)
  // Calculate consecutive days worked out leading to today
  let consecutiveDays = 0;
  const sortedUniqueDates = [...new Set(workouts.map(w => w.WorkoutDate))].sort((a,b) => b.localeCompare(a));
  
  if (sortedUniqueDates.length > 0) {
    let checkDate = new Date();
    for (let i = 0; i < 7; i++) {
      const dateStr = checkDate.toISOString().split('T')[0];
      if (sortedUniqueDates.includes(dateStr)) {
        consecutiveDays++;
        checkDate.setDate(checkDate.getDate() - 1);
      } else {
        break;
      }
    }
  }

  if (consecutiveDays >= 5) {
    score += 5;
    factors.push({
      factor: `Insufficient Rest (${consecutiveDays} consecutive training days)`,
      scoreContribution: 5
    });
  } else if (consecutiveDays >= 3) {
    score += 2;
    factors.push({
      factor: `Moderate Fatigue (${consecutiveDays} consecutive training days)`,
      scoreContribution: 2
    });
  }

  // 5. Workout Intensity vs Experience Level Mismatch
  if (profile) {
    const level = profile.Experience; // Beginner / Intermediate / Advanced
    const hardWorkouts = recentWorkouts.filter(w => w.Difficulty === 'Hard' || w.Difficulty === 'Very Hard');

    if (level === 'Beginner' && hardWorkouts.length >= 2) {
      score += 4;
      factors.push({
        factor: `Beginner performing high-difficulty movements`,
        scoreContribution: 4
      });
    } else if (level === 'Intermediate' && hardWorkouts.some(w => w.Difficulty === 'Very Hard')) {
      score += 2;
      factors.push({
        factor: `Intermediate training at extreme difficulty`,
        scoreContribution: 2
      });
    }
  }

  // Calculate final category
  let level: 'Low' | 'Medium' | 'High' = 'Low';
  if (score >= 15) {
    level = 'High';
  } else if (score >= 7) {
    level = 'Medium';
  }

  // Cap score to 30 for visual metrics
  const displayScore = Math.min(Math.round(score), 30);

  return {
    score: displayScore,
    level,
    factors: factors.length > 0 ? factors : [{ factor: 'Balanced Training Volume & Adequate Recovery', scoreContribution: 0 }]
  };
}
