// AI Service for Injury Prevention Analysis & Chat
// Uses @google/genai SDK with a rich rule-based fallback system

import { GoogleGenAI, Type } from '@google/genai';
import { FitnessProfile, WorkoutHistory, PainReport, AIRecommendation } from '../src/types.js';
import { calculateInjuryRisk } from './risk_engine.js';

// Lazy initializer for GoogleGenAI to ensure process.env.GEMINI_API_KEY is populated after dotenv.config()
let aiInstance: GoogleGenAI | null = null;

function getAI(): GoogleGenAI | null {
  if (aiInstance) return aiInstance;

  const apiKey = process.env.GEMINI_API_KEY;
  if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
    aiInstance = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
    console.log('GoogleGenAI initialized lazily and successfully.');
  } else {
    console.log('No valid GEMINI_API_KEY found in process.env during lazy initialization.');
  }
  return aiInstance;
}

export interface AIAnalysisOutput {
  causes: string[];
  recommendations: string[];
  recoveryAdvice: string[];
  saferAlternatives: string[];
  riskLevel: 'Low' | 'Medium' | 'High';
  riskExplanation: string;
  // Mapped properties for direct frontend compatibility
  riskScore: number;
  factors: string[];
  rehabTips: string[];
  explanation: string;
}

const MEDICAL_DISCLAIMER = "\n\n*Disclaimer: This is educational fitness guidance only, not a medical diagnosis. If you experience severe, shooting, or persistent pain, numbness, swelling, or loss of mobility, please stop exercising immediately and seek a professional medical diagnosis.*";

/**
 * Fallback Rule-Based Analysis when no Gemini API Key is configured
 */
export function generateFallbackAnalysis(
  profile: FitnessProfile | null,
  recentWorkouts: WorkoutHistory[],
  recentPainReports: PainReport[]
): AIAnalysisOutput {
  const risk = calculateInjuryRisk(recentWorkouts, recentPainReports, profile);
  
  const bodyPart = recentPainReports.length > 0 ? recentPainReports[0].BodyPart : 'General';
  const exercise = recentPainReports.length > 0 ? recentPainReports[0].Exercise : 'workout';

  let causes: string[] = [];
  let recommendations: string[] = [];
  let recoveryAdvice: string[] = [];
  let saferAlternatives: string[] = [];

  // Specific Body Part Logic
  if (bodyPart.toLowerCase().includes('shoulder')) {
    causes = [
      `Excessive elbow flaring during ${exercise || 'bench presses'} placing high shear force on the anterior deltoids.`,
      `Minor rotator cuff impingement due to pushing volume mismatch compared to back pulling/scapular retraction.`,
      `Inadequate dynamic warm-up targeting shoulder rotators and serratus anterior.`
    ];
    recommendations = [
      `Angle your elbows at 45 degrees relative to your torso on pushing exercises rather than wide 90 degrees.`,
      `Implement a 2:1 ratio of back pulling (pullups, rows, facepulls) to chest pressing volume.`,
      `Focus on stretching chest/anterior deltoids and strengthening rotator cuff muscles (internal/external rotations).`
    ];
    recoveryAdvice = [
      `Apply ice if throbbing or hot; use heat to increase blood flow if stiff.`,
      `Take 5-7 days off heavy vertical or horizontal pressing movements.`,
      `Perform daily band pull-aparts and sleeper stretches for mobility.`
    ];
    saferAlternatives = [
      `Dumbbell Floor Press (restricts excessive shoulder hyperextension)`,
      `Incline Dumbbell Press (reduces pressure on front deltoid)`,
      `Chest-Supported Dumbbell Rows (targets back stabilizers)`
    ];
  } else if (bodyPart.toLowerCase().includes('knee')) {
    causes = [
      `Patellar tendon tracking issues caused by tight quadriceps or weak gluteus medius pulling knee inward.`,
      `Sudden increase in deep bending volume or weight on ${exercise || 'squats'} without proper ankle mobility.`,
      `Poor knee alignment (knees caving in / valgus collapse) during loaded lower body exercises.`
    ];
    recommendations = [
      `Squeeze your glutes and push knees outward dynamically while squatting.`,
      `Perform foam rolling and static stretches on tight quadriceps and IT-bands.`,
      `Limit depth to parallel instead of deep 'ass-to-grass' until knee joints stabilize.`
    ];
    recoveryAdvice = [
      `Rest from high-impact running or heavy bilateral squatting for 7-10 days.`,
      `Ice knee for 15 minutes after workouts if minor swelling occurs.`,
      `Incorporate low-impact swimming or steady stationary cycling to maintain joint lubrication.`
    ];
    saferAlternatives = [
      `Goblet Squats (forces upright torso and better glute activation)`,
      `Leg Press (limits spinal loading and stabilizes knee track)`,
      `Box Squats (prevents bottom-range knee stress)`
    ];
  } else if (bodyPart.toLowerCase().includes('back') || bodyPart.toLowerCase().includes('spine')) {
    causes = [
      `Lumbar spine rounding under load during ${exercise || 'deadlifts or squats'} due to fatigue or core collapse.`,
      `Poor hip hinge mechanics shifting the load onto the spinal erectors instead of hamstrings and glutes.`,
      `Weak deep abdominal core muscles (transverse abdominis) failing to stabilize the lumbar curve.`
    ];
    recommendations = [
      `Maintain a rigid, neutral flat back at all times when pulling or squatting.`,
      `Incorporate bracing protocols (Valsalva maneuver) prior to every repetition.`,
      `Decrease working load by 20-30% and master the hip hinge with bodyweight or wooden dowels.`
    ];
    recoveryAdvice = [
      `Perform 'Cat-Cow' stretches and gentle abdominal hollowing daily.`,
      `Avoid long-duration sitting which compresses spinal discs further.`,
      `Use gentle walking to encourage active blood flow to lower back muscles.`
    ];
    saferAlternatives = [
      `Trap Bar Deadlift (keeps load centered closer to gravity)`,
      `Chest-Supported Dumbbell Rows (completely deloads lumbar spine)`,
      `Plank variations (trains core stabilization without flexion)`
    ];
  } else {
    // General / Catch-all Fallback
    causes = [
      `Sudden increase in workout frequency or intensity exceeding muscular recovery capacity.`,
      `Muscle imbalance surrounding the affected joints, leading to compensation.`,
      `Insufficient joint warm-up or missing mobility/stretching work.`
    ];
    recommendations = [
      `Reduce weight by 20-40% on exercises that stimulate pain and focus on eccentric control.`,
      `Double down on daily sleep quality, hydration, and protein intake to aid tissue recovery.`,
      `Track training volume strictly to prevent sudden overreaching.`
    ];
    recoveryAdvice = [
      `Apply active recovery protocols: light stretching and zone 2 cardio.`,
      `Adopt a minimum of 2 complete rest days per week.`,
      `Incorporate dynamic stretching routines before your lifting session.`
    ];
    saferAlternatives = [
      `Bodyweight exercises targeting the muscle groups`,
      `Cable machine alternatives (controls mechanical tension path)`,
      `Isolations that bypass the painful joint`
    ];
  }

  // Factor in risk scores to risk explanation
  const contributing = risk.factors.map(f => f.factor).join(', ');
  const riskExplanation = `Risk scored at ${risk.score}/30 (Category: ${risk.level}). Key warning flags include: ${contributing}.`;

  return {
    causes,
    recommendations,
    recoveryAdvice,
    saferAlternatives,
    riskLevel: risk.level,
    riskExplanation,
    // Add exact fields that the frontend expects
    riskScore: risk.score,
    factors: causes,
    rehabTips: recoveryAdvice,
    explanation: riskExplanation
  };
}

/**
 * Generate Structured AI Injury Risk Analysis using Gemini 3.5
 */
export async function generateAnalysis(
  profile: FitnessProfile | null,
  recentWorkouts: WorkoutHistory[],
  recentPainReports: PainReport[]
): Promise<AIAnalysisOutput> {
  const ai = getAI();
  if (!ai) {
    return generateFallbackAnalysis(profile, recentWorkouts, recentPainReports);
  }

  const risk = calculateInjuryRisk(recentWorkouts, recentPainReports, profile);
  const painContext = recentPainReports.length > 0 
    ? `Latest Pain Report:
- Affected Body Part: ${recentPainReports[0].BodyPart}
- Pain Level: ${recentPainReports[0].PainLevel}/10
- Pain Type: ${recentPainReports[0].PainType}
- Duration: ${recentPainReports[0].Duration}
- Trigger Exercise: ${recentPainReports[0].Exercise}
- User Notes: ${recentPainReports[0].Notes || 'None'}`
    : "No recent pain reports logged.";

  const profileContext = profile
    ? `User Fitness Profile:
- Age: ${profile.Age}, Gender: ${profile.Gender}
- Height: ${profile.Height} cm, Weight: ${profile.Weight} kg, BMI: ${profile.BMI}
- Lifting Experience: ${profile.Experience}
- Goal: ${profile.Goal}`
    : "No fitness profile completed yet.";

  const workoutContext = recentWorkouts.length > 0
    ? `Recent Workouts Logged (Last 10 days):
${recentWorkouts.slice(0, 8).map(w => `- Date: ${w.WorkoutDate}, Exercise: ${w.Exercise}, Muscle: ${w.MuscleGroup}, Sets: ${w.Sets}, Reps: ${w.Reps}, Weight: ${w.Weight}kg, Difficulty: ${w.Difficulty}`).join('\n')}`
    : "No workouts logged in the system yet.";

  const prompt = `You are an expert Sports Medicine & Athletic Injury Prevention assistant.
Analyze this athlete's data to estimate injury risk, describe possible causes, and suggest safer exercises and recovery advice.

${profileContext}

${painContext}

${workoutContext}

Our rule-based risk algorithm calculated a preliminary score of ${risk.score}/30 with risk category "${risk.level}".
Take this calculation into account but do a comprehensive biomechanical, athletic evaluation.

You MUST respond strictly with a valid JSON object matching this schema:
{
  "causes": ["cause 1", "cause 2"],
  "recommendations": ["rec 1", "rec 2"],
  "recoveryAdvice": ["advice 1", "advice 2"],
  "saferAlternatives": ["alt 1", "alt 2"],
  "riskLevel": "Low" | "Medium" | "High",
  "riskExplanation": "detailed explanation"
}

Ensure all statements are educational, non-medical, and reference specific exercises or body parts mentioned in the context.`;

  try {
    let response;
    const modelConfig = {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          causes: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "2-4 possible biomechanical causes of the pain or risk"
          },
          recommendations: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "2-4 practical tips to improve technique, balance training volume, or prevent injury"
          },
          recoveryAdvice: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "2-3 dynamic stretching, mobilty exercises, or standard rest parameters"
          },
          saferAlternatives: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "2-3 mechanical alternative exercises that reduce load on the painful body parts"
          },
          riskLevel: {
            type: Type.STRING,
            description: "Low, Medium, or High"
          },
          riskExplanation: {
            type: Type.STRING,
            description: "A comprehensive summary explanation of their injury risk factors and recovery time"
          }
        },
        required: ['causes', 'recommendations', 'recoveryAdvice', 'saferAlternatives', 'riskLevel', 'riskExplanation']
      }
    };

    try {
      response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: modelConfig
      });
    } catch (primaryErr) {
      console.warn('Primary model gemini-2.5-flash failed, trying secondary gemini-3.1-flash-lite:', primaryErr);
      response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite',
        contents: prompt,
        config: modelConfig
      });
    }

    const text = response.text;
    if (text) {
      let cleaned = text.trim();
      if (cleaned.startsWith('```')) {
        cleaned = cleaned.replace(/^```(?:json)?\n?/, '').replace(/\n?```$/, '').trim();
      }
      const parsed = JSON.parse(cleaned);
      
      // Normalize riskLevel to capitalized Low | Medium | High
      if (parsed.riskLevel) {
        const rLower = String(parsed.riskLevel).toLowerCase();
        if (rLower.includes('high')) parsed.riskLevel = 'High';
        else if (rLower.includes('med')) parsed.riskLevel = 'Medium';
        else parsed.riskLevel = 'Low';
      } else {
        parsed.riskLevel = risk.level;
      }

      // Populate missing fields for direct compatibility with frontend expectations
      parsed.riskScore = risk.score;
      parsed.factors = parsed.causes || [];
      parsed.rehabTips = parsed.recoveryAdvice || parsed.recommendations || [];
      parsed.explanation = parsed.riskExplanation || '';
      return parsed as AIAnalysisOutput;
    }
    throw new Error('Empty AI response');
  } catch (err) {
    console.error('Error generating analysis from Gemini, using fallback:', err);
    return generateFallbackAnalysis(profile, recentWorkouts, recentPainReports);
  }
}

/**
 * Handle AI Chatbot Replies integrating the user's specific context
 */
export async function chatReply(
  profile: FitnessProfile | null,
  recentWorkouts: WorkoutHistory[],
  recentPainReports: PainReport[],
  question: string
): Promise<string> {
  const ai = getAI();
  if (!ai) {
    // Elegant and highly concise keyword-based fallback replies for local demo without billing
    const qLower = question.toLowerCase();
    let reply = "";

    if (qLower.includes('shoulder') || qLower.includes('bench') || qLower.includes('chest')) {
      reply = `**Shoulder Safety:** Shoulder pinching during bench press is often rotator cuff impingement.
• **Tip:** Pin your shoulder blades back/down; angle elbows at 45° (don't flare to 90°).
• **Alternative:** Try **Dumbbell Floor Press** to restrict deep shoulder hyperextension, and perform band facepulls.`;
    } else if (qLower.includes('squat') || qLower.includes('knee') || qLower.includes('leg')) {
      reply = `**Knee Protection:** Knee strain in squats usually stems from knees caving inward or tight quads.
• **Tip:** Push knees outward dynamically during the lift, and foam roll your quadriceps.
• **Alternative:** Swap back squats for **Goblet Squats** (keeps torso upright) or stable **Leg Press** (higher foot placement).`;
    } else if (qLower.includes('back') || qLower.includes('deadlift') || qLower.includes('row')) {
      reply = `**Lower Back Care:** Back stiffness often results from lumbar rounding or poor hip hinges.
• **Tip:** Keep a flat spine, brace your core, and keep the bar close to your shins.
• **Alternative:** Switch to **Chest-Supported Rows** or **Trap Bar Deadlifts** to deload spinal forces.`;
    } else if (qLower.includes('diet') || qLower.includes('food') || qLower.includes('eat') || qLower.includes('protein') || qLower.includes('nutrition') || qLower.includes('meal') || qLower.includes('calorie')) {
      reply = `**Recovery Nutrition & Diet:**
• **Protein:** Target 1.6 to 2.2 grams per kg of bodyweight daily to repair exercise-induced micro-tears in muscle tissues.
• **Anti-Inflammatory Nutrition:** Integrate Omega-3 rich foods (salmon, walnuts, chia seeds) and antioxidants to minimize joint swelling and support cartilage.
• **Hydration & Glycogen:** Maintain high water intake to keep synovial fluid lubricated, and replenish energy with clean complex carbohydrates (oatmeal, sweet potatoes).`;
    } else {
      reply = `Hi! I'm your AI Coach. Based on your profile:
${recentPainReports.length > 0 ? `• **Active Pain:** ${recentPainReports[0].BodyPart} (Level ${recentPainReports[0].PainLevel}/10). Rest recommended.` : `• **Status:** No active pain. Great job!`}
${recentWorkouts.length > 0 ? `• **History:** ${recentWorkouts.length} logged workouts. Avoid training spikes.` : `• **History:** No workouts logged yet.`}

**Injury Prevention Essentials:**
1. Limit weekly volume increases to <10%.
2. Maintain 1-2 full rest days weekly.
3. Replace painful moves with safe alternatives immediately.

What specific joints, exercises, or recovery nutrition should we optimize?`;
    }

    return reply + MEDICAL_DISCLAIMER;
  }

  const painContext = recentPainReports.length > 0 
    ? `User reports pain in their ${recentPainReports[0].BodyPart} (Level ${recentPainReports[0].PainLevel}/10, Type: ${recentPainReports[0].PainType}) from ${recentPainReports[0].Exercise}.`
    : "User has no active pain reports logged.";

  const profileContext = profile 
    ? `User profile: Age ${profile.Age}, experience level is ${profile.Experience}, goal is ${profile.Goal}.`
    : "User profile is not completed.";

  const recentWorkoutSummary = recentWorkouts.length > 0
    ? `Recent workouts list: ${recentWorkouts.slice(0, 3).map(w => w.Exercise).join(', ')}.`
    : "No recent workouts logged.";

  const prompt = `You are a professional, safety-first AI Coach specializing in workout biomechanics, injury prevention, and recovery.
The user is asking a health, exercise, recovery, or nutrition question: "${question}"

Provide a concise, direct, and relevant answer strictly under 150 words. Focus on:
1. Directly addressing their query with practical, actionable tips (e.g. food options if asking about diet, technique cues if asking about lifts).
2. Tying it back briefly to training safety, recovery, joint health, or biomechanics where logical.
3. Using brief bullet points and bold headers to keep it extremely readable and easy to scan.

**User Profile & Context:**
- ${profileContext}
- ${painContext}
- ${recentWorkoutSummary}

Provide your answer below (strictly under 150 words):`;

  try {
    let response;
    const modelConfig = {
      systemInstruction: "You are an expert, friendly AI Workout Coach specializing in biomechanics, injury prevention, joint health, and athletic nutrition. Provide clear, direct, and relevant guidance tailored exactly to what the user asks. Always keep your responses highly concise, direct, and under 150 words using clean markdown bullet points. Do not write essays or verbose paragraphs. Get straight to the point."
    };

    try {
      response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: modelConfig
      });
    } catch (primaryErr) {
      console.warn('Primary model gemini-2.5-flash failed, trying secondary gemini-3.1-flash-lite:', primaryErr);
      response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite',
        contents: prompt,
        config: modelConfig
      });
    }

    const replyText = response.text;
    if (replyText) {
      return replyText.trim() + MEDICAL_DISCLAIMER;
    }
    throw new Error('Empty chat response');
  } catch (err) {
    console.error('All Gemini model calls failed, using local biomechanical fallback:', err);
    // Dynamic rule-based backup response
    const qLower = question.toLowerCase();
    let reply = "";

    if (qLower.includes('shoulder') || qLower.includes('bench') || qLower.includes('chest')) {
      reply = `**Shoulder Safety:** Shoulder pinching during bench press is often rotator cuff impingement.
• **Tip:** Pin your shoulder blades back/down; angle elbows at 45° (don't flare to 90°).
• **Alternative:** Try **Dumbbell Floor Press** to restrict deep shoulder hyperextension, and perform band facepulls.`;
    } else if (qLower.includes('squat') || qLower.includes('knee') || qLower.includes('leg')) {
      reply = `**Knee Protection:** Knee strain in squats usually stems from knees caving inward or tight quads.
• **Tip:** Push knees outward dynamically during the lift, and foam roll your quadriceps.
• **Alternative:** Swap back squats for **Goblet Squats** (keeps torso upright) or stable **Leg Press** (higher foot placement).`;
    } else if (qLower.includes('back') || qLower.includes('deadlift') || qLower.includes('row')) {
      reply = `**Lower Back Care:** Back stiffness often results from lumbar rounding or poor hip hinges.
• **Tip:** Keep a flat spine, brace your core, and keep the bar close to your shins.
• **Alternative:** Switch to **Chest-Supported Rows** or **Trap Bar Deadlifts** to deload spinal forces.`;
    } else if (qLower.includes('diet') || qLower.includes('food') || qLower.includes('eat') || qLower.includes('protein') || qLower.includes('nutrition') || qLower.includes('meal') || qLower.includes('calorie')) {
      reply = `**Recovery Nutrition & Diet:**
• **Protein:** Target 1.6 to 2.2 grams per kg of bodyweight daily to repair exercise-induced micro-tears in muscle tissues.
• **Anti-Inflammatory Nutrition:** Integrate Omega-3 rich foods (salmon, walnuts, chia seeds) and antioxidants to minimize joint swelling and support cartilage.
• **Hydration & Glycogen:** Maintain high water intake to keep synovial fluid lubricated, and replenish energy with clean complex carbohydrates (oatmeal, sweet potatoes).`;
    } else {
      reply = `Hi! I'm your AI Coach. Based on your profile:
${recentPainReports.length > 0 ? `• **Active Pain:** ${recentPainReports[0].BodyPart} (Level ${recentPainReports[0].PainLevel}/10). Rest recommended.` : `• **Status:** No active pain. Great job!`}
${recentWorkouts.length > 0 ? `• **History:** ${recentWorkouts.length} logged workouts. Avoid training spikes.` : `• **History:** No workouts logged yet.`}

**Injury Prevention Essentials:**
1. Limit weekly volume increases to <10%.
2. Maintain 1-2 full rest days weekly.
3. Replace painful moves with safe alternatives immediately.

What specific joints, exercises, or recovery nutrition should we optimize?`;
    }

    const note = `*(Note: Upstream AI is currently experiencing high load; displaying local biomechanical guidelines)*\n\n`;
    return note + reply + MEDICAL_DISCLAIMER;
  }
}
