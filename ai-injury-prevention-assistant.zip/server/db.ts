// File-based persistent JSON Database Engine
// Mimics a relational MySQL Database for AI Injury Prevention Assistant
import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import { 
  User, FitnessProfile, Exercise, WorkoutHistory, PainReport, 
  AIRecommendation, RecoveryPlan, ChatMessage, Notification, 
  PasswordReset, ActivityLog 
} from '../src/types.js';

const DB_FILE = path.join(process.cwd(), 'db_storage.json');

interface DatabaseSchema {
  Users: User[];
  FitnessProfile: FitnessProfile[];
  Exercises: Exercise[];
  WorkoutHistory: WorkoutHistory[];
  PainReports: PainReport[];
  AIRecommendations: AIRecommendation[];
  RecoveryPlans: RecoveryPlan[];
  ChatHistory: ChatMessage[];
  Notifications: Notification[];
  PasswordReset: PasswordReset[];
  ActivityLog: ActivityLog[];
}

// Global In-Memory representation synced to file
let db: DatabaseSchema = {
  Users: [],
  FitnessProfile: [],
  Exercises: [],
  WorkoutHistory: [],
  PainReports: [],
  AIRecommendations: [],
  RecoveryPlans: [],
  ChatHistory: [],
  Notifications: [],
  PasswordReset: [],
  ActivityLog: []
};

// Auto-seed Initial Data
async function initDb() {
  if (fs.existsSync(DB_FILE)) {
    try {
      const data = fs.readFileSync(DB_FILE, 'utf8');
      const loaded = JSON.parse(data);
      db = {
        Users: loaded.Users || [],
        FitnessProfile: loaded.FitnessProfile || [],
        Exercises: loaded.Exercises || [],
        WorkoutHistory: loaded.WorkoutHistory || [],
        PainReports: loaded.PainReports || [],
        AIRecommendations: loaded.AIRecommendations || [],
        RecoveryPlans: loaded.RecoveryPlans || [],
        ChatHistory: loaded.ChatHistory || [],
        Notifications: loaded.Notifications || [],
        PasswordReset: loaded.PasswordReset || [],
        ActivityLog: loaded.ActivityLog || [],
      };
      
      // Ensure seed users have valid password hashes in the existing JSON database
      let modified = false;
      const adminUser = db.Users.find(u => u.Email.toLowerCase() === 'admin@demo.com');
      if (adminUser && !(adminUser as any).Password) {
        (adminUser as any).Password = await bcrypt.hash('admin123', 10);
        modified = true;
      }
      const demoUser = db.Users.find(u => u.Email.toLowerCase() === 'demo@user.com');
      if (demoUser && !(demoUser as any).Password) {
        (demoUser as any).Password = await bcrypt.hash('demo123', 10);
        modified = true;
      }
      if (modified) {
        fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf8');
        console.log('Backfilled missing passwords for seeded admin and user accounts in existing database.');
      }

      console.log('Database loaded successfully and normalized from', DB_FILE);
      return;
    } catch (e) {
      console.error('Error reading DB_FILE, re-initializing...', e);
    }
  }

  console.log('Initializing fresh database and seeding realistic demo data...');

  // 1. Seed Users (Hashed passwords for 'demo123' and 'admin123')
  const userPasswordHash = await bcrypt.hash('demo123', 10);
  const adminPasswordHash = await bcrypt.hash('admin123', 10);

  db.Users = [
    {
      UserID: 1,
      Name: 'System Admin',
      Email: 'admin@demo.com',
      Role: 'admin',
      CreatedAt: new Date().toISOString()
    },
    {
      UserID: 2,
      Name: 'John Doe',
      Email: 'demo@user.com',
      Role: 'user',
      CreatedAt: new Date().toISOString()
    }
  ];

  (db.Users[0] as any).Password = adminPasswordHash;
  (db.Users[1] as any).Password = userPasswordHash;

  // 2. Seed Fitness Profile
  db.FitnessProfile = [
    {
      UserID: 2,
      Age: 28,
      Gender: 'Male',
      Height: 180,
      Weight: 82,
      BMI: 25.31,
      Experience: 'Intermediate',
      Goal: 'Muscle Gain'
    }
  ];

  // 3. Seed Exercises with safety tips & alternatives
  db.Exercises = [
    {
      ExerciseID: 1,
      ExerciseName: 'Bench Press',
      MuscleGroup: 'Chest',
      Description: 'A classic upper body compound exercise targeting the pectoral muscles, anterior deltoids, and triceps.',
      SafetyTips: 'Keep your feet flat on the floor, maintain a slight arch in your lower back, and do not flare your elbows excessively (aim for 45 degrees).',
      Difficulty: 'Intermediate',
      Equipment: 'Barbell, Bench',
      Alternatives: ['Dumbbell Floor Press (Safer for shoulders)', 'Incline Dumbbell Press (Reduces flat bench shoulder strain)']
    },
    {
      ExerciseID: 2,
      ExerciseName: 'Push-ups',
      MuscleGroup: 'Chest',
      Description: 'A versatile bodyweight movement that strengthens the chest, shoulders, and triceps while training core stability.',
      SafetyTips: 'Maintain a rigid plank position. Do not sag your hips or crane your neck forward.',
      Difficulty: 'Beginner',
      Equipment: 'Bodyweight',
      Alternatives: ['Incline Push-ups (Easier on shoulders)', 'Knee Push-ups (Regressed load)']
    },
    {
      ExerciseID: 3,
      ExerciseName: 'Pull-ups',
      MuscleGroup: 'Back',
      Description: 'An advanced upper body pulling exercise focusing on the latissimus dorsi, biceps, and upper back.',
      SafetyTips: 'Pull with your elbows, keep your shoulders depressed and retracted at the start, and control the eccentric (lowering) phase.',
      Difficulty: 'Advanced',
      Equipment: 'Pull-up Bar',
      Alternatives: ['Lat Pulldown (Controls weight, easier to scale)', 'Inverted Rows (Lower intensity pulling)']
    },
    {
      ExerciseID: 4,
      ExerciseName: 'Barbell Row',
      MuscleGroup: 'Back',
      Description: 'A powerful back exercise targeting the lats, rhomboids, traps, and rear delts, while requiring lower back stability.',
      SafetyTips: 'Keep a flat back, bend at the hips, and pull the bar to your lower rib cage. Avoid rounding your spine.',
      Difficulty: 'Intermediate',
      Equipment: 'Barbell',
      Alternatives: ['Chest-Supported Row (Eliminates lower back load)', 'Seated Cable Rows (Stable seated posture)']
    },
    {
      ExerciseID: 5,
      ExerciseName: 'Overhead Shoulder Press',
      MuscleGroup: 'Shoulders',
      Description: 'A fundamental vertical pushing movement that builds shoulder strength and stability.',
      SafetyTips: 'Keep your core engaged, glutes tight, and press in a straight line up. Avoid hyperextending your lower back.',
      Difficulty: 'Intermediate',
      Equipment: 'Barbell or Dumbbells',
      Alternatives: ['Landmine Press (Safer arc-like vertical press)', 'Dumbbell Shoulder Press (Independent shoulder tracking)']
    },
    {
      ExerciseID: 6,
      ExerciseName: 'Lateral Raises',
      MuscleGroup: 'Shoulders',
      Description: 'An isolation exercise targeting the lateral head of the deltoids to create shoulder width.',
      SafetyTips: 'Lead with your elbows and maintain a slight forward bend in your torso. Do not swing the weights.',
      Difficulty: 'Beginner',
      Equipment: 'Dumbbells',
      Alternatives: ['Cable Lateral Raises (Continuous tension)', 'Machine Lateral Raises (Guarded path of motion)']
    },
    {
      ExerciseID: 7,
      ExerciseName: 'Barbell Back Squat',
      MuscleGroup: 'Legs',
      Description: 'The king of lower body compound exercises, targeting the quadriceps, glutes, hamstrings, and lower back.',
      SafetyTips: 'Keep your heels flat, chest up, and push your knees outward. Descend until your thighs are parallel to the floor or lower.',
      Difficulty: 'Intermediate',
      Equipment: 'Barbell, Squat Rack',
      Alternatives: ['Goblet Squat (Reduces spinal loading)', 'Leg Press (Safer alternative for lower back issues)']
    },
    {
      ExerciseID: 8,
      ExerciseName: 'Romanian Deadlift',
      MuscleGroup: 'Legs',
      Description: 'An excellent hinge pattern exercise targeting the hamstrings, glutes, and posterior chain.',
      SafetyTips: 'Hinge at your hips, keep the weight close to your legs, and keep a flat spine. Stop when you feel a maximum stretch in hamstrings.',
      Difficulty: 'Intermediate',
      Equipment: 'Barbell or Dumbbells',
      Alternatives: ['Leg Curls (Saves lower back while isolating hamstrings)', 'Glute Bridges (Glute focus without back bending)']
    },
    {
      ExerciseID: 9,
      ExerciseName: 'Bicep Curl',
      MuscleGroup: 'Arms',
      Description: 'An isolation exercise focusing strictly on the biceps brachii.',
      SafetyTips: 'Keep your elbows pinned to your sides. Avoid swinging your body to lift the weight.',
      Difficulty: 'Beginner',
      Equipment: 'Dumbbells or Barbell',
      Alternatives: ['Hammer Curls (Target brachioradialis)', 'Preacher Curls (Eliminates cheating)']
    },
    {
      ExerciseID: 10,
      ExerciseName: 'Tricep Overhead Extension',
      MuscleGroup: 'Arms',
      Description: 'An exercise targeting the long head of the triceps by placing them in a deep stretch.',
      SafetyTips: 'Keep your upper arms vertical and close to your ears. Avoid flaring your elbows outward.',
      Difficulty: 'Beginner',
      Equipment: 'Dumbbell',
      Alternatives: ['Cable Tricep Pushdowns (Safer elbow position)', 'Dips (Compound arms/chest extension)']
    },
    {
      ExerciseID: 11,
      ExerciseName: 'Plank',
      MuscleGroup: 'Core',
      Description: 'An isometric core strength exercise that tests abdominal endurance and full-body rigidity.',
      SafetyTips: 'Squeeze your glutes and core, keep a straight line from your head to your heels, and do not let your lower back sag.',
      Difficulty: 'Beginner',
      Equipment: 'Bodyweight',
      Alternatives: ['Deadbugs (Active dynamic core stability)', 'Bird-Dog (Gentler lumbar loading)']
    }
  ];

  // Helper to get formatted dates relative to today
  const getDateDaysAgo = (days: number): string => {
    const date = new Date();
    date.setDate(date.getDate() - days);
    return date.toISOString().split('T')[0];
  };

  // 4. Seed Workout History for Demo User (over the last 10 days)
  db.WorkoutHistory = [
    {
      WorkoutID: 1,
      UserID: 2,
      Exercise: 'Bench Press',
      MuscleGroup: 'Chest',
      Weight: 80,
      Sets: 4,
      Reps: 8,
      Duration: 45,
      Difficulty: 'Hard',
      WorkoutDate: getDateDaysAgo(10),
      Notes: 'Felt slight tightness in my right shoulder on the last set.'
    },
    {
      WorkoutID: 2,
      UserID: 2,
      Exercise: 'Pull-ups',
      MuscleGroup: 'Back',
      Weight: 0,
      Sets: 3,
      Reps: 10,
      Duration: 30,
      Difficulty: 'Medium',
      WorkoutDate: getDateDaysAgo(9),
      Notes: 'Lats felt great. Controlled descent.'
    },
    {
      WorkoutID: 3,
      UserID: 2,
      Exercise: 'Barbell Back Squat',
      MuscleGroup: 'Legs',
      Weight: 100,
      Sets: 4,
      Reps: 6,
      Duration: 50,
      Difficulty: 'Hard',
      WorkoutDate: getDateDaysAgo(8),
      Notes: 'Legs were fatigued but form felt solid.'
    },
    {
      WorkoutID: 4,
      UserID: 2,
      Exercise: 'Overhead Shoulder Press',
      MuscleGroup: 'Shoulders',
      Weight: 50,
      Sets: 3,
      Reps: 8,
      Duration: 40,
      Difficulty: 'Hard',
      WorkoutDate: getDateDaysAgo(6),
      Notes: 'Right shoulder felt some pinching when pressing lockout.'
    },
    {
      WorkoutID: 5,
      UserID: 2,
      Exercise: 'Bench Press',
      MuscleGroup: 'Chest',
      Weight: 85,
      Sets: 3,
      Reps: 6,
      Duration: 45,
      Difficulty: 'Very Hard',
      WorkoutDate: getDateDaysAgo(4),
      Notes: 'Shoulder pain became prominent on set 3. Had to stop.'
    },
    {
      WorkoutID: 6,
      UserID: 2,
      Exercise: 'Bicep Curl',
      MuscleGroup: 'Arms',
      Weight: 15,
      Sets: 3,
      Reps: 12,
      Duration: 20,
      Difficulty: 'Medium',
      WorkoutDate: getDateDaysAgo(2),
      Notes: 'Arm accessory day. Quick pump.'
    }
  ];

  // 5. Seed Pain Report for Demo User
  db.PainReports = [
    {
      PainID: 1,
      UserID: 2,
      BodyPart: 'Shoulder',
      Exercise: 'Bench Press',
      PainLevel: 6,
      PainType: 'Sharp pinching',
      Duration: '3 days',
      Notes: 'Pinched feeling in front of right shoulder at the bottom of the bench press. Stiff the next morning.',
      ReportDate: getDateDaysAgo(3)
    }
  ];

  // 6. Seed AI Recommendation for Demo User
  db.AIRecommendations = [
    {
      RecommendationID: 1,
      UserID: 2,
      PainID: 1,
      Recommendation: `Based on your report of sharp pinching in your Shoulder during Bench Press, you may be experiencing minor rotator cuff impingement or tendonitis.

**Possible Causes:**
- Too much shoulder internal rotation or flaring elbow position during flat chest press.
- High training volume (multiple pressing workouts in 6 days) with insufficient back pulling to support chest posture.

**Recommendations:**
1. **Switch Exercises**: Temporarily substitute standard Bench Press with **Dumbbell Floor Press** or **Incline Dumbbell Press**.
2. **Modify Technique**: Pull your shoulder blades back and down before lifting, and keep elbows angled at 45 degrees rather than flared.
3. **Warm-up**: Spend 5-10 minutes warming up rotator cuffs using resistance bands.
4. **Volume Adjustment**: Rest the shoulder from all overhead pressing and bench presses for at least 7 days.

*Disclaimer: Educational guidance only. Not a medical diagnosis. If pain persists or worsens, consult a physical therapist or sports medicine specialist.*`,
      RiskLevel: 'Medium',
      CreatedAt: new Date(getDateDaysAgo(3)).toISOString()
    }
  ];

  // 7. Seed Recovery Plan
  db.RecoveryPlans = [
    {
      RecoveryID: 1,
      UserID: 2,
      Advice: 'Rest shoulder from pressing exercises, perform rotator cuff stretches and band wall walks.',
      RecoveryDays: 7,
      Status: 'Active'
    }
  ];

  // 8. Seed Notifications
  db.Notifications = [
    {
      NotificationID: 1,
      UserID: 2,
      Title: 'Welcome to Injury Prevention Assistant!',
      Message: 'Complete your fitness profile to enable personalized injury risk calculations and AI recommended alternatives!',
      Status: 'unread',
      IsAnnouncement: false,
      CreatedAt: new Date().toISOString()
    },
    {
      NotificationID: 2,
      UserID: null, // Announcement
      Title: 'System Announcement: Safety Guidelines',
      Message: 'Always warm up for at least 5-10 minutes prior to lifting heavy loads to protect tendons and dynamic stabilizers.',
      Status: 'unread',
      IsAnnouncement: true,
      CreatedAt: new Date().toISOString()
    }
  ];

  saveDb();
}

// Persist current state to db_storage.json
function saveDb() {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf8');
  } catch (e) {
    console.error('Error saving DB_FILE', e);
  }
}

// Exported DB Actions (mimicking MySQL database engine)
export const dbService = {
  // Ensure loaded
  async ensureReady() {
    if (db.Users.length === 0) {
      await initDb();
    }
  },

  // Users
  getUsers() { return db.Users; },
  getUserById(id: number) { return db.Users.find(u => u.UserID === id) || null; },
  getUserByEmail(email: string) { return db.Users.find(u => u.Email.toLowerCase() === email.toLowerCase()) || null; },
  async createUser(user: Partial<User> & { PasswordHash: string }) {
    const nextId = db.Users.reduce((max, u) => u.UserID > max ? u.UserID : max, 0) + 1;
    const newUser: User = {
      UserID: nextId,
      Name: user.Name || 'Anonymous',
      Email: user.Email!,
      Role: user.Role || 'user',
      CreatedAt: new Date().toISOString()
    };
    
    // Set mock password field internally (stored in separate schema map inside db)
    db.Users.push(newUser);
    
    // Save user password hashed directly inside db schema (to keep file simple, we add a secret password property that is filtered out when returning)
    (newUser as any).Password = user.PasswordHash;
    
    saveDb();
    return newUser;
  },
  async updateUserPassword(userId: number, newHash: string) {
    const user = db.Users.find(u => u.UserID === userId);
    if (user) {
      (user as any).Password = newHash;
      saveDb();
      return true;
    }
    return false;
  },
  deleteUser(id: number) {
    db.Users = db.Users.filter(u => u.UserID !== id);
    db.FitnessProfile = db.FitnessProfile.filter(p => p.UserID !== id);
    db.WorkoutHistory = db.WorkoutHistory.filter(w => w.UserID !== id);
    db.PainReports = db.PainReports.filter(pr => pr.UserID !== id);
    db.AIRecommendations = db.AIRecommendations.filter(r => r.UserID !== id);
    db.RecoveryPlans = db.RecoveryPlans.filter(rp => rp.UserID !== id);
    db.ChatHistory = db.ChatHistory.filter(ch => ch.UserID !== id);
    db.Notifications = db.Notifications.filter(n => n.UserID !== id);
    db.PasswordReset = db.PasswordReset.filter(p => p.UserID !== id);
    saveDb();
    return true;
  },

  // Fitness Profile
  getProfileByUserId(userId: number) { return db.FitnessProfile.find(p => p.UserID === userId) || null; },
  upsertProfile(profile: Partial<FitnessProfile> & { UserID: number }) {
    let existing = db.FitnessProfile.find(p => p.UserID === profile.UserID);
    const weight = profile.Weight ?? 0;
    const height = profile.Height ?? 0;
    const bmi = height > 0 ? Number((weight / ((height / 100) ** 2)).toFixed(2)) : 0;

    if (existing) {
      existing.Age = profile.Age ?? existing.Age;
      existing.Gender = profile.Gender ?? existing.Gender;
      existing.Height = profile.Height ?? existing.Height;
      existing.Weight = profile.Weight ?? existing.Weight;
      existing.BMI = bmi;
      existing.Experience = profile.Experience ?? existing.Experience;
      existing.Goal = profile.Goal ?? existing.Goal;
    } else {
      const nextId = db.FitnessProfile.reduce((max, p) => p.ProfileID! > max ? p.ProfileID! : max, 0) + 1;
      existing = {
        ProfileID: nextId,
        UserID: profile.UserID,
        Age: profile.Age || 0,
        Gender: profile.Gender || 'Other',
        Height: profile.Height || 0,
        Weight: profile.Weight || 0,
        BMI: bmi,
        Experience: profile.Experience || 'Beginner',
        Goal: profile.Goal || 'General Fitness'
      };
      db.FitnessProfile.push(existing);
    }
    saveDb();
    return existing;
  },

  // Exercises
  getExercises() { return db.Exercises; },
  getExerciseById(id: number) { return db.Exercises.find(e => e.ExerciseID === id) || null; },
  getExerciseByName(name: string) { return db.Exercises.find(e => e.ExerciseName.toLowerCase() === name.toLowerCase()) || null; },
  createExercise(exercise: Partial<Exercise>) {
    const nextId = db.Exercises.reduce((max, e) => e.ExerciseID > max ? e.ExerciseID : max, 0) + 1;
    const newEx: Exercise = {
      ExerciseID: nextId,
      ExerciseName: exercise.ExerciseName || 'Unnamed Exercise',
      MuscleGroup: exercise.MuscleGroup || 'General',
      Description: exercise.Description || '',
      SafetyTips: exercise.SafetyTips || '',
      Difficulty: exercise.Difficulty || 'Beginner',
      Equipment: exercise.Equipment || 'None',
      Alternatives: exercise.Alternatives || []
    };
    db.Exercises.push(newEx);
    saveDb();
    return newEx;
  },
  updateExercise(id: number, exercise: Partial<Exercise>) {
    const ex = db.Exercises.find(e => e.ExerciseID === id);
    if (ex) {
      ex.ExerciseName = exercise.ExerciseName ?? ex.ExerciseName;
      ex.MuscleGroup = exercise.MuscleGroup ?? ex.MuscleGroup;
      ex.Description = exercise.Description ?? ex.Description;
      ex.SafetyTips = exercise.SafetyTips ?? ex.SafetyTips;
      ex.Difficulty = exercise.Difficulty ?? ex.Difficulty;
      ex.Equipment = exercise.Equipment ?? ex.Equipment;
      ex.Alternatives = exercise.Alternatives ?? ex.Alternatives;
      saveDb();
      return ex;
    }
    return null;
  },
  deleteExercise(id: number) {
    db.Exercises = db.Exercises.filter(e => e.ExerciseID !== id);
    saveDb();
    return true;
  },

  // Workout History
  getWorkoutsByUserId(userId: number) {
    return db.WorkoutHistory.filter(w => w.UserID === userId).sort((a,b) => b.WorkoutDate.localeCompare(a.WorkoutDate));
  },
  createWorkout(workout: Partial<WorkoutHistory> & { UserID: number }) {
    const nextId = db.WorkoutHistory.reduce((max, w) => w.WorkoutID > max ? w.WorkoutID : max, 0) + 1;
    const newWorkout: WorkoutHistory = {
      WorkoutID: nextId,
      UserID: workout.UserID,
      Exercise: workout.Exercise || 'Exercise',
      MuscleGroup: workout.MuscleGroup || 'General',
      Weight: Number(workout.Weight) || 0,
      Sets: Number(workout.Sets) || 1,
      Reps: Number(workout.Reps) || 1,
      Duration: Number(workout.Duration) || 0,
      Difficulty: workout.Difficulty || 'Medium',
      WorkoutDate: workout.WorkoutDate || new Date().toISOString().split('T')[0],
      Notes: workout.Notes || ''
    };
    db.WorkoutHistory.push(newWorkout);
    saveDb();
    return newWorkout;
  },
  updateWorkout(id: number, workout: Partial<WorkoutHistory>) {
    const w = db.WorkoutHistory.find(item => item.WorkoutID === id);
    if (w) {
      w.Exercise = workout.Exercise ?? w.Exercise;
      w.MuscleGroup = workout.MuscleGroup ?? w.MuscleGroup;
      w.Weight = workout.Weight !== undefined ? Number(workout.Weight) : w.Weight;
      w.Sets = workout.Sets !== undefined ? Number(workout.Sets) : w.Sets;
      w.Reps = workout.Reps !== undefined ? Number(workout.Reps) : w.Reps;
      w.Duration = workout.Duration !== undefined ? Number(workout.Duration) : w.Duration;
      w.Difficulty = workout.Difficulty ?? w.Difficulty;
      w.WorkoutDate = workout.WorkoutDate ?? w.WorkoutDate;
      w.Notes = workout.Notes ?? w.Notes;
      saveDb();
      return w;
    }
    return null;
  },
  deleteWorkout(id: number) {
    db.WorkoutHistory = db.WorkoutHistory.filter(w => w.WorkoutID !== id);
    saveDb();
    return true;
  },

  // Pain Reports
  getPainReportsByUserId(userId: number) {
    return db.PainReports.filter(p => p.UserID === userId).sort((a,b) => {
      const dateCompare = b.ReportDate.localeCompare(a.ReportDate);
      if (dateCompare !== 0) return dateCompare;
      return b.PainID - a.PainID; // descending order of ID for newer logs on same day
    });
  },
  createPainReport(report: Partial<PainReport> & { UserID: number }) {
    const nextId = db.PainReports.reduce((max, p) => p.PainID > max ? p.PainID : max, 0) + 1;
    const newReport: PainReport = {
      PainID: nextId,
      UserID: report.UserID,
      BodyPart: report.BodyPart || 'General',
      Exercise: report.Exercise || 'None',
      PainLevel: Number(report.PainLevel) || 1,
      PainType: report.PainType || 'Stiffness',
      Duration: report.Duration || '1 day',
      Notes: report.Notes || '',
      ReportDate: report.ReportDate || new Date().toISOString().split('T')[0]
    };
    db.PainReports.push(newReport);
    saveDb();
    return newReport;
  },
  updatePainReport(id: number, report: Partial<PainReport>) {
    const p = db.PainReports.find(item => item.PainID === id);
    if (p) {
      p.BodyPart = report.BodyPart ?? p.BodyPart;
      p.Exercise = report.Exercise ?? p.Exercise;
      p.PainLevel = report.PainLevel !== undefined ? Number(report.PainLevel) : p.PainLevel;
      p.PainType = report.PainType ?? p.PainType;
      p.Duration = report.Duration ?? p.Duration;
      p.Notes = report.Notes ?? p.Notes;
      p.ReportDate = report.ReportDate ?? p.ReportDate;
      saveDb();
      return p;
    }
    return null;
  },
  deletePainReport(id: number) {
    db.PainReports = db.PainReports.filter(p => p.PainID !== id);
    saveDb();
    return true;
  },

  // AI Recommendations
  getRecommendationsByUserId(userId: number) {
    return db.AIRecommendations.filter(r => r.UserID === userId).sort((a,b) => b.CreatedAt.localeCompare(a.CreatedAt));
  },
  createRecommendation(rec: Partial<AIRecommendation> & { UserID: number }) {
    const nextId = db.AIRecommendations.reduce((max, r) => r.RecommendationID > max ? r.RecommendationID : max, 0) + 1;
    const newRec: AIRecommendation = {
      RecommendationID: nextId,
      UserID: rec.UserID,
      PainID: rec.PainID ?? null,
      Recommendation: rec.Recommendation || '',
      RiskLevel: rec.RiskLevel || 'Low',
      CreatedAt: new Date().toISOString()
    };
    db.AIRecommendations.push(newRec);
    saveDb();
    return newRec;
  },
  deleteRecommendation(id: number) {
    db.AIRecommendations = db.AIRecommendations.filter(r => r.RecommendationID !== id);
    saveDb();
    return true;
  },

  // Chat History
  getChatHistoryByUserId(userId: number) {
    return db.ChatHistory.filter(ch => ch.UserID === userId).sort((a,b) => a.Timestamp.localeCompare(b.Timestamp));
  },
  addChatMessage(userId: number, question: string, response: string) {
    const nextId = db.ChatHistory.reduce((max, ch) => ch.ChatID > max ? ch.ChatID : max, 0) + 1;
    const newMessage: ChatMessage = {
      ChatID: nextId,
      UserID: userId,
      Question: question,
      Response: response,
      Timestamp: new Date().toISOString()
    };
    db.ChatHistory.push(newMessage);
    saveDb();
    return newMessage;
  },

  // Notifications
  getNotificationsByUserId(userId: number) {
    return db.Notifications.filter(n => n.UserID === userId || n.UserID === null)
      .map(n => ({ ...n, IsRead: n.Status === 'read' }))
      .sort((a,b) => b.CreatedAt.localeCompare(a.CreatedAt));
  },
  getUnreadNotificationsCount(userId: number) {
    return db.Notifications.filter(n => (n.UserID === userId || n.UserID === null) && n.Status === 'unread').length;
  },
  createNotification(notif: Partial<Notification>) {
    const nextId = db.Notifications.reduce((max, n) => n.NotificationID > max ? n.NotificationID : max, 0) + 1;
    const newNotif: Notification = {
      NotificationID: nextId,
      UserID: notif.UserID !== undefined ? notif.UserID : null,
      Title: notif.Title || 'Alert',
      Message: notif.Message || '',
      Status: 'unread',
      IsAnnouncement: notif.IsAnnouncement || false,
      CreatedAt: new Date().toISOString()
    };
    db.Notifications.push(newNotif);
    saveDb();
    return newNotif;
  },
  markNotificationAsRead(id: number) {
    const notif = db.Notifications.find(n => n.NotificationID === id);
    if (notif) {
      notif.Status = 'read';
      saveDb();
      return true;
    }
    return false;
  },

  // Password Reset OTPs
  createPasswordReset(userId: number, otp: string) {
    const expiry = new Date();
    expiry.setMinutes(expiry.getMinutes() + 15); // 15 mins expiry
    const nextId = db.PasswordReset.reduce((max, p) => p.ResetID > max ? p.ResetID : max, 0) + 1;
    const newReset: PasswordReset = {
      ResetID: nextId,
      UserID: userId,
      OTP: otp,
      Expiry: expiry.toISOString()
    };
    db.PasswordReset.push(newReset);
    saveDb();
    return newReset;
  },
  verifyResetOTP(userId: number, otp: string) {
    const entry = db.PasswordReset.find(p => p.UserID === userId && p.OTP === otp && new Date(p.Expiry) > new Date());
    if (entry) {
      // Clear OTPs
      db.PasswordReset = db.PasswordReset.filter(p => p.UserID !== userId);
      saveDb();
      return true;
    }
    return false;
  },

  // Activity logs
  getActivityLogs() {
    return db.ActivityLog.sort((a,b) => b.Time.localeCompare(a.Time));
  },
  logActivity(userId: number | null, activity: string) {
    const nextId = db.ActivityLog.reduce((max, l) => l.LogID > max ? l.LogID : max, 0) + 1;
    const log: ActivityLog = {
      LogID: nextId,
      UserID: userId,
      Activity: activity,
      Time: new Date().toISOString()
    };
    db.ActivityLog.push(log);
    saveDb();
  },

  // Site statistics for admin
  getAdminStats() {
    const totalUsers = db.Users.filter(u => u.Role === 'user').length;
    const totalWorkouts = db.WorkoutHistory.length;
    const totalPainReports = db.PainReports.length;
    
    // Risk level distribution
    const riskLevels = { Low: 0, Medium: 0, High: 0 };
    db.Users.forEach(u => {
      if (u.Role === 'admin') return;
      // Get most recent recommendation
      const recs = db.AIRecommendations.filter(r => r.UserID === u.UserID);
      if (recs.length > 0) {
        const rL = recs[0].RiskLevel;
        if (rL === 'High') riskLevels.High++;
        else if (rL === 'Medium') riskLevels.Medium++;
        else riskLevels.Low++;
      } else {
        // Default is Low
        riskLevels.Low++;
      }
    });

    return {
      totalUsers,
      totalWorkouts,
      totalPainReports,
      riskDistribution: [
        { name: 'Low Risk', value: riskLevels.Low },
        { name: 'Medium Risk', value: riskLevels.Medium },
        { name: 'High Risk', value: riskLevels.High }
      ]
    };
  }
};
