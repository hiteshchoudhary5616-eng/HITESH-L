// Main Application Component
import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { User } from './types.js';

// Modular Sub-components
import Auth from './components/Auth.js';
import Navbar from './components/Navbar.js';
import Dashboard from './components/Dashboard.js';
import Profile from './components/Profile.js';
import Workouts from './components/Workouts.js';
import PainReports from './components/PainReports.js';
import AIAnalysis from './components/AIAnalysis.js';
import ExerciseLibrary from './components/ExerciseLibrary.js';
import Chatbot from './components/Chatbot.js';
import Notifications from './components/Notifications.js';
import AdminPanel from './components/AdminPanel.js';

export default function App() {
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('assistant_token'));
  const [user, setUser] = useState<User | null>(() => {
    const cached = localStorage.getItem('assistant_user');
    return cached ? JSON.parse(cached) : null;
  });

  const [activeTab, setActiveTab] = useState('dashboard');
  const [unreadCount, setUnreadCount] = useState(0);
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('theme') === 'dark' || 
           (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches);
  });

  // Base API endpoint proxying directly on port 3000
  const API_BASE = '/api';

  // Toggle Dark Mode Class on Root Document
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [darkMode]);

  const fetchUnreadCount = async () => {
    if (!token) return;
    try {
      const res = await fetch(`${API_BASE}/notifications`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        const unread = data.filter((n: any) => !n.IsRead).length;
        setUnreadCount(unread);
      }
    } catch (err) {
      console.error('Failed to sync notification indicators', err);
    }
  };

  useEffect(() => {
    if (token) {
      fetchUnreadCount();
      // Poll notifications every 30 seconds
      const interval = setInterval(fetchUnreadCount, 30000);
      return () => clearInterval(interval);
    }
  }, [token]);

  const handleLoginSuccess = (newToken: string, loggedInUser: User) => {
    localStorage.setItem('assistant_token', newToken);
    localStorage.setItem('assistant_user', JSON.stringify(loggedInUser));
    setToken(newToken);
    setUser(loggedInUser);
    
    // Default administrators directly to the admin panel
    if (loggedInUser.Role === 'admin') {
      setActiveTab('admin');
    } else {
      setActiveTab('dashboard');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('assistant_token');
    localStorage.removeItem('assistant_user');
    setToken(null);
    setUser(null);
    setActiveTab('dashboard');
  };

  const renderActiveViewport = () => {
    if (!token || !user) return null;

    switch (activeTab) {
      case 'dashboard':
        return (
          <Dashboard 
            apiBase={API_BASE} 
            token={token} 
            setActiveTab={setActiveTab} 
            onRefreshTrigger={fetchUnreadCount} 
          />
        );
      case 'profile':
        return <Profile apiBase={API_BASE} token={token} onProfileUpdated={fetchUnreadCount} />;
      case 'workouts':
        return <Workouts apiBase={API_BASE} token={token} onWorkoutLogged={fetchUnreadCount} />;
      case 'pain':
        return <PainReports apiBase={API_BASE} token={token} onPainLogged={fetchUnreadCount} />;
      case 'analysis':
        return <AIAnalysis apiBase={API_BASE} token={token} />;
      case 'exercises':
        return <ExerciseLibrary apiBase={API_BASE} token={token} />;
      case 'chat':
        return <Chatbot apiBase={API_BASE} token={token} />;
      case 'notifications':
        return <Notifications apiBase={API_BASE} token={token} onNotificationsRead={fetchUnreadCount} />;
      case 'admin':
        return user.Role === 'admin' ? <AdminPanel apiBase={API_BASE} token={token} /> : null;
      default:
        return <div className="text-center py-10 font-mono text-xs">Viewport tab unrecognized</div>;
    }
  };

  // 1. Unauthenticated Workspace View
  if (!token || !user) {
    return <Auth onLoginSuccess={handleLoginSuccess} apiBase={API_BASE} />;
  }

  // 2. Authenticated Application Workspace View
  return (
    <div id="application-container" className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-300">
      
      {/* Universal Top Navigation Header */}
      <Navbar 
        user={user} 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        unreadCount={unreadCount} 
        onLogout={handleLogout}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
      />

      {/* Main Responsive Body Viewport */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          id="viewport-frame"
        >
          {renderActiveViewport()}
        </motion.div>
      </main>

      {/* Global Bottom Footer (Clean system metadata) */}
      <footer className="py-6 border-t border-slate-200 dark:border-slate-850 bg-white/40 dark:bg-slate-950/40 text-center transition-all duration-300">
        <p className="text-[10px] text-slate-400 dark:text-slate-500 font-mono">
          AI Injury Prevention Assistant • Academic Capstone Portfolio • Node v22 Environment
        </p>
      </footer>
    </div>
  );
}
