// AI Analysis Sub-Component (Module 5)
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, ShieldAlert, CheckCircle, Clock, RotateCcw, 
  RefreshCw, Stethoscope, ArrowRight, Dumbbell, Calendar, Heart 
} from 'lucide-react';
import { 
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, 
  BarChart, Bar, Cell, CartesianGrid 
} from 'recharts';
import { AIRecommendation } from '../types.js';

interface AIAnalysisProps {
  apiBase: string;
  token: string;
}

interface ParsedRecommendation {
  riskLevel: 'Low' | 'Medium' | 'High';
  riskScore: number;
  factors: string[];
  saferAlternatives: string[];
  rehabTips: string[];
  explanation: string;
}

export default function AIAnalysis({ apiBase, token }: AIAnalysisProps) {
  const [history, setHistory] = useState<AIRecommendation[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeAnalysis, setActiveAnalysis] = useState<ParsedRecommendation | null>(null);

  // Sync historical diagnostics
  const fetchAnalysisHistory = async () => {
    try {
      const res = await fetch(`${apiBase}/ai/history`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!res.ok) throw new Error('Failed to load analysis history.');
      const data = await res.json();
      setHistory(data);

      // Set the latest analysis as active if available
      if (data.length > 0) {
        parseAndSetActive(data[0].Recommendation);
      }
    } catch (err: any) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchAnalysisHistory();
  }, [token]);

  // Safely parse JSON strings from stored model responses
  const parseAndSetActive = (recStr: string) => {
    try {
      // It's saved as a JSON-string in server-side dbService
      const parsed: any = JSON.parse(recStr);
      
      const mapped: ParsedRecommendation = {
        riskLevel: parsed.riskLevel || 'Medium',
        riskScore: Number(parsed.riskScore) || (parsed.riskLevel === 'High' ? 25 : parsed.riskLevel === 'Medium' ? 15 : 5),
        factors: Array.isArray(parsed.factors) ? parsed.factors : (Array.isArray(parsed.causes) ? parsed.causes : []),
        saferAlternatives: Array.isArray(parsed.saferAlternatives) ? parsed.saferAlternatives : [],
        rehabTips: Array.isArray(parsed.rehabTips) ? parsed.rehabTips : (Array.isArray(parsed.recoveryAdvice) ? parsed.recoveryAdvice : (Array.isArray(parsed.recommendations) ? parsed.recommendations : [])),
        explanation: parsed.explanation || parsed.riskExplanation || String(recStr)
      };
      setActiveAnalysis(mapped);
    } catch (err) {
      // Handle potential raw strings fallback
      setActiveAnalysis({
        riskLevel: 'Medium',
        riskScore: 15,
        factors: ['Kinetic volume tracking', 'Unbalanced movement load'],
        saferAlternatives: ['Chest stretch', 'Light dumbbells accessory work'],
        rehabTips: ['Warm up thoroughly', 'Maintain 2 rest days per week'],
        explanation: recStr
      });
    }
  };

  const handleRunAnalysis = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`${apiBase}/ai/analyze`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || 'Server biomechanical analysis error.');
      }
      const data: AIRecommendation = await res.json();
      
      // Update history and parse active result
      parseAndSetActive(data.Recommendation);
      fetchAnalysisHistory();
    } catch (err: any) {
      setError(err.message || 'AI diagnostic evaluation timed out. Please check your logs.');
    } finally {
      setLoading(false);
    }
  };

  const getRiskThemeStyles = (level: string) => {
    switch(level) {
      case 'High': return 'border-rose-500/25 bg-rose-50/50 dark:bg-rose-950/25 text-rose-800 dark:text-rose-400';
      case 'Medium': return 'border-amber-500/25 bg-amber-50/50 dark:bg-amber-950/25 text-amber-800 dark:text-amber-400';
      default: return 'border-emerald-500/25 bg-emerald-50/50 dark:bg-emerald-950/25 text-emerald-800 dark:text-emerald-400';
    }
  };

  // Render-time calculation of charts data
  const trendData = history.length > 0 
    ? [...history].reverse().map((h, idx) => {
        let score = 5;
        try {
          const p = JSON.parse(h.Recommendation);
          score = Number(p.riskScore) || (h.RiskLevel === 'High' ? 25 : h.RiskLevel === 'Medium' ? 15 : 5);
        } catch {
          score = h.RiskLevel === 'High' ? 25 : h.RiskLevel === 'Medium' ? 15 : 5;
        }
        return { name: `Scan #${idx + 1}`, Score: score };
      })
    : [
        { name: 'Baseline', Score: 5 },
        { name: 'Scan #1', Score: 12 }
      ];

  const factorChartData = activeAnalysis 
    ? activeAnalysis.factors.map((f, i) => {
        let contribution = 3;
        const numMatch = f.match(/\d+/);
        if (numMatch) {
          contribution = Math.min(Number(numMatch[0]), 10);
        } else if (f.toLowerCase().includes('high') || f.toLowerCase().includes('sharp')) {
          contribution = 8;
        } else if (f.toLowerCase().includes('overtraining') || f.toLowerCase().includes('fatigue')) {
          contribution = 6;
        } else {
          contribution = Math.max(7 - i * 2, 2);
        }
        return {
          Factor: f.length > 25 ? f.substring(0, 22) + '...' : f,
          'Risk Contribution': contribution
        };
      })
    : [];

  return (
    <div id="ai-analysis-root" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      
      {/* Central Diagnostic Hub (Left 2 Columns) */}
      <div className="lg:col-span-2 space-y-6">
        
        {/* Trigger Header banner */}
        <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl p-6 shadow-sm transition-all">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-indigo-500" />
                AI Biomechanical Safety Engine
              </h2>
              <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
                Synthesize active workout volumes and joint indicators using Gemini API to diagnose mechanical hazards.
              </p>
            </div>
            <button
              id="trigger-ai-scan-btn"
              onClick={handleRunAnalysis}
              disabled={loading}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-all shadow-lg shadow-indigo-500/10 flex items-center gap-2 disabled:opacity-50"
            >
              {loading ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  Synthesizing Logs...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  Run AI Injury Scan
                </>
              )}
            </button>
          </div>

          {/* Academic Medical Disclaimer Banner (STRICT specification) */}
          <div id="medical-disclaimer-banner" className="mt-5 p-4 bg-slate-50 dark:bg-slate-900/60 border border-slate-200/50 rounded-xl flex gap-2.5 items-start">
            <Stethoscope className="h-5 w-5 text-slate-500 dark:text-slate-400 shrink-0 mt-0.5" />
            <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-normal font-medium">
              <strong className="text-slate-700 dark:text-slate-300 uppercase block tracking-wider mb-0.5 text-[9px]">
                Educational Simulating Disclosure
              </strong>
              This application and its biomechanical injury risk outputs are designed solely for academic evaluation, research testing, and capstone demonstration. All recommendations generated, whether by rule-based algorithm or external LLM, represent mock simulated athletic guidance and do not constitute clinical diagnostics, physical therapy prescriptions, or standard medical advice. Consult a sports therapist or physician before acting on injury warnings.
            </p>
          </div>
        </div>

        {error && (
          <div id="ai-alert-error" className="p-3.5 bg-rose-50 dark:bg-rose-950/20 border border-rose-200/50 dark:border-rose-900/30 rounded-xl text-rose-600 dark:text-rose-400 text-xs flex gap-2">
            <ShieldAlert className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {/* Structured Results Display */}
        <AnimatePresence mode="wait">
          {activeAnalysis ? (
            <motion.div
              id="ai-results-wrapper"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="space-y-6"
            >
              
              {/* Card 1: Risk Level Assessment Overview */}
              <div id="ai-risk-overview-card" className={`border p-6 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 transition-all ${getRiskThemeStyles(activeAnalysis.riskLevel)}`}>
                <div>
                  <span className="text-[10px] font-mono font-bold uppercase tracking-widest block mb-0.5">Biomechanical Diagnostic Status</span>
                  <h3 className="text-xl font-bold">Estimated Risk Level: {activeAnalysis.riskLevel}</h3>
                  <p className="text-xs mt-1 max-w-lg opacity-85 leading-relaxed">
                    {activeAnalysis.explanation}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-3xl font-extrabold font-mono block leading-none">{activeAnalysis.riskScore}</span>
                  <span className="text-[9px] font-mono font-bold uppercase tracking-wider">Kinetic Strain Units</span>
                </div>
              </div>

              {/* Charts Grid Block: Historical Timeline & Stress Contributions */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Historical risk timeline line chart */}
                <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-5 rounded-2xl shadow-sm">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3 flex items-center gap-1.5">
                    <Clock className="h-4 w-4 text-indigo-500" />
                    Injury Risk Score Timeline
                  </h4>
                  <div className="h-48 w-full text-[10px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={trendData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" className="dark:stroke-slate-900" />
                        <XAxis dataKey="name" stroke="#94a3b8" fontSize={9} tickLine={false} />
                        <YAxis stroke="#94a3b8" fontSize={9} domain={[0, 30]} tickLine={false} />
                        <Tooltip 
                          contentStyle={{ 
                            background: '#1f2937', 
                            border: 'none', 
                            borderRadius: '8px', 
                            color: '#fff',
                            fontSize: '11px' 
                          }} 
                        />
                        <Line 
                          type="monotone" 
                          dataKey="Score" 
                          stroke="#6366f1" 
                          strokeWidth={2.5} 
                          activeDot={{ r: 6 }} 
                          dot={{ r: 4, strokeWidth: 1 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-2 text-center">
                    Visual progression of compiled biomechanical stress scores. Lower scores mean safer lifting.
                  </p>
                </div>

                {/* Risk Factors Breakdown bar chart */}
                <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-5 rounded-2xl shadow-sm">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3 flex items-center gap-1.5">
                    <ShieldAlert className="h-4 w-4 text-rose-500" />
                    Risk Contribution Breakdown
                  </h4>
                  <div className="h-48 w-full text-[10px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={factorChartData} layout="vertical" margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" className="dark:stroke-slate-900" />
                        <XAxis type="number" stroke="#94a3b8" fontSize={9} domain={[0, 10]} tickLine={false} />
                        <YAxis dataKey="Factor" type="category" stroke="#94a3b8" fontSize={9} width={100} tickLine={false} />
                        <Tooltip 
                          contentStyle={{ 
                            background: '#1f2937', 
                            border: 'none', 
                            borderRadius: '8px', 
                            color: '#fff',
                            fontSize: '11px' 
                          }} 
                        />
                        <Bar dataKey="Risk Contribution" radius={[0, 4, 4, 0]} barSize={10}>
                          {factorChartData.map((entry, idx) => {
                            const val = entry['Risk Contribution'];
                            const color = val >= 7 ? '#f43f5e' : val >= 5 ? '#f59e0b' : '#6366f1';
                            return <Cell key={`cell-${idx}`} fill={color} />;
                          })}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-2 text-center">
                    Biomechanical and volume parameters weight comparison (capped at 10 units).
                  </p>
                </div>

              </div>

              {/* Card 2: Factors, Alternatives, & Rehab Split */}
              <div id="ai-analysis-details" className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                
                {/* Safe Exercise Alternatives */}
                <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-5 rounded-2xl shadow-sm">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3 flex items-center gap-1.5">
                    <Dumbbell className="h-4 w-4 text-indigo-500" />
                    Recommended Safe Alternatives
                  </h4>
                  <ul className="space-y-2 text-xs">
                    {activeAnalysis.saferAlternatives.map((alt, i) => (
                      <li key={i} className="flex gap-2 items-start text-slate-700 dark:text-slate-300 font-medium">
                        <CheckCircle className="h-4 w-4 text-indigo-500 shrink-0 mt-0.5" />
                        <span>{alt}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Rehabilitation & Active Recovery tips */}
                <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-5 rounded-2xl shadow-sm">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3 flex items-center gap-1.5">
                    <Heart className="h-4 w-4 text-rose-500" />
                    Recovery & Joint Loading Protocols
                  </h4>
                  <ul className="space-y-2 text-xs">
                    {activeAnalysis.rehabTips.map((tip, i) => (
                      <li key={i} className="flex gap-2 items-start text-slate-700 dark:text-slate-300">
                        <ArrowRight className="h-4 w-4 text-rose-500 shrink-0 mt-0.5" />
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>

              </div>

              {/* Primary Biomechanical Contributory Factors list */}
              <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-5 rounded-2xl shadow-sm">
                <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">Target Mechanical Stress Factors</h4>
                <div className="flex flex-wrap gap-2">
                  {activeAnalysis.factors.map((fac, i) => (
                    <span key={i} className="px-2.5 py-1 bg-slate-100 dark:bg-slate-900 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-400">
                      {fac}
                    </span>
                  ))}
                </div>
              </div>

            </motion.div>
          ) : (
            <div id="ai-blankslate" className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl p-12 text-center shadow-sm">
              <Sparkles className="h-10 w-10 text-indigo-300 dark:text-indigo-700 mx-auto mb-3 animate-pulse" />
              <h3 className="text-base font-bold text-slate-900 dark:text-white">Pending Biomechanical Diagnostics</h3>
              <p className="text-xs text-slate-400 dark:text-slate-500 mt-1 max-w-sm mx-auto leading-relaxed">
                No safety analysis report generated yet. Click "Run AI Injury Scan" above to compile your physical measurements, load ratios, and active joint pain records.
              </p>
            </div>
          )}
        </AnimatePresence>

      </div>

      {/* Historical Diagnostics Archive (Right Column) */}
      <div className="lg:col-span-1 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-5 rounded-2xl shadow-sm h-fit">
        <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-4 flex items-center gap-1.5">
          <Clock className="h-4 w-4 text-slate-400" />
          Diagnostics Archive
        </h3>

        {history.length > 0 ? (
          <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
            {history.map((h, idx) => {
              const isSelected = activeAnalysis?.explanation === h.Recommendation || (h.Recommendation.startsWith('{') && activeAnalysis?.riskLevel === h.RiskLevel);
              return (
                <div
                  key={h.RecommendationID}
                  id={`history-item-${h.RecommendationID}`}
                  onClick={() => parseAndSetActive(h.Recommendation)}
                  className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                    isSelected 
                      ? 'border-indigo-500 bg-indigo-50/20' 
                      : 'border-slate-100 dark:border-slate-900 hover:bg-slate-50 dark:hover:bg-slate-900/60'
                  }`}
                >
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono">Scan #{history.length - idx}</span>
                    <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
                      h.RiskLevel === 'High' ? 'bg-rose-500/10 text-rose-500' :
                      h.RiskLevel === 'Medium' ? 'bg-amber-500/10 text-amber-500' :
                      'bg-emerald-500/10 text-emerald-500'
                    }`}>
                      {h.RiskLevel} Risk
                    </span>
                  </div>
                  <p className="text-xs text-slate-700 dark:text-slate-300 font-semibold line-clamp-2">
                    {h.Recommendation.startsWith('{') ? "Structured Joint/Muscle Alignment Advice" : h.Recommendation}
                  </p>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-xs text-slate-400 dark:text-slate-500 font-medium font-mono">Archive Empty</p>
          </div>
        )}
      </div>

    </div>
  );
}
