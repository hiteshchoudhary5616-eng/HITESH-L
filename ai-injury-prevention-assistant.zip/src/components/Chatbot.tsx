// AI Coach Chatbot Sub-Component (Module 8)
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MessageSquare, Send, Sparkles, RefreshCw, HelpCircle, 
  User as UserIcon, Bot, Stethoscope, AlertTriangle 
} from 'lucide-react';
import { ChatMessage } from '../types.js';

interface ChatbotProps {
  apiBase: string;
  token: string;
}

export default function Chatbot({ apiBase, token }: ChatbotProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const starterQuestions = [
    "What exercises are safe to train with shoulder pain?",
    "How can I prevent lower back tightness during squats?",
    "Am I training with too much weekly volume?",
    "Suggest a dynamic warm-up for tight hips."
  ];

  const [sendingQuestion, setSendingQuestion] = useState<string | null>(null);

  const fetchChatHistory = async () => {
    try {
      const res = await fetch(`${apiBase}/chat/history`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!res.ok) throw new Error('Failed to load chat history.');
      const data = await res.json();
      setMessages(data);
    } catch (err: any) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchChatHistory();
  }, [token]);

  // Auto scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading, sendingQuestion]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || loading) return;

    setInputText('');
    setSendingQuestion(textToSend);
    setLoading(true);
    setError(null);

    try {
      const res = await fetch(`${apiBase}/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ question: textToSend })
      });

      if (!res.ok) throw new Error('API chatbot failed to respond.');
      
      const serverMsg: ChatMessage = await res.json();
      setSendingQuestion(null);
      fetchChatHistory();
    } catch (err: any) {
      setError(err.message || 'Chatbot processing timed out. Please retry.');
      setSendingQuestion(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="chatbot-root" className="grid grid-cols-1 lg:grid-cols-4 gap-6 min-h-[68vh] max-h-[78vh]">
      
      {/* Side Quick Templates Panel (Hidden on Mobile) */}
      <div className="hidden lg:flex flex-col justify-between bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-5 rounded-2xl shadow-sm">
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Bot className="h-5 w-5 text-indigo-500" />
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">AI Coaching Prompt Templates</h3>
          </div>
          <p className="text-[11px] text-slate-400 dark:text-slate-500 leading-relaxed">
            Click any kinetic question below to analyze your historical logs and joint discomfort indices automatically.
          </p>

          <div id="starter-prompts-list" className="space-y-2.5">
            {starterQuestions.map((q, i) => (
              <button
                key={i}
                id={`starter-q-${i}`}
                onClick={() => handleSendMessage(q)}
                disabled={loading}
                className="w-full p-2.5 text-left bg-slate-50 hover:bg-slate-100 dark:bg-slate-900 dark:hover:bg-slate-850 border border-slate-200/50 dark:border-slate-800 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 transition-colors leading-normal"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* Dynamic Warning Alert */}
        <div className="p-3.5 bg-indigo-50/50 dark:bg-indigo-950/25 border border-indigo-200/40 rounded-xl text-[10px] text-slate-500 dark:text-slate-400 leading-tight">
          <strong>Interactive Context:</strong> Your logged load intensities, volume spikes, and joint stiffness ratings are automatically submitted as hidden diagnostic variables with each chat request.
        </div>
      </div>

      {/* Primary Message Stream (Left 3 Columns) */}
      <div className="lg:col-span-3 flex flex-col bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl shadow-sm overflow-hidden h-[68vh]">
        
        {/* Chat Stream Header */}
        <div className="px-5 py-3 border-b border-slate-150 dark:border-slate-850 bg-slate-50/60 dark:bg-slate-900/60 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-indigo-600 rounded-lg text-white">
              <MessageSquare className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">AI Injury Prevention Coach</h3>
              <p className="text-[10px] text-slate-400">Context-Aware Conversational Assistant</p>
            </div>
          </div>
        </div>

        {/* Academic Medical Disclaimer display (Strict specification) */}
        <div id="chat-educational-disclaimer" className="p-3 bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200/40 text-[9px] text-slate-500 dark:text-slate-400 flex gap-2 items-start">
          <Stethoscope className="h-4 w-4 text-slate-400 shrink-0" />
          <span>
            <strong>Academic Disclosure:</strong> This chatbot provides simulated coaching for educational purposes under a capstone scope. Always consult professional healthcare practitioners for clinical concerns.
          </span>
        </div>

        {/* Messages List Area */}
        <div id="messages-container" className="flex-1 overflow-y-auto p-5 space-y-4">
          
          {/* Welcome greeting */}
          <div className="flex gap-3 max-w-[85%] text-left">
            <div className="h-8 w-8 rounded-full bg-indigo-100 dark:bg-indigo-950/50 flex items-center justify-center text-indigo-600 dark:text-indigo-400 shrink-0">
              <Bot className="h-4 w-4" />
            </div>
            <div className="p-3 bg-slate-100 dark:bg-slate-900/60 rounded-2xl rounded-tl-none">
              <p className="text-xs text-slate-800 dark:text-slate-300 leading-relaxed font-medium">
                Hello! I am your AI Biomechanical Coach. Ask me about training safely, repairing range of motion limitations, or choosing exercises that spare your joints. How are you feeling today?
              </p>
            </div>
          </div>

          {messages.map((m) => {
            return (
              <React.Fragment key={m.ChatID}>
                {/* User Message */}
                <div className="flex gap-3 max-w-[85%] text-left ml-auto flex-row-reverse">
                  <div className="h-8 w-8 rounded-full bg-indigo-600 text-white shadow-md shadow-indigo-500/10 flex items-center justify-center shrink-0">
                    <UserIcon className="h-4 w-4" />
                  </div>
                  <div className="p-3.5 rounded-2xl shadow-sm bg-indigo-600 rounded-tr-none text-white">
                    <p className="text-xs leading-relaxed font-sans whitespace-pre-wrap">
                      {m.Question}
                    </p>
                    <span className="text-[9px] block text-right mt-1.5 opacity-65 font-mono text-indigo-200">
                      {m.Timestamp ? m.Timestamp.split('T')[1]?.substring(0, 5) || m.Timestamp : 'Just Now'}
                    </span>
                  </div>
                </div>

                {/* Bot Response */}
                <div className="flex gap-3 max-w-[85%] text-left">
                  <div className="h-8 w-8 rounded-full bg-indigo-100 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
                    <Bot className="h-4 w-4" />
                  </div>
                  <div className="p-3.5 rounded-2xl shadow-sm bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-tl-none text-slate-800 dark:text-slate-300">
                    <p className="text-xs leading-relaxed font-sans whitespace-pre-wrap">
                      {m.Response}
                    </p>
                    <span className="text-[9px] block text-right mt-1.5 opacity-65 font-mono text-slate-400">
                      {m.Timestamp ? m.Timestamp.split('T')[1]?.substring(0, 5) || m.Timestamp : 'Just Now'}
                    </span>
                  </div>
                </div>
              </React.Fragment>
            );
          })}

          {sendingQuestion && (
            <div className="flex gap-3 max-w-[85%] text-left ml-auto flex-row-reverse animate-pulse">
              <div className="h-8 w-8 rounded-full bg-indigo-600 text-white shadow-md shadow-indigo-500/10 flex items-center justify-center shrink-0">
                <UserIcon className="h-4 w-4" />
              </div>
              <div className="p-3.5 rounded-2xl shadow-sm bg-indigo-600 rounded-tr-none text-white">
                <p className="text-xs leading-relaxed font-sans whitespace-pre-wrap">
                  {sendingQuestion}
                </p>
              </div>
            </div>
          )}

          {loading && (
            <div className="flex gap-3 max-w-[85%] text-left">
              <div className="h-8 w-8 rounded-full bg-indigo-100 dark:bg-indigo-950/50 flex items-center justify-center text-indigo-600 dark:text-indigo-400 shrink-0">
                <Bot className="h-4 w-4" />
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-2xl rounded-tl-none border border-slate-100 dark:border-slate-850 flex items-center gap-2">
                <RefreshCw className="h-3.5 w-3.5 text-indigo-500 animate-spin" />
                <span className="text-[10px] text-slate-400 font-mono">Coach is formulating recovery tips...</span>
              </div>
            </div>
          )}

          {error && (
            <div className="p-3.5 bg-rose-50 dark:bg-rose-950/20 border border-rose-200/50 rounded-xl text-rose-600 text-xs flex gap-2 max-w-lg mx-auto">
              <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar form */}
        <form 
          id="chat-input-form"
          onSubmit={(e) => { e.preventDefault(); handleSendMessage(inputText); }}
          className="p-4 border-t border-slate-150 dark:border-slate-850 bg-slate-50/40 dark:bg-slate-900/40 flex gap-2"
        >
          <input 
            id="chat-text-input"
            type="text" 
            placeholder="Ask your coach anything about exercise mechanics..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            disabled={loading}
            className="flex-1 px-4 py-2.5 rounded-lg border border-slate-200 dark:border-slate-850 bg-white dark:bg-slate-950 text-slate-900 dark:text-white text-xs focus:outline-none focus:border-indigo-500"
            required
          />
          <button
            id="chat-submit-btn"
            type="submit"
            disabled={loading || !inputText.trim()}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors shadow-md shadow-indigo-500/10 flex items-center justify-center disabled:opacity-50"
          >
            <Send className="h-4 w-4" />
          </button>
        </form>

      </div>

    </div>
  );
}
