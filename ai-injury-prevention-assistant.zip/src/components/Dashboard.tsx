// Dashboard Sub-Component (Module 9)
import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { 
  Activity, Dumbbell, Heart, AlertTriangle, Sparkles, Bell, 
  Calendar, Award, TrendingUp, RefreshCw, HelpCircle, ArrowRight 
} from 'lucide-react';
import { 
  BarChart, Bar, LineChart, Line, ResponsiveContainer, XAxis, YAxis, 
  Tooltip, CartesianGrid, Legend, RadialBarChart, RadialBar 
} from 'recharts';
import { DashboardPayload } from '../types.js';

interface DashboardProps {
  apiBase: string;
  token: string;
  setActiveTab: (tab: string) => void;
  onRefreshTrigger: () => void;
}

export default function Dashboard({ apiBase, token, setActiveTab, onRefreshTrigger }: DashboardProps) {
  const [data, setData] = useState<DashboardPayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tipIndex, setTipIndex] = useState(0);

  const healthTips = [
    "Balance your training: Aim for a 2:1 ratio of pulling movements (rows, pull-ups) to pressing movements (bench press) to maintain posture and secure rotator cuffs.",
    "Prioritize dynamic mobility: Spend 5-10 minutes warming up the target joint capsule using resistance bands and rotational control before adding heavy loads.",
    "Listen to biological signals: Muscle burning represents safe metabolic stress, but sharp, joint-specific pinching is a critical warning. Stop immediately.",
    "The 10% rule: Limit sudden training spikes by increasing your total active weekly volume by no more than 10% week-over-week.",
    "Recovery is active building: Tendons and ligaments adapt slower than muscles and require adequate hydration, sleep, and 1-2 designated rest days weekly."
  ];

  const fetchDashboardData = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`${apiBase}/dashboard`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (!res.ok) {
        throw new Error('Failed to download dashboard data.');
      }
      const payload = await res.json();
      setData(payload);
    } catch (err: any) {
      setError(err.message || 'Server data retrieval error.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
    // Rotate tips every 15 seconds
    const interval = setInterval(() => {
      setTipIndex(prev => (prev + 1) % healthTips.length);
    }, 15000);
    return () => clearInterval(interval);
  }, [token]);

  if (loading) {
    return (
      <div id="dashboard-loading" className="min-h-[70vh] flex flex-col items-center justify-center">
        <RefreshCw className="h-10 w-10 text-indigo-600 dark:text-indigo-400 animate-spin mb-4" />
        <p className="text-sm font-semibold text-slate-500 dark:text-slate-400">Loading your safety metrics...</p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div id="dashboard-error" className="min-h-[70vh] flex flex-col items-center justify-center p-6 text-center">
        <AlertTriangle className="h-12 w-12 text-rose-500 mb-4" />
        <h3 className="text-lg font-bold text-slate-900 dark:text-white">Failed to load Dashboard</h3>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-md">{error || 'An error occurred fetching metrics'}</p>
        <button 
          onClick={fetchDashboardData}
          className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold transition-all"
        >
          Try Again
        </button>
      </div>
    );
  }

  const {
    user,
    profile,
    recentWorkouts,
    recentPainReports,
    riskAssessment,
    recentRecommendations,
    unreadNotificationsCount,
    weeklyVolumeData,
    muscleDistributionData,
    painTrendData
  } = data;

  // Format risk gauge color styles
  const getRiskColor = (level: string) => {
    switch(level) {
      case 'High': return { bg: 'bg-rose-500/10', text: 'text-rose-600 dark:text-rose-400', border: 'border-rose-500/20', circle: '#ef4444' };
      case 'Medium': return { bg: 'bg-amber-500/10', text: 'text-amber-600 dark:text-amber-400', border: 'border-amber-500/20', circle: '#f59e0b' };
      default: return { bg: 'bg-emerald-500/10', text: 'text-emerald-600 dark:text-emerald-400', border: 'border-emerald-500/20', circle: '#10b981' };
    }
  };

  const riskTheme = getRiskColor(riskAssessment.level);

  // Radial chart formatting
  const radialData = [
    { name: 'Risk', value: riskAssessment.score, fill: riskTheme.circle }
  ];

  return (
    <div id="dashboard-root" className="space-y-6">
      
      {/* Welcome Hero / Header */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 bg-gradient-to-r from-indigo-50 to-slate-50 dark:from-slate-900 dark:to-slate-950 p-6 rounded-2xl border border-slate-200/50 dark:border-slate-800/50 transition-all duration-300">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            Welcome back, {user.Name}! <Award className="h-6 w-6 text-indigo-500 animate-bounce" />
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {profile 
              ? `${profile.Experience} Lifter • Goal: ${profile.Goal} • BMI: ${profile.BMI}` 
              : "Complete your fitness profile to enable fully personalized biomechanical risk scoring!"}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button 
            id="dash-refresh-btn"
            onClick={() => { fetchDashboardData(); onRefreshTrigger(); }}
            className="p-2 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-600 dark:text-slate-400 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Sync Logs
          </button>
          {!profile && (
            <button 
              id="dash-complete-profile-btn"
              onClick={() => setActiveTab('profile')}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-all shadow-lg shadow-indigo-500/10 flex items-center gap-1"
            >
              Fill Profile
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Dynamic Health Advisor Slider */}
      <div id="rotating-tips-banner" className="bg-white dark:bg-slate-950 border border-indigo-100 dark:border-indigo-950/40 rounded-xl p-4 flex gap-3 items-start shadow-sm transition-all">
        <div className="p-2 bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 rounded-lg shrink-0">
          <Sparkles className="h-4 w-4 animate-pulse" />
        </div>
        <div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 font-mono block mb-0.5">
            AI Coach Health Tips
          </span>
          <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
            {healthTips[tipIndex]}
          </p>
        </div>
      </div>

      {/* Main Aggregated Widgets Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        
        {/* Widget 1: Injury Risk Score Gauge */}
        <div id="risk-score-widget" className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-5 rounded-2xl flex flex-col justify-between shadow-sm transition-all duration-300">
          <div className="flex justify-between items-start mb-2">
            <div>
              <span className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">Current Injury Risk</span>
              <h3 className="text-xl font-bold text-slate-950 dark:text-white mt-0.5">Biomechanical Rating</h3>
            </div>
            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${riskTheme.bg} ${riskTheme.text} border ${riskTheme.border}`}>
              {riskAssessment.level} Risk
            </span>
          </div>

          <div className="flex justify-center my-1 relative h-28">
            {/* Radial score indicator representing a simplified gauge */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className={`text-3xl font-extrabold ${riskTheme.text} font-mono`}>{riskAssessment.score}</span>
              <span className="text-[10px] text-slate-400 dark:text-slate-500 font-medium">Safety Units</span>
            </div>
            <ResponsiveContainer width="100%" height="100%">
              <RadialBarChart 
                cx="50%" 
                cy="50%" 
                innerRadius="65%" 
                outerRadius="90%" 
                barSize={10} 
                data={radialData} 
                startAngle={180} 
                endAngle={-180}
              >
                <RadialBar 
                  background={{ fill: '#e2e8f0' }} 
                  dataKey="value" 
                  cornerRadius={5}
                />
              </RadialBarChart>
            </ResponsiveContainer>
          </div>

          <p className="text-[11px] text-slate-400 dark:text-slate-500 leading-tight text-center italic mt-1">
            "Based on consecutive training loads, joint pain markers, and experience levels."
          </p>
        </div>

        {/* Widget 2: Weekly Workouts */}
        <div id="workouts-count-widget" className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-5 rounded-2xl flex flex-col justify-between shadow-sm transition-all duration-300">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">Workouts Tracked</span>
              <h3 className="text-xl font-bold text-slate-950 dark:text-white mt-0.5">This Week</h3>
            </div>
            <div className="p-2 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 rounded-lg">
              <Dumbbell className="h-5 w-5" />
            </div>
          </div>
          
          <div className="my-4">
            <span className="text-4xl font-extrabold text-slate-900 dark:text-white font-mono">
              {recentWorkouts.length}
            </span>
            <span className="text-xs text-slate-400 dark:text-slate-500 ml-1.5 font-medium">sessions logged</span>
            <div className="h-1 w-full bg-slate-100 dark:bg-slate-800 rounded-full mt-3 overflow-hidden">
              <div 
                className="h-full bg-indigo-600 dark:bg-indigo-500 rounded-full" 
                style={{ width: `${Math.min((recentWorkouts.length / 5) * 100, 100)}%` }}
              ></div>
            </div>
          </div>

          <button 
            id="dash-add-workout-btn"
            onClick={() => setActiveTab('workouts')}
            className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline font-bold text-left flex items-center gap-1 mt-1"
          >
            Log another workout
            <ArrowRight className="h-3 w-3" />
          </button>
        </div>

        {/* Widget 3: Recent Pain Log */}
        <div id="pain-status-widget" className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-5 rounded-2xl flex flex-col justify-between shadow-sm transition-all duration-300">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">Pain Markers</span>
              <h3 className="text-xl font-bold text-slate-950 dark:text-white mt-0.5">Active Reports</h3>
            </div>
            <div className="p-2 bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 rounded-lg">
              <Heart className="h-5 w-5" />
            </div>
          </div>

          <div className="my-4">
            {recentPainReports.length > 0 ? (
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-3xl font-extrabold text-slate-900 dark:text-white font-mono">
                    {recentPainReports[0].PainLevel}/10
                  </span>
                  <span className="text-xs font-bold text-rose-600 dark:text-rose-400 px-1.5 py-0.5 bg-rose-50 dark:bg-rose-950/40 rounded border border-rose-100 dark:border-rose-950">
                    {recentPainReports[0].BodyPart}
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-full truncate">
                  Triggered by: {recentPainReports[0].Exercise || 'None'}
                </p>
              </div>
            ) : (
              <div>
                <span className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 block">
                  All Systems Clear
                </span>
                <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
                  No active joint pain reports logged. Keep training safely!
                </p>
              </div>
            )}
          </div>

          <button 
            id="dash-add-pain-btn"
            onClick={() => setActiveTab('pain')}
            className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline font-bold text-left flex items-center gap-1 mt-1"
          >
            Update pain logs
            <ArrowRight className="h-3 w-3" />
          </button>
        </div>

        {/* Widget 4: Quick AI Diagnostics Status */}
        <div id="ai-recs-widget" className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-5 rounded-2xl flex flex-col justify-between shadow-sm transition-all duration-300">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">AI Safety Advisor</span>
              <h3 className="text-xl font-bold text-slate-950 dark:text-white mt-0.5">Recommendations</h3>
            </div>
            <div className="p-2 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 rounded-lg">
              <Sparkles className="h-5 w-5" />
            </div>
          </div>

          <div className="my-4">
            {recentRecommendations.length > 0 ? (
              <div>
                <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/30 px-2 py-0.5 rounded uppercase">
                  Latest Advice Generated
                </span>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1.5 line-clamp-2 italic leading-normal">
                  {recentRecommendations[0].RiskLevel === 'Low' || recentRecommendations[0].Recommendation.startsWith('{') 
                    ? "Safe alternatives and biomechanical analysis stored." 
                    : recentRecommendations[0].Recommendation}
                </p>
              </div>
            ) : (
              <div>
                <span className="text-xs font-bold text-slate-400 dark:text-slate-500 block uppercase">
                  Pending Execution
                </span>
                <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
                  Run an AI analysis scan to diagnose active muscle/joint issues.
                </p>
              </div>
            )}
          </div>

          <button 
            id="dash-run-ai-btn"
            onClick={() => setActiveTab('analysis')}
            className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline font-bold text-left flex items-center gap-1 mt-1"
          >
            Run safety analysis
            <ArrowRight className="h-3 w-3" />
          </button>
        </div>

      </div>

      {/* Charts Section - Two Column Bento Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Chart 1: Weekly Workout Volume */}
        <div id="weekly-volume-chart-card" className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-5 rounded-2xl shadow-sm transition-all duration-300">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h4 className="text-base font-bold text-slate-900 dark:text-white">Weekly Workout Volume Trend</h4>
              <p className="text-xs text-slate-400 dark:text-slate-500 mt-0.5">Calculated as: Weight × Sets × Reps logged daily</p>
            </div>
            <TrendingUp className="h-4 w-4 text-indigo-500" />
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyVolumeData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" className="dark:hidden" />
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" className="hidden dark:block" />
                <XAxis dataKey="day" tick={{ fontSize: 10, fill: '#64748b' }} />
                <YAxis tick={{ fontSize: 10, fill: '#64748b' }} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(255, 255, 255, 0.95)', 
                    borderColor: '#cbd5e1',
                    borderRadius: '8px',
                    fontSize: '11px',
                    color: '#0f172a'
                  }}
                />
                <Bar dataKey="volume" fill="#4f46e5" radius={[4, 4, 0, 0]} name="Total Volume (kg)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Pain Level Index Over Time */}
        <div id="pain-trend-chart-card" className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-5 rounded-2xl shadow-sm transition-all duration-300">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h4 className="text-base font-bold text-slate-900 dark:text-white">Pain Indicator Over Time</h4>
              <p className="text-xs text-slate-400 dark:text-slate-500 mt-0.5">Tracks chronological fluctuations in logged discomfort</p>
            </div>
            <Heart className="h-4 w-4 text-rose-500" />
          </div>
          <div className="h-64 w-full">
            {painTrendData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={painTrendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" className="dark:hidden" />
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" className="hidden dark:block" />
                  <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#64748b' }} />
                  <YAxis domain={[0, 10]} ticks={[0, 2, 4, 6, 8, 10]} tick={{ fontSize: 10, fill: '#64748b' }} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'rgba(255, 255, 255, 0.95)', 
                      borderColor: '#cbd5e1',
                      borderRadius: '8px',
                      fontSize: '11px',
                      color: '#0f172a'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="level" 
                    stroke="#f43f5e" 
                    strokeWidth={2.5} 
                    dot={{ r: 4 }} 
                    activeDot={{ r: 6 }} 
                    name="Pain Intensity" 
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex flex-col items-center justify-center border border-dashed border-slate-200 dark:border-slate-800 rounded-xl bg-slate-50/50 dark:bg-slate-950/40 text-center p-6">
                <HelpCircle className="h-8 w-8 text-slate-300 dark:text-slate-700 mb-2" />
                <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">No discomfort logs detected</p>
                <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1 max-w-xs">Logging pain reports allows us to build interactive joint trend tracking indices.</p>
              </div>
            )}
          </div>
        </div>

      </div>

      {/* Notifications & Recent Exercises Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Column 1: Notification Quick Feed */}
        <div id="dash-notifications-preview-card" className="lg:col-span-1 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-5 rounded-2xl shadow-sm transition-all duration-300">
          <div className="flex justify-between items-center mb-3">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <Bell className="h-4 w-4 text-indigo-500" />
              Safety Notifications
            </h4>
            {unreadNotificationsCount > 0 && (
              <span className="px-2 py-0.5 bg-rose-500 text-white rounded text-[9px] font-bold uppercase tracking-wider animate-pulse">
                {unreadNotificationsCount} Unread
              </span>
            )}
          </div>

          <p className="text-[11px] text-slate-400 dark:text-slate-500 mb-4 leading-relaxed">
            Automatic triggers alert you to recovery cycles and overreaching.
          </p>

          <button 
            id="dash-view-all-notifications-btn"
            onClick={() => setActiveTab('notifications')}
            className="w-full py-2 bg-slate-50 hover:bg-slate-100 dark:bg-slate-900 dark:hover:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-lg text-xs font-bold text-indigo-600 dark:text-indigo-400 transition-colors"
          >
            View Notification Center
          </button>
        </div>

        {/* Column 2: Recent Workout Activity Feed */}
        <div id="dash-workouts-preview-card" className="lg:col-span-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-5 rounded-2xl shadow-sm transition-all duration-300">
          <div className="flex justify-between items-center mb-4">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <Dumbbell className="h-4 w-4 text-indigo-500" />
              Recent Workout Logs
            </h4>
            <button 
              id="dash-view-workouts-history-btn"
              onClick={() => setActiveTab('workouts')}
              className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline font-bold"
            >
              Full History
            </button>
          </div>

          {recentWorkouts.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 dark:border-slate-850 text-slate-400 dark:text-slate-500 font-semibold uppercase tracking-wider">
                    <th className="pb-2">Date</th>
                    <th className="pb-2">Exercise</th>
                    <th className="pb-2">Muscle Group</th>
                    <th className="pb-2 text-right">Load</th>
                    <th className="pb-2 text-right">Reps/Sets</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-900 text-slate-700 dark:text-slate-300">
                  {recentWorkouts.map((w) => (
                    <tr key={w.WorkoutID} className="hover:bg-slate-50/50 dark:hover:bg-slate-900/40">
                      <td className="py-2.5 font-mono text-[11px]">
                        {w.WorkoutDate.split('-').slice(1).join('/')}
                      </td>
                      <td className="py-2.5 font-semibold text-slate-900 dark:text-white">{w.Exercise}</td>
                      <td className="py-2.5">
                        <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-900 rounded text-[10px]">
                          {w.MuscleGroup}
                        </span>
                      </td>
                      <td className="py-2.5 text-right font-mono font-medium">{w.Weight} kg</td>
                      <td className="py-2.5 text-right font-mono">{w.Sets} × {w.Reps}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-6 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl bg-slate-50/50 dark:bg-slate-950/40 p-4">
              <Dumbbell className="h-6 w-6 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">No workout logs recorded yet</p>
              <button 
                id="dash-add-first-workout-btn"
                onClick={() => setActiveTab('workouts')}
                className="mt-2 text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                Create your first log
              </button>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
