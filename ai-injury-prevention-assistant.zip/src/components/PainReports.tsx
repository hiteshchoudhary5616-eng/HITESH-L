// Pain Reports Sub-Component (Module 4)
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Heart, Plus, Edit2, Trash2, Calendar, AlertTriangle, 
  Sparkles, RefreshCw, HelpCircle, Activity, Stethoscope 
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { PainReport } from '../types.js';

interface PainReportsProps {
  apiBase: string;
  token: string;
  onPainLogged: () => void;
}

export default function PainReports({ apiBase, token, onPainLogged }: PainReportsProps) {
  const [reports, setReports] = useState<PainReport[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Form State
  const [bodyPart, setBodyPart] = useState('Shoulder');
  const [exercise, setExercise] = useState('');
  const [painLevel, setPainLevel] = useState<number>(3);
  const [painType, setPainType] = useState('Sharp');
  const [duration, setDuration] = useState('2 days');
  const [notes, setNotes] = useState('');
  const [reportDate, setReportDate] = useState(new Date().toISOString().split('T')[0]);

  // Modal State
  const [editingId, setEditingId] = useState<number | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);

  const fetchPainReports = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`${apiBase}/pain-reports`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!res.ok) throw new Error('Failed to retrieve pain logs.');
      const data = await res.json();
      setReports(data);
    } catch (err: any) {
      setError(err.message || 'Failed to sync with pain API.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPainReports();
  }, [token]);

  const handleOpenAddModal = () => {
    setEditingId(null);
    setBodyPart('Shoulder');
    setExercise('');
    setPainLevel(3);
    setPainType('Sharp');
    setDuration('2 days');
    setNotes('');
    setReportDate(new Date().toISOString().split('T')[0]);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (r: PainReport) => {
    setEditingId(r.PainID);
    setBodyPart(r.BodyPart);
    setExercise(r.Exercise || '');
    setPainLevel(r.PainLevel);
    setPainType(r.PainType);
    setDuration(r.Duration);
    setNotes(r.Notes || '');
    setReportDate(r.ReportDate);
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const payload = {
      bodyPart,
      exercise,
      painLevel,
      painType,
      duration,
      notes,
      reportDate
    };

    try {
      let res;
      if (editingId) {
        res = await fetch(`${apiBase}/pain-reports/${editingId}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(payload)
        });
      } else {
        res = await fetch(`${apiBase}/pain-reports`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(payload)
        });
      }

      if (!res.ok) throw new Error('Failed to write pain report to DB.');
      
      setIsModalOpen(false);
      fetchPainReports();
      onPainLogged();
    } catch (err: any) {
      setError(err.message || 'Failed to save discomfort log.');
    }
  };

  const handleDelete = async (id: number) => {
    if (deletingId !== id) {
      setDeletingId(id);
      // Auto reset confirmation state after 3 seconds
      setTimeout(() => {
        setDeletingId(curr => curr === id ? null : curr);
      }, 3000);
      return;
    }
    setDeletingId(null);
    try {
      const res = await fetch(`${apiBase}/pain-reports/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!res.ok) throw new Error('Deletion failed.');
      fetchPainReports();
      onPainLogged();
    } catch (err: any) {
      setError(err.message || 'Failed to delete discomfort record.');
    }
  };

  // Pain Level color indicator helpers
  const getPainBadgeStyles = (level: number) => {
    if (level <= 3) return 'bg-emerald-100 text-emerald-700 border-emerald-200/50 dark:bg-emerald-950/20 dark:text-emerald-400';
    if (level <= 6) return 'bg-amber-100 text-amber-700 border-amber-200/50 dark:bg-amber-950/20 dark:text-amber-400';
    return 'bg-rose-100 text-rose-700 border-rose-200/50 dark:bg-rose-950/20 dark:text-rose-400';
  };

  const getPainLevelDescription = (level: number) => {
    if (level <= 3) return { text: 'Mild discomfort - Safe to train with care', color: 'text-emerald-500 font-bold' };
    if (level <= 6) return { text: 'Moderate pain - Suggest light load or exercise alternatives', color: 'text-amber-500 font-bold' };
    return { text: 'Severe pain - Cease compound heavy movements immediately!', color: 'text-rose-500 font-extrabold' };
  };

  // Reconstruct chronological line-chart data
  const chronologicalChartData = reports
    .slice(0, 15)
    .map(p => ({
      date: p.ReportDate.split('-').slice(1).join('/'),
      Level: p.PainLevel,
      BodyPart: p.BodyPart
    }))
    .reverse();

  return (
    <div id="pain-reports-root" className="space-y-6">
      
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-6 rounded-2xl shadow-sm transition-all">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Heart className="h-5 w-5 text-rose-500 animate-pulse" />
            Active Pain & Discomfort Logs
          </h2>
          <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
            Track joint discomfort. Pain levels above 6 trigger active overreaching indicators.
          </p>
        </div>
        <button
          id="add-pain-modal-btn"
          onClick={handleOpenAddModal}
          className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold transition-all shadow-lg shadow-rose-500/10 flex items-center gap-1.5"
        >
          <Plus className="h-4 w-4" />
          Log Active Discomfort
        </button>
      </div>

      {error && (
        <div id="pain-alert-error" className="p-3 bg-rose-50 dark:bg-rose-950/20 border border-rose-200/50 dark:border-rose-900/30 rounded-xl text-rose-600 dark:text-rose-400 text-xs flex gap-2">
          <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {/* Grid of Chart + Active Warnings */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Pain Trend Chart Card */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-5 rounded-2xl shadow-sm">
          <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-4 flex items-center gap-1.5">
            <Activity className="h-4 w-4 text-rose-500" />
            Joint Pain Track Index (Chronological)
          </h3>
          <div className="h-56 w-full">
            {chronologicalChartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chronologicalChartData} margin={{ top: 5, right: 10, left: -25, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" className="dark:hidden" />
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" className="hidden dark:block" />
                  <XAxis dataKey="date" tick={{ fontSize: 9, fill: '#64748b' }} />
                  <YAxis domain={[0, 10]} ticks={[0, 2, 4, 6, 8, 10]} tick={{ fontSize: 9, fill: '#64748b' }} />
                  <Tooltip contentStyle={{ fontSize: '10px' }} />
                  <Line 
                    type="monotone" 
                    dataKey="Level" 
                    stroke="#f43f5e" 
                    strokeWidth={2.5} 
                    dot={{ r: 4 }} 
                    activeDot={{ r: 6 }} 
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex flex-col items-center justify-center border border-dashed border-slate-200 dark:border-slate-800 rounded-xl bg-slate-50/50 dark:bg-slate-950/40 text-center p-6">
                <HelpCircle className="h-7 w-7 text-slate-300 dark:text-slate-700 mb-1" />
                <p className="text-xs text-slate-500 font-medium">No discomfort logs written</p>
                <p className="text-[10px] text-slate-400 mt-1">Logging active discomfort maps your joint recovery rates over time.</p>
              </div>
            )}
          </div>
        </div>

        {/* Biomechanical Warning / Diagnostic Panel */}
        <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-5 rounded-2xl shadow-sm flex flex-col justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider font-mono text-rose-600 dark:text-rose-400 block mb-1">
              Biomechanical Safety
            </span>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">Active Joint Warning Thresholds</h4>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-1 leading-relaxed">
              If any of your active joint discomfort logs list a severity score above <strong className="text-rose-500">6/10</strong>, please do not continue heavy compound barbell operations.
            </p>
          </div>

          <div className="my-4 pt-4 border-t border-slate-100 dark:border-slate-850">
            {reports.length > 0 ? (
              <div className="p-3 bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200/50 rounded-xl space-y-1.5">
                <span className="text-[10px] font-bold text-rose-500 dark:text-rose-400 uppercase tracking-widest block">Latest Pain Marker</span>
                <p className="text-sm font-bold text-slate-900 dark:text-white">
                  {reports[0].BodyPart}: {reports[0].PainLevel}/10 ({reports[0].PainType})
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-normal">
                  Triggered during: <span className="font-semibold text-slate-700 dark:text-slate-300">{reports[0].Exercise || 'Not Specified'}</span>
                </p>
              </div>
            ) : (
              <div className="p-3 bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200/50 rounded-xl text-center">
                <p className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">All systems structural stable</p>
                <p className="text-[10px] text-slate-400 mt-0.5">Maintain progressive overload safely!</p>
              </div>
            )}
          </div>

          <div className="p-3 bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-200/40 rounded-xl text-[10px] text-slate-500 dark:text-slate-400 leading-tight">
            <strong>AI Assist advice:</strong> Logging joint parameters feeds critical health signals directly to the Gemini risk analysis model to formulate therapeutic training recommendations.
          </div>
        </div>

      </div>

      {/* History Log Table */}
      <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 dark:border-slate-850">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">Discomfort History Timeline</h3>
        </div>
        
        <div className="overflow-x-auto">
          {reports.length > 0 ? (
            <table id="pain-history-table" className="w-full text-left text-xs text-slate-700 dark:text-slate-300">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200 dark:border-slate-850 text-slate-400 dark:text-slate-500 font-semibold uppercase tracking-wider">
                  <th className="px-6 py-3">Report Date</th>
                  <th className="px-6 py-3">Affected Joint/Muscle</th>
                  <th className="px-6 py-3">Discomfort Intensity</th>
                  <th className="px-6 py-3">Pain Pattern</th>
                  <th className="px-6 py-3">Suspected Trigger Exercise</th>
                  <th className="px-6 py-3 text-right">Active Duration</th>
                  <th className="px-6 py-3">Diagnostic Notes</th>
                  <th className="px-6 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-900">
                {reports.map((r) => (
                  <tr key={r.PainID} className="hover:bg-slate-50/50 dark:hover:bg-slate-900/40 transition-colors">
                    <td className="px-6 py-3.5 font-mono">{r.ReportDate}</td>
                    <td className="px-6 py-3.5 font-bold text-slate-900 dark:text-white">{r.BodyPart}</td>
                    <td className="px-6 py-3.5 font-mono">
                      <span className={`px-2.5 py-0.5 rounded-full font-bold border text-[11px] ${getPainBadgeStyles(r.PainLevel)}`}>
                        {r.PainLevel} / 10
                      </span>
                    </td>
                    <td className="px-6 py-3.5">
                      <span className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-900 rounded font-medium text-[10px]">
                        {r.PainType}
                      </span>
                    </td>
                    <td className="px-6 py-3.5 font-semibold text-slate-800 dark:text-slate-200">{r.Exercise || '-'}</td>
                    <td className="px-6 py-3.5 text-right font-mono">{r.Duration}</td>
                    <td className="px-6 py-3.5 max-w-44 truncate text-slate-400 dark:text-slate-500" title={r.Notes}>
                      {r.Notes || '-'}
                    </td>
                    <td className="px-6 py-3.5 text-right whitespace-nowrap">
                      <div className="flex justify-end gap-1.5">
                        <button
                          id={`edit-pain-btn-${r.PainID}`}
                          onClick={() => handleOpenEditModal(r)}
                          className="p-1.5 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded transition-colors"
                          title="Edit Log"
                        >
                          <Edit2 className="h-3.5 w-3.5" />
                        </button>
                        <button
                          id={`delete-pain-btn-${r.PainID}`}
                          onClick={() => handleDelete(r.PainID)}
                          className={`p-1 rounded transition-all text-[10px] font-bold ${
                            deletingId === r.PainID 
                              ? 'bg-rose-600 hover:bg-rose-700 text-white px-2 animate-pulse' 
                              : 'text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 p-1.5'
                          }`}
                          title={deletingId === r.PainID ? "Click again to confirm delete" : "Delete Log"}
                        >
                          {deletingId === r.PainID ? 'Confirm?' : <Trash2 className="h-3.5 w-3.5" />}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="text-center py-12 p-6">
              <Stethoscope className="h-8 w-8 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium font-sans">No discomfort or pain records logged.</p>
              <button 
                onClick={handleOpenAddModal}
                className="mt-3 text-xs font-bold text-rose-600 dark:text-rose-400 hover:underline"
              >
                Log Active Discomfort
              </button>
            </div>
          )}
        </div>

      </div>

      {/* Add / Edit Pain Modal Form */}
      <AnimatePresence>
        {isModalOpen && (
          <div id="pain-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div
              id="pain-modal-card"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-6 animate-none"
            >
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-4">
                <Heart className="h-5 w-5 text-rose-500" />
                {editingId ? 'Edit Discomfort Log' : 'Record Active Discomfort'}
              </h3>

              <form id="pain-form" onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  
                  {/* Affected Body Part */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Affected Joint/Area</label>
                    <select
                      id="form-body-part"
                      value={bodyPart}
                      onChange={(e) => setBodyPart(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                    >
                      <option value="Shoulder">Shoulder (Rotator cuff / AC joint)</option>
                      <option value="Knee">Knee (Patella / meniscus)</option>
                      <option value="Lower Back">Lower Back (Lumbar decompression)</option>
                      <option value="Elbow">Elbow (Tendinitis / Golfer elbow)</option>
                      <option value="Wrist">Wrist (Carpal strain)</option>
                      <option value="Ankle">Ankle (Achilles / joint capsule)</option>
                      <option value="Neck">Neck (Cervical alignment)</option>
                      <option value="Hip">Hip (Flexor tightness)</option>
                    </select>
                  </div>

                  {/* Trigger Exercise */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Trigger Exercise (Optional)</label>
                    <input 
                      id="form-pain-exercise"
                      type="text" 
                      value={exercise}
                      onChange={(e) => setExercise(e.target.value)}
                      placeholder="e.g. Overhead Dumbbell Press"
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  {/* Pain Level 1-10 Slider */}
                  <div className="sm:col-span-2">
                    <div className="flex justify-between items-center mb-1.5">
                      <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider">Pain Intensity Level</label>
                      <span id="slider-value-indicator" className={`text-sm font-bold font-mono px-2 py-0.5 rounded border ${getPainBadgeStyles(painLevel)}`}>
                        {painLevel} / 10
                      </span>
                    </div>
                    <input 
                      id="form-pain-level"
                      type="range" 
                      min={1}
                      max={10}
                      step={1}
                      value={painLevel}
                      onChange={(e) => setPainLevel(Number(e.target.value))}
                      className="w-full accent-rose-500 cursor-pointer"
                    />
                    <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                      <span>1 (Very Mild stiffness)</span>
                      <span>5 (Moderate interference)</span>
                      <span>10 (Severe joint pain)</span>
                    </div>
                    <p className={`text-[11px] mt-2 italic ${getPainLevelDescription(painLevel).color}`}>
                      {getPainLevelDescription(painLevel).text}
                    </p>
                  </div>

                  {/* Pain Type */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Pain Sensation</label>
                    <select
                      id="form-pain-type"
                      value={painType}
                      onChange={(e) => setPainType(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                    >
                      <option value="Sharp">Sharp (Sudden pinch)</option>
                      <option value="Dull Ache">Dull Ache (Post-workout tension)</option>
                      <option value="Stiffness">Stiffness (Range of motion block)</option>
                      <option value="Throbbing">Throbbing (Inflammatory heat)</option>
                      <option value="Numbness">Numbness / Tingling (Nerve strain)</option>
                    </select>
                  </div>

                  {/* Duration */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Active Duration</label>
                    <input 
                      id="form-pain-duration"
                      type="text" 
                      value={duration}
                      onChange={(e) => setDuration(e.target.value)}
                      placeholder="e.g. 2 days, 3 weeks"
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                      required
                    />
                  </div>

                  {/* Report Date */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Date Noticed</label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"><Calendar className="h-4 w-4" /></span>
                      <input 
                        id="form-pain-date"
                        type="date" 
                        value={reportDate}
                        onChange={(e) => setReportDate(e.target.value)}
                        className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                        required
                      />
                    </div>
                  </div>

                  {/* Diagnostic Notes */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Symptoms & Sensation Notes</label>
                    <textarea 
                      id="form-pain-notes"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="e.g. Noticeable clicking when rotating shoulders backwards. Warm shower helps dull the stiffness."
                      rows={2}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-xs focus:outline-none focus:border-indigo-500"
                    ></textarea>
                  </div>

                </div>

                {/* Buttons */}
                <div className="flex justify-between items-center pt-4 border-t border-slate-100 dark:border-slate-850">
                  <div>
                    {editingId && (
                      <button
                        id="form-pain-delete"
                        type="button"
                        onClick={() => {
                          handleDelete(editingId);
                          setIsModalOpen(false);
                        }}
                        className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 border border-rose-200 hover:border-rose-300 text-rose-600 dark:bg-rose-950/25 dark:border-rose-900/40 dark:text-rose-400 dark:hover:bg-rose-950/40 rounded-lg text-xs font-bold transition-colors"
                      >
                        Delete Log
                      </button>
                    )}
                  </div>
                  <div className="flex gap-2.5">
                    <button
                      id="form-pain-cancel"
                      type="button"
                      onClick={() => setIsModalOpen(false)}
                      className="px-4 py-2 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg text-xs font-bold text-slate-600 dark:text-slate-400 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      id="form-pain-submit"
                      type="submit"
                      className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold transition-all shadow-lg shadow-rose-500/10"
                    >
                      {editingId ? 'Save Changes' : 'Record Log'}
                    </button>
                  </div>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
