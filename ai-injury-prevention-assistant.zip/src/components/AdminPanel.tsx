// Admin Panel Sub-Component (Module 11)
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldAlert, Users, Dumbbell, Activity, Bell, Trash2, Edit2, 
  Plus, Megaphone, Terminal, RefreshCw, AlertTriangle, Check, X 
} from 'lucide-react';
import { User, Exercise, ActivityLog } from '../types.js';

interface AdminPanelProps {
  apiBase: string;
  token: string;
}

export default function AdminPanel({ apiBase, token }: AdminPanelProps) {
  const [activeSubTab, setActiveSubTab] = useState<'stats' | 'users' | 'exercises' | 'announcements'>('stats');
  
  // States
  const [stats, setStats] = useState<any | null>(null);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [exercises, setExercises] = useState<Exercise[]>([]);
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Announcement Form State
  const [announcementTitle, setAnnouncementTitle] = useState('');
  const [announcementMessage, setAnnouncementMessage] = useState('');

  // Exercise CRUD Form State
  const [isExerciseModalOpen, setIsExerciseModalOpen] = useState(false);
  const [editingExerciseId, setEditingExerciseId] = useState<number | null>(null);
  const [deletingUserId, setDeletingUserId] = useState<number | null>(null);
  const [deletingExerciseId, setDeletingExerciseId] = useState<number | null>(null);
  const [exName, setExName] = useState('');
  const [exMuscle, setExMuscle] = useState('Chest');
  const [exDesc, setExDesc] = useState('');
  const [exSafety, setExSafety] = useState('');
  const [exDiff, setExDiff] = useState('Medium');
  const [exEquip, setExEquip] = useState('Barbell');
  const [exAltsInput, setExAltsInput] = useState(''); // Comma separated alternatives

  const muscles = ['Chest', 'Back', 'Shoulders', 'Legs', 'Arms', 'Core'];

  const fetchAdminData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [statsRes, usersRes, exercisesRes] = await Promise.all([
        fetch(`${apiBase}/admin/stats`, { headers: { 'Authorization': `Bearer ${token}` } }),
        fetch(`${apiBase}/admin/users`, { headers: { 'Authorization': `Bearer ${token}` } }),
        fetch(`${apiBase}/exercises`, { headers: { 'Authorization': `Bearer ${token}` } })
      ]);

      if (!statsRes.ok || !usersRes.ok || !exercisesRes.ok) {
        throw new Error('Admin API request rejected.');
      }

      const statsData = await statsRes.json();
      const usersData = await usersRes.json();
      const exercisesData = await exercisesRes.json();

      setStats(statsData.stats);
      setActivityLogs(statsData.activityLogs);
      setUsers(usersData);
      setExercises(exercisesData);
    } catch (err: any) {
      setError(err.message || 'Authorization rejected or backend unavailable.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, [token, activeSubTab]);

  // Delete user
  const handleDeleteUser = async (userId: number) => {
    if (deletingUserId !== userId) {
      setDeletingUserId(userId);
      setTimeout(() => {
        setDeletingUserId(curr => curr === userId ? null : curr);
      }, 3000);
      return;
    }
    setDeletingUserId(null);
    try {
      const res = await fetch(`${apiBase}/admin/users/${userId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!res.ok) throw new Error('Termination rejected.');
      setSuccess('User account successfully deleted.');
      fetchAdminData();
    } catch (err: any) {
      setError(err.message || 'Action failed.');
    }
  };

  // Publish global announcement
  const handlePostAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!announcementTitle || !announcementMessage) {
      setError('Title and message are required.');
      return;
    }

    try {
      const res = await fetch(`${apiBase}/admin/announcements`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ title: announcementTitle, message: announcementMessage })
      });

      if (!res.ok) throw new Error('Announcement failed to broadcast.');
      
      setSuccess('Broadcasting Announcement to all user terminals.');
      setAnnouncementTitle('');
      setAnnouncementMessage('');
      fetchAdminData();
    } catch (err: any) {
      setError(err.message || 'Failed to post bulletin.');
    }
  };

  // Open exercise modal
  const handleOpenAddExModal = () => {
    setEditingExerciseId(null);
    setExName('');
    setExMuscle('Chest');
    setExDesc('');
    setExSafety('');
    setExDiff('Medium');
    setExEquip('Barbell');
    setExAltsInput('');
    setIsExerciseModalOpen(true);
  };

  const handleOpenEditExModal = (ex: Exercise) => {
    setEditingExerciseId(ex.ExerciseID);
    setExName(ex.ExerciseName);
    setExMuscle(ex.MuscleGroup);
    setExDesc(ex.Description);
    setExSafety(ex.SafetyTips);
    setExDiff(ex.Difficulty);
    setExEquip(ex.Equipment);
    setExAltsInput(ex.Alternatives ? ex.Alternatives.join(', ') : '');
    setIsExerciseModalOpen(true);
  };

  // Exercise Submit
  const handleExerciseSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    const altsArray = exAltsInput.split(',').map(s => s.trim()).filter(s => s.length > 0);

    const payload = {
      exerciseName: exName,
      muscleGroup: exMuscle,
      description: exDesc,
      safetyTips: exSafety,
      difficulty: exDiff,
      equipment: exEquip,
      alternatives: altsArray
    };

    try {
      let res;
      if (editingExerciseId) {
        res = await fetch(`${apiBase}/admin/exercises/${editingExerciseId}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(payload)
        });
      } else {
        res = await fetch(`${apiBase}/admin/exercises`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(payload)
        });
      }

      if (!res.ok) throw new Error('Failed to save exercise.');
      
      setSuccess('Exercise database updated successfully.');
      setIsExerciseModalOpen(false);
      fetchAdminData();
    } catch (err: any) {
      setError(err.message || 'Exercise database write failed.');
    }
  };

  const handleDeleteExercise = async (id: number) => {
    if (deletingExerciseId !== id) {
      setDeletingExerciseId(id);
      setTimeout(() => {
        setDeletingExerciseId(curr => curr === id ? null : curr);
      }, 3000);
      return;
    }
    setDeletingExerciseId(null);
    try {
      const res = await fetch(`${apiBase}/admin/exercises/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!res.ok) throw new Error('Deletion rejected.');
      setSuccess('Exercise removed successfully.');
      fetchAdminData();
    } catch (err: any) {
      setError(err.message || 'Deletion failed.');
    }
  };

  return (
    <div id="admin-root" className="space-y-6">
      
      {/* Admin Title Card */}
      <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-6 rounded-2xl shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 transition-all">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <ShieldAlert className="h-5 w-5 text-indigo-500" />
            Administrator Core Workspace
          </h2>
          <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
            Review live system telemetry, terminate spam listings, update biomechanical databases, and broadcast safety bulletins.
          </p>
        </div>
        <button 
          id="admin-sync-btn"
          onClick={fetchAdminData}
          className="p-2 bg-slate-50 dark:bg-slate-900 border border-slate-250 dark:border-slate-800 rounded-lg text-slate-600 dark:text-slate-400 text-xs font-semibold flex items-center gap-1.5 transition-colors shrink-0"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          Sync Diagnostics
        </button>
      </div>

      {/* Admin Alert Indicators */}
      {error && (
        <div id="admin-alert-error" className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-600 text-xs flex gap-2">
          <AlertTriangle className="h-4 w-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div id="admin-alert-success" className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-600 text-xs flex gap-2">
          <Check className="h-4 w-4 shrink-0" />
          <span>{success}</span>
        </div>
      )}

      {/* Workspace Menu Bar */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 gap-2 overflow-x-auto scrollbar-none">
        {[
          { id: 'stats', label: 'Telemetry Stats', icon: Terminal },
          { id: 'users', label: 'User Accounts', icon: Users },
          { id: 'exercises', label: 'Movement Library CRUD', icon: Dumbbell },
          { id: 'announcements', label: 'Broadcast Announcement', icon: Megaphone }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`admin-subtab-${tab.id}`}
              onClick={() => { setActiveSubTab(tab.id as any); setError(null); setSuccess(null); }}
              className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold whitespace-nowrap border-b-2 transition-all ${
                isActive 
                  ? 'border-indigo-600 text-indigo-600 dark:border-indigo-400 dark:text-indigo-400' 
                  : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <Icon className="h-4 w-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {loading ? (
        <div className="min-h-[30vh] flex flex-col items-center justify-center">
          <RefreshCw className="h-6 w-6 text-indigo-500 animate-spin mb-2" />
          <p className="text-xs text-slate-400">Querying DB...</p>
        </div>
      ) : (
        <AnimatePresence mode="wait">
          
          {/* TELEMETRY STATS & ACTIVITY LOG TAB */}
          {activeSubTab === 'stats' && stats && (
            <motion.div
              key="stats"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="bg-white dark:bg-slate-950 border border-slate-200 p-5 rounded-2xl">
                  <span className="text-xs font-bold text-slate-400 block uppercase">Active Accounts</span>
                  <span id="admin-users-count" className="text-3xl font-extrabold text-slate-900 dark:text-white font-mono mt-1 block">{stats.totalUsers}</span>
                </div>
                <div className="bg-white dark:bg-slate-950 border border-slate-200 p-5 rounded-2xl">
                  <span className="text-xs font-bold text-slate-400 block uppercase">Workouts Logged</span>
                  <span id="admin-workouts-count" className="text-3xl font-extrabold text-slate-900 dark:text-white font-mono mt-1 block">{stats.totalWorkouts}</span>
                </div>
                <div className="bg-white dark:bg-slate-950 border border-slate-200 p-5 rounded-2xl">
                  <span className="text-xs font-bold text-slate-400 block uppercase">Pain Records</span>
                  <span id="admin-pains-count" className="text-3xl font-extrabold text-slate-900 dark:text-white font-mono mt-1 block">{stats.totalPainReports}</span>
                </div>
                <div className="bg-white dark:bg-slate-950 border border-slate-200 p-5 rounded-2xl">
                  <span className="text-xs font-bold text-slate-400 block uppercase">AI Diagnostics</span>
                  <span id="admin-ai-count" className="text-3xl font-extrabold text-slate-900 dark:text-white font-mono mt-1 block">{stats.totalAIRecommendations}</span>
                </div>
              </div>

              {/* Activity terminal logs */}
              <div className="bg-slate-950 border border-slate-900 rounded-2xl overflow-hidden shadow-2xl p-5">
                <div className="flex justify-between items-center mb-3">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1.5">
                    <Terminal className="h-4 w-4" />
                    System Operation Auditing Logs
                  </h3>
                  <span className="h-2 w-2 rounded-full bg-emerald-500 animate-ping"></span>
                </div>
                <div id="admin-activity-logs" className="max-h-80 overflow-y-auto font-mono text-[11px] text-emerald-400 space-y-1.5 pr-2 select-all scrollbar-thin">
                  {activityLogs.map((log) => (
                    <div key={log.LogID} className="leading-relaxed hover:bg-slate-900/60 p-0.5 rounded">
                      <span className="text-slate-500 font-bold">[{log.LogDate}]</span>{' '}
                      <span className="text-indigo-400 font-semibold">User #{log.UserID}</span>{' '}
                      <span className="text-slate-300">{log.Activity}</span>
                    </div>
                  ))}
                  {activityLogs.length === 0 && (
                    <div className="text-slate-500 italic">No activity entries registered.</div>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {/* USER ACCOUNTS MANAGEMENT */}
          {activeSubTab === 'users' && (
            <motion.div
              key="users"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl overflow-hidden"
            >
              <div className="p-5 border-b border-slate-100 dark:border-slate-850">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">Active System Accounts</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200 text-slate-400 font-semibold uppercase">
                      <th className="px-6 py-3">Account ID</th>
                      <th className="px-6 py-3">Full Name</th>
                      <th className="px-6 py-3">Email Address</th>
                      <th className="px-6 py-3">Role Status</th>
                      <th className="px-6 py-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-900">
                    {users.map((u) => (
                      <tr key={u.UserID} className="hover:bg-slate-50/50">
                        <td className="px-6 py-3 font-mono">#{u.UserID}</td>
                        <td className="px-6 py-3 font-bold text-slate-900 dark:text-white">{u.Name}</td>
                        <td className="px-6 py-3 font-mono">{u.Email}</td>
                        <td className="px-6 py-3">
                          <span className="px-2 py-0.5 bg-indigo-50 dark:bg-indigo-900/40 text-indigo-600 rounded font-semibold text-[10px] uppercase">
                            {u.Role}
                          </span>
                        </td>
                        <td className="px-6 py-3 text-right">
                          <button
                            id={`terminate-user-btn-${u.UserID}`}
                            onClick={() => handleDeleteUser(u.UserID)}
                            className={`p-1 rounded transition-all text-[10px] font-bold ${
                              deletingUserId === u.UserID
                                ? 'bg-rose-600 text-white px-2 animate-pulse'
                                : 'text-rose-600 hover:bg-rose-50 p-1.5'
                            }`}
                            title={deletingUserId === u.UserID ? "Click again to confirm delete" : "Terminate User Account"}
                          >
                            {deletingUserId === u.UserID ? 'Confirm?' : <Trash2 className="h-4 w-4" />}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {/* MOVEMENT LIBRARY CRUD */}
          {activeSubTab === 'exercises' && (
            <motion.div
              key="exercises"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-4"
            >
              <div className="flex justify-between items-center bg-white dark:bg-slate-950 p-4 border border-slate-200 dark:border-slate-850 rounded-xl">
                <span className="text-xs font-bold text-slate-900 dark:text-white">Exercises Catalog ({exercises.length})</span>
                <button
                  id="admin-create-exercise-btn"
                  onClick={handleOpenAddExModal}
                  className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-all shadow-md shadow-indigo-500/10 flex items-center gap-1"
                >
                  <Plus className="h-3.5 w-3.5" />
                  Compile New Exercise
                </button>
              </div>

              <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200 text-slate-400 font-semibold uppercase">
                        <th className="px-6 py-3">ID</th>
                        <th className="px-6 py-3">Exercise Name</th>
                        <th className="px-6 py-3">Target Muscle</th>
                        <th className="px-6 py-3">Equipment</th>
                        <th className="px-6 py-3">Difficulty</th>
                        <th className="px-6 py-3">Alternatives</th>
                        <th className="px-6 py-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-900">
                      {exercises.map((ex) => (
                        <tr key={ex.ExerciseID} className="hover:bg-slate-50/50">
                          <td className="px-6 py-3 font-mono">#{ex.ExerciseID}</td>
                          <td className="px-6 py-3 font-bold text-slate-900 dark:text-white">{ex.ExerciseName}</td>
                          <td className="px-6 py-3">
                            <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-900 rounded font-semibold text-[10px]">
                              {ex.MuscleGroup}
                            </span>
                          </td>
                          <td className="px-6 py-3 font-mono">{ex.Equipment}</td>
                          <td className="px-6 py-3 uppercase text-[10px] font-bold">{ex.Difficulty}</td>
                          <td className="px-6 py-3 max-w-44 truncate text-slate-500">{ex.Alternatives ? ex.Alternatives.join(', ') : '-'}</td>
                          <td className="px-6 py-3 text-right whitespace-nowrap">
                            <div className="flex justify-end gap-1">
                              <button
                                id={`edit-ex-btn-${ex.ExerciseID}`}
                                onClick={() => handleOpenEditExModal(ex)}
                                className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded"
                              >
                                <Edit2 className="h-3.5 w-3.5" />
                              </button>
                              <button
                                id={`delete-ex-btn-${ex.ExerciseID}`}
                                onClick={() => handleDeleteExercise(ex.ExerciseID)}
                                className={`p-1 rounded transition-all text-[10px] font-bold ${
                                  deletingExerciseId === ex.ExerciseID
                                    ? 'bg-rose-600 text-white px-2 animate-pulse'
                                    : 'text-rose-600 hover:bg-rose-50 p-1.5'
                                }`}
                                title={deletingExerciseId === ex.ExerciseID ? "Click again to confirm delete" : "Delete Exercise"}
                              >
                                {deletingExerciseId === ex.ExerciseID ? 'Confirm?' : <Trash2 className="h-3.5 w-3.5" />}
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </motion.div>
          )}

          {/* BROADCAST ANNOUNCEMENTS FORM */}
          {activeSubTab === 'announcements' && (
            <motion.div
              key="announcements"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="max-w-xl mx-auto bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-6 rounded-2xl shadow-sm"
            >
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5 mb-2">
                <Megaphone className="h-4.5 w-4.5 text-indigo-500" />
                Publish Global Safety Bulletin
              </h3>
              <p className="text-xs text-slate-400 dark:text-slate-500 mb-4 leading-relaxed">
                Broadcasting an announcement pushes a real-time notification alert instantly onto every single active user terminal.
              </p>

              <form id="announcement-form" onSubmit={handlePostAnnouncement} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">Bulletin Title</label>
                  <input 
                    id="admin-ann-title"
                    type="text" 
                    placeholder="e.g. Server Maintenance or New Kinetic Tutorials Added"
                    value={announcementTitle}
                    onChange={(e) => setAnnouncementTitle(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 text-slate-900 dark:text-white text-xs focus:outline-none focus:border-indigo-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">Bulletin Message Content</label>
                  <textarea 
                    id="admin-ann-msg"
                    rows={4}
                    placeholder="Provide safety advice, warning notices, or site development newsletters."
                    value={announcementMessage}
                    onChange={(e) => setAnnouncementMessage(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 text-slate-900 dark:text-white text-xs focus:outline-none focus:border-indigo-500"
                    required
                  ></textarea>
                </div>

                <button 
                  id="admin-ann-submit-btn"
                  type="submit" 
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-all shadow-md shadow-indigo-500/10 flex items-center justify-center gap-1.5"
                >
                  <Megaphone className="h-4 w-4" />
                  Broadcast Announcement
                </button>
              </form>
            </motion.div>
          )}

        </AnimatePresence>
      )}

      {/* Exercise CRUD Form Modal (Module 11) */}
      <AnimatePresence>
        {isExerciseModalOpen && (
          <div id="ex-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div
              id="ex-modal-card"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-6"
            >
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-4">
                <Dumbbell className="h-5 w-5 text-indigo-500" />
                {editingExerciseId ? 'Update Exercise Specifications' : 'Compile New Biomechanical Exercise'}
              </h3>

              <form id="ex-crud-form" onSubmit={handleExerciseSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  
                  {/* Name */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Exercise Name</label>
                    <input 
                      id="admin-ex-name"
                      type="text" 
                      value={exName}
                      onChange={(e) => setExName(e.target.value)}
                      placeholder="e.g. Hex Bar Deadlift"
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 text-slate-900 dark:text-white text-xs focus:outline-none"
                      required
                    />
                  </div>

                  {/* Muscle */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Target Muscle Group</label>
                    <select
                      id="admin-ex-muscle"
                      value={exMuscle}
                      onChange={(e) => setExMuscle(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 text-slate-900 dark:text-white text-xs focus:outline-none"
                    >
                      {muscles.map(m => (
                        <option key={m} value={m}>{m}</option>
                      ))}
                    </select>
                  </div>

                  {/* Difficulty */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Mechanical Difficulty</label>
                    <select
                      id="admin-ex-difficulty"
                      value={exDiff}
                      onChange={(e) => setExDiff(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 text-slate-900 dark:text-white text-xs focus:outline-none"
                    >
                      <option value="Easy">Easy (Accessory repair)</option>
                      <option value="Medium">Medium (Standard compound)</option>
                      <option value="Hard">Hard (Highly loaded kinetic chain)</option>
                    </select>
                  </div>

                  {/* Equipment */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Required Equipment</label>
                    <input 
                      id="admin-ex-equipment"
                      type="text" 
                      value={exEquip}
                      onChange={(e) => setExEquip(e.target.value)}
                      placeholder="e.g. Trap Bar, Dumbbells, Pullup Bar"
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 text-slate-900 dark:text-white text-xs focus:outline-none"
                      required
                    />
                  </div>

                  {/* Description */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Biomechanics & Technical Execution</label>
                    <textarea 
                      id="admin-ex-desc"
                      rows={2}
                      value={exDesc}
                      onChange={(e) => setExDesc(e.target.value)}
                      placeholder="Specify mechanical setup, active motion path, and lumbar brace tips."
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 text-slate-900 dark:text-white text-xs focus:outline-none"
                      required
                    ></textarea>
                  </div>

                  {/* Safety Tips */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Injury Prevention & Safety Advice</label>
                    <textarea 
                      id="admin-ex-safety"
                      rows={2}
                      value={exSafety}
                      onChange={(e) => setExSafety(e.target.value)}
                      placeholder="Provide rotational controls, shoulder retraction warnings, and RPE safeguards."
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 text-slate-900 dark:text-white text-xs focus:outline-none"
                      required
                    ></textarea>
                  </div>

                  {/* Alternatives */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Safer Alternatives (Comma separated)</label>
                    <input 
                      id="admin-ex-alts"
                      type="text" 
                      value={exAltsInput}
                      onChange={(e) => setExAltsInput(e.target.value)}
                      placeholder="e.g. Dumbbell Bench Press, Floor Press, Pushups"
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 text-slate-900 dark:text-white text-xs focus:outline-none"
                    />
                  </div>

                </div>

                {/* Submit buttons */}
                <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
                  <button
                    id="admin-ex-cancel"
                    type="button"
                    onClick={() => setIsExerciseModalOpen(false)}
                    className="px-4 py-2 hover:bg-slate-100 border border-slate-200 rounded-lg text-xs font-bold text-slate-600"
                  >
                    Cancel
                  </button>
                  <button
                    id="admin-ex-submit"
                    type="submit"
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold"
                  >
                    Save Specifications
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
