// Navigation Bar Sub-Component
import React from 'react';
import { motion } from 'motion/react';
import { 
  Dumbbell, Activity, Heart, ShieldAlert, Library, MessageSquare, 
  Bell, LogOut, Sun, Moon, Sparkles, UserCheck 
} from 'lucide-react';
import { User } from '../types.js';

interface NavbarProps {
  user: User;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  unreadCount: number;
  onLogout: () => void;
  darkMode: boolean;
  setDarkMode: (dark: boolean) => void;
}

export default function Navbar({ 
  user, activeTab, setActiveTab, unreadCount, onLogout, darkMode, setDarkMode 
}: NavbarProps) {
  const isUserAdmin = user.Role === 'admin';

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Activity, roles: ['user', 'admin'] },
    { id: 'profile', label: 'My Profile', icon: UserCheck, roles: ['user'] },
    { id: 'workouts', label: 'Workouts', icon: Dumbbell, roles: ['user'] },
    { id: 'pain', label: 'Pain Logs', icon: Heart, roles: ['user'] },
    { id: 'analysis', label: 'AI Risk', icon: Sparkles, roles: ['user'] },
    { id: 'exercises', label: 'Gym Library', icon: Library, roles: ['user', 'admin'] },
    { id: 'chat', label: 'Coach Chat', icon: MessageSquare, roles: ['user'] },
    { id: 'admin', label: 'Admin Panel', icon: ShieldAlert, roles: ['admin'] }
  ];

  const visibleNavItems = navItems.filter(item => item.roles.includes(user.Role));

  return (
    <nav id="app-navbar" className="sticky top-0 z-50 w-full bg-white dark:bg-slate-950 border-b border-slate-200 dark:border-slate-850 shadow-sm transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          
          {/* Brand Logo & Name */}
          <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
            <div className="flex items-center justify-center p-2 bg-indigo-600 dark:bg-indigo-500 rounded-lg text-white">
              <Activity className="h-5 w-5 animate-pulse" />
            </div>
            <div>
              <span className="font-bold text-slate-900 dark:text-white tracking-tight block sm:inline">
                Injury Prevent AI
              </span>
              <span className="text-[10px] block font-mono text-indigo-600 dark:text-indigo-400 font-bold uppercase tracking-wider leading-none">
                Safety First
              </span>
            </div>
          </div>

          {/* Center Navigation Links (Hidden on small mobile) */}
          <div className="hidden md:flex space-x-1 items-center">
            {visibleNavItems.map(item => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-link-${item.id}`}
                  onClick={() => setActiveTab(item.id)}
                  className={`relative flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold tracking-wide transition-all ${
                    isActive 
                      ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40' 
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-900'
                  }`}
                >
                  <Icon className={`h-4 w-4 ${isActive ? 'stroke-[2.5px]' : ''}`} />
                  {item.label}
                  {item.id === 'analysis' && (
                    <span className="absolute -top-1 -right-1 flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Right Action Icons */}
          <div className="flex items-center gap-3">
            
            {/* Dark Mode Toggle */}
            <button
              id="theme-toggle-btn"
              onClick={() => setDarkMode(!darkMode)}
              className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors"
              title={darkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
            >
              {darkMode ? <Sun className="h-4 w-4 text-amber-500" /> : <Moon className="h-4 w-4 text-indigo-600" />}
            </button>

            {/* Notification Bell (User only) */}
            {user.Role === 'user' && (
              <button
                id="navbar-notification-bell"
                onClick={() => setActiveTab('notifications')}
                className={`relative p-2 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors ${
                  activeTab === 'notifications' ? 'bg-slate-50 dark:bg-slate-900 border-indigo-400 text-indigo-600' : ''
                }`}
              >
                <Bell className="h-4 w-4" />
                {unreadCount > 0 && (
                  <span id="unread-count-badge" className="absolute -top-1 -right-1 flex items-center justify-center min-w-4 h-4 px-1 rounded-full bg-rose-600 text-[9px] font-bold text-white leading-none">
                    {unreadCount}
                  </span>
                )}
              </button>
            )}

            {/* User Session Info / Logout */}
            <div className="flex items-center gap-2 pl-2 border-l border-slate-200 dark:border-slate-800">
              <div className="hidden lg:flex flex-col text-right">
                <span className="text-xs font-bold text-slate-900 dark:text-white leading-none mb-0.5 max-w-28 truncate">{user.Name}</span>
                <span className="text-[9px] font-mono font-bold uppercase tracking-widest text-slate-400 dark:text-slate-500">
                  {user.Role}
                </span>
              </div>

              {isUserAdmin && (
                <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-500/10 text-amber-600 border border-amber-500/25 uppercase mr-1">
                  ADMIN
                </span>
              )}

              <button
                id="logout-btn"
                onClick={onLogout}
                className="p-2 rounded-lg bg-rose-50 dark:bg-rose-950/20 text-rose-600 dark:text-rose-400 border border-rose-100 dark:border-rose-950/50 hover:bg-rose-100 dark:hover:bg-rose-950/35 transition-colors"
                title="Log Out"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>

          </div>
        </div>
      </div>

      {/* Subnav Rail for Small Mobile Screens */}
      <div id="mobile-subnav" className="md:hidden flex overflow-x-auto gap-1 px-4 py-2 bg-slate-50 dark:bg-slate-900/60 border-t border-slate-200/50 dark:border-slate-850 scrollbar-none">
        {visibleNavItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              id={`nav-link-mobile-${item.id}`}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold whitespace-nowrap transition-all ${
                isActive 
                  ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40' 
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 hover:bg-slate-100 dark:hover:bg-slate-900'
              }`}
            >
              <Icon className="h-3.5 w-3.5" />
              {item.label}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
