// Workout Tracker Sub-Component (Module 3)
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, Edit2, Trash2, Calendar, Dumbbell, Clock, Activity, 
  BarChart3, RefreshCw, AlertCircle, Search, Filter, HelpCircle 
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { WorkoutHistory, Exercise } from '../types.js';

interface WorkoutsProps {
  apiBase: string;
  token: string;
  onWorkoutLogged: () => void;
}

export default function Workouts({ apiBase, token, onWorkoutLogged }: WorkoutsProps) {
  const [workouts, setWorkouts] = useState<WorkoutHistory[]>([]);
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Form State
  const [exercise, setExercise] = useState('');
  const [muscleGroup, setMuscleGroup] = useState('Chest');
  const [weight, setWeight] = useState<number>(60);
  const [sets, setSets] = useState<number>(3);
  const [reps, setReps] = useState<number>(10);
  const [duration, setDuration] = useState<number>(45);
  const [difficulty, setDifficulty] = useState('Medium');
  const [workoutDate, setWorkoutDate] = useState(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');

  // Editing state
  const [editingId, setEditingId] = useState<number | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);

  // Filters State
  const [searchQuery, setSearchQuery] = useState('');
  const [filterMuscle, setFilterMuscle] = useState('All');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const muscles = ['Chest', 'Back', 'Shoulders', 'Legs', 'Arms', 'Core'];

  const fetchWorkoutsAndExercises = async () => {
    setLoading(true);
    setError(null);
    try {
      // Parallel fetches
      const [workoutsRes, exercisesRes] = await Promise.all([
        fetch(`${apiBase}/workouts`, { headers: { 'Authorization': `Bearer ${token}` } }),
        fetch(`${apiBase}/exercises`, { headers: { 'Authorization': `Bearer ${token}` } })
      ]);

      if (!workoutsRes.ok || !exercisesRes.ok) {
        throw new Error('Failed to retrieve logs from server.');
      }

      const workoutsData = await workoutsRes.json();
      const exercisesData = await exercisesRes.json();

      setWorkouts(workoutsData);
      setExercises(exercisesData);
    } catch (err: any) {
      setError(err.message || 'Failed to sync with API.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWorkoutsAndExercises();
  }, [token]);

  // Handle autocomplete matching when selecting standard exercise names
  const handleExerciseNameSelect = (eName: string) => {
    setExercise(eName);
    const match = exercises.find(ex => ex.ExerciseName === eName);
    if (match) {
      setMuscleGroup(match.MuscleGroup);
    }
  };

  const handleOpenAddModal = () => {
    setEditingId(null);
    setExercise('');
    setMuscleGroup('Chest');
    setWeight(60);
    setSets(3);
    setReps(10);
    setDuration(45);
    setDifficulty('Medium');
    setWorkoutDate(new Date().toISOString().split('T')[0]);
    setNotes('');
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (w: WorkoutHistory) => {
    setEditingId(w.WorkoutID);
    setExercise(w.Exercise);
    setMuscleGroup(w.MuscleGroup);
    setWeight(w.Weight);
    setSets(w.Sets);
    setReps(w.Reps);
    setDuration(w.Duration);
    setDifficulty(w.Difficulty);
    setWorkoutDate(w.WorkoutDate);
    setNotes(w.Notes || '');
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const payload = {
      exercise,
      muscleGroup,
      weight,
      sets,
      reps,
      duration,
      difficulty,
      workoutDate,
      notes
    };

    try {
      let res;
      if (editingId) {
        res = await fetch(`${apiBase}/workouts/${editingId}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(payload)
        });
      } else {
        res = await fetch(`${apiBase}/workouts`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(payload)
        });
      }

      if (!res.ok) {
        throw new Error('Failed to save workout log.');
      }

      setIsModalOpen(false);
      fetchWorkoutsAndExercises();
      onWorkoutLogged();
    } catch (err: any) {
      setError(err.message || 'Failed to submit workout log.');
    }
  };

  const handleDelete = async (id: number) => {
    if (deletingId !== id) {
      setDeletingId(id);
      // Auto reset confirmation after 3 seconds of inactivity
      setTimeout(() => {
        setDeletingId(curr => curr === id ? null : curr);
      }, 3000);
      return;
    }
    setDeletingId(null);
    try {
      const res = await fetch(`${apiBase}/workouts/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!res.ok) throw new Error('Deletion failed.');
      fetchWorkoutsAndExercises();
      onWorkoutLogged();
    } catch (err: any) {
      setError(err.message || 'Failed to delete record.');
    }
  };

  // Filter & Search Logic
  const filteredWorkouts = workouts.filter(w => {
    const matchesSearch = w.Exercise.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesMuscle = filterMuscle === 'All' || w.MuscleGroup.toLowerCase() === filterMuscle.toLowerCase();
    const matchesStart = !startDate || w.WorkoutDate >= startDate;
    const matchesEnd = !endDate || w.WorkoutDate <= endDate;
    return matchesSearch && matchesMuscle && matchesStart && matchesEnd;
  });

  // Calculate stats
  const totalVolumeThisWeek = filteredWorkouts.reduce((sum, w) => sum + (w.Weight * w.Sets * w.Reps), 0);
  const totalSetsThisWeek = filteredWorkouts.reduce((sum, w) => sum + w.Sets, 0);

  // 1. Weekly Workout Volume trend
  const last7DaysData = Array.from({ length: 7 }).map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const dStr = d.toISOString().split('T')[0];
    const dLabel = d.toLocaleDateString('en-US', { weekday: 'short' });
    
    const dayVolume = workouts
      .filter(w => w.WorkoutDate === dStr)
      .reduce((sum, w) => sum + (w.Weight * w.Sets * w.Reps), 0);

    return { name: dLabel, Volume: dayVolume };
  }).reverse();

  // 2. Training distribution across muscle groups
  const muscleDistributionData = muscles.map(m => {
    const totalVol = workouts
      .filter(w => w.MuscleGroup.toLowerCase() === m.toLowerCase())
      .reduce((sum, w) => sum + (w.Weight * w.Sets * w.Reps), 0);
    return { name: m, Volume: totalVol };
  });

  return (
    <div id="workouts-root" className="space-y-6">
      
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-6 rounded-2xl shadow-sm transition-all">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Dumbbell className="h-5 w-5 text-indigo-500" />
            Workout Tracker
          </h2>
          <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
            Build structural balance and prevent shoulder or back impingements by tracking your compound loads.
          </p>
        </div>
        <button
          id="add-workout-modal-btn"
          onClick={handleOpenAddModal}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-all shadow-lg shadow-indigo-500/10 flex items-center gap-1.5"
        >
          <Plus className="h-4 w-4" />
          Log Workout Session
        </button>
      </div>

      {error && (
        <div id="workouts-alert-error" className="p-3 bg-rose-50 dark:bg-rose-950/20 border border-rose-200/50 dark:border-rose-900/30 rounded-xl text-rose-600 dark:text-rose-400 text-xs flex gap-2">
          <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {/* Dynamic Statistics Panel (Module 3 requirement) */}
      <div id="workout-stats-panel" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Metric Cards Column */}
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl p-5 shadow-sm">
            <span className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">Filtered Training Volume</span>
            <span id="workouts-total-volume" className="text-3xl font-extrabold text-slate-900 dark:text-white font-mono mt-1 block">
              {totalVolumeThisWeek.toLocaleString()} kg
            </span>
            <span className="text-[10px] text-slate-400 dark:text-slate-500 mt-1 block leading-tight">
              Computed as total weight × sets × reps currently shown in history.
            </span>
          </div>

          <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl p-5 shadow-sm">
            <span className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">Total Sets Completed</span>
            <span id="workouts-total-sets" className="text-3xl font-extrabold text-slate-900 dark:text-white font-mono mt-1 block">
              {totalSetsThisWeek} Sets
            </span>
            <span className="text-[10px] text-slate-400 dark:text-slate-500 mt-1 block leading-tight">
              A high set volume in pushing exercises without matching pull exercises increases impingement.
            </span>
          </div>
        </div>

        {/* Chart 1: Last 7 Days Volume Trend */}
        <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl p-5 shadow-sm">
          <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">Daily Load Volume (Last 7 Days)</h4>
          <div className="h-40 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={last7DaysData} margin={{ top: 5, right: 0, left: -25, bottom: 0 }}>
                <XAxis dataKey="name" tick={{ fontSize: 9, fill: '#64748b' }} />
                <YAxis tick={{ fontSize: 9, fill: '#64748b' }} />
                <Tooltip contentStyle={{ fontSize: '10px' }} />
                <Bar dataKey="Volume" fill="#4f46e5" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Muscle Distribution */}
        <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl p-5 shadow-sm">
          <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">Volume Distribution by Muscle</h4>
          <div className="h-40 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={muscleDistributionData} margin={{ top: 5, right: 0, left: -25, bottom: 0 }}>
                <XAxis dataKey="name" tick={{ fontSize: 9, fill: '#64748b' }} />
                <YAxis tick={{ fontSize: 9, fill: '#64748b' }} />
                <Tooltip contentStyle={{ fontSize: '10px' }} />
                <Bar dataKey="Volume" fill="#10b981" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      {/* Filter and History section */}
      <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl shadow-sm overflow-hidden transition-all duration-300">
        
        {/* Filter Controls Bar */}
        <div className="p-5 border-b border-slate-100 dark:border-slate-850 flex flex-col lg:flex-row gap-4 items-stretch lg:items-center">
          
          {/* Text Search */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input 
              id="workouts-search-input"
              type="text" 
              placeholder="Search by exercise name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-xs focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Muscle Category Filter */}
          <div className="relative">
            <select
              id="workouts-muscle-filter"
              value={filterMuscle}
              onChange={(e) => setFilterMuscle(e.target.value)}
              className="pl-3 pr-8 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-xs focus:outline-none focus:border-indigo-500 appearance-none cursor-pointer"
            >
              <option value="All">All Muscle Groups</option>
              {muscles.map(m => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
            <Filter className="absolute right-2.5 top-1/2 -translate-y-1/2 h-3 w-3 text-slate-400 pointer-events-none" />
          </div>

          {/* Date range filters */}
          <div className="flex items-center gap-2">
            <input 
              id="workouts-start-date"
              type="date" 
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="px-2 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-[11px] focus:outline-none focus:border-indigo-500"
            />
            <span className="text-slate-400 text-xs">to</span>
            <input 
              id="workouts-end-date"
              type="date" 
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="px-2 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-[11px] focus:outline-none focus:border-indigo-500"
            />
          </div>

        </div>

        {/* History Table */}
        <div className="overflow-x-auto">
          {filteredWorkouts.length > 0 ? (
            <table id="workouts-history-table" className="w-full text-left text-xs text-slate-700 dark:text-slate-300">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200 dark:border-slate-850 text-slate-400 dark:text-slate-500 font-semibold uppercase tracking-wider">
                  <th className="px-6 py-3">Workout Date</th>
                  <th className="px-6 py-3">Exercise Name</th>
                  <th className="px-6 py-3">Muscle Group</th>
                  <th className="px-6 py-3 text-right">Weight (kg)</th>
                  <th className="px-6 py-3 text-right">Sets × Reps</th>
                  <th className="px-6 py-3 text-right">Duration</th>
                  <th className="px-6 py-3">Intensity</th>
                  <th className="px-6 py-3">Notes</th>
                  <th className="px-6 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-900">
                {filteredWorkouts.map((w) => (
                  <tr key={w.WorkoutID} className="hover:bg-slate-50/50 dark:hover:bg-slate-900/40 transition-colors">
                    <td className="px-6 py-3.5 font-mono">{w.WorkoutDate}</td>
                    <td className="px-6 py-3.5 font-bold text-slate-900 dark:text-white">{w.Exercise}</td>
                    <td className="px-6 py-3.5">
                      <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-900 rounded font-semibold text-[10px]">
                        {w.MuscleGroup}
                      </span>
                    </td>
                    <td className="px-6 py-3.5 text-right font-mono font-medium">{w.Weight} kg</td>
                    <td className="px-6 py-3.5 text-right font-mono">{w.Sets} × {w.Reps}</td>
                    <td className="px-6 py-3.5 text-right font-mono">{w.Duration} mins</td>
                    <td className="px-6 py-3.5">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                        w.Difficulty === 'Hard' || w.Difficulty === 'Very Hard' 
                          ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400' 
                          : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                      }`}>
                        {w.Difficulty}
                      </span>
                    </td>
                    <td className="px-6 py-3.5 max-w-44 truncate text-slate-400 dark:text-slate-500" title={w.Notes}>
                      {w.Notes || '-'}
                    </td>
                    <td className="px-6 py-3.5 text-right whitespace-nowrap">
                      <div className="flex justify-end gap-1.5">
                        <button
                          id={`edit-workout-btn-${w.WorkoutID}`}
                          onClick={() => handleOpenEditModal(w)}
                          className="p-1.5 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded transition-colors"
                          title="Edit Log"
                        >
                          <Edit2 className="h-3.5 w-3.5" />
                        </button>
                        <button
                          id={`delete-workout-btn-${w.WorkoutID}`}
                          onClick={() => handleDelete(w.WorkoutID)}
                          className={`p-1 rounded transition-all text-[10px] font-bold ${
                            deletingId === w.WorkoutID 
                              ? 'bg-rose-600 hover:bg-rose-700 text-white px-2 animate-pulse' 
                              : 'text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 p-1.5'
                          }`}
                          title={deletingId === w.WorkoutID ? "Click again to confirm delete" : "Delete Log"}
                        >
                          {deletingId === w.WorkoutID ? 'Confirm?' : <Trash2 className="h-3.5 w-3.5" />}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="text-center py-12 p-6">
              <Dumbbell className="h-8 w-8 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">No workout logs match your filtering parameters.</p>
              <button 
                onClick={handleOpenAddModal}
                className="mt-3 text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                Clear Filters & Log Session
              </button>
            </div>
          )}
        </div>

      </div>

      {/* Add / Edit Workout Modal Form */}
      <AnimatePresence>
        {isModalOpen && (
          <div id="workout-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div
              id="workout-modal-card"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-6"
            >
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-4">
                <Dumbbell className="h-5 w-5 text-indigo-500" />
                {editingId ? 'Edit Workout Log' : 'Log New Exercise Set'}
              </h3>

              <form id="workout-form" onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  
                  {/* Exercise Name Selection/Text */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Exercise Name</label>
                    <input 
                      id="form-exercise"
                      type="text" 
                      list="exercises-options"
                      value={exercise}
                      onChange={(e) => handleExerciseNameSelect(e.target.value)}
                      placeholder="e.g. Bench Press, Pull-ups, Squats"
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                      required
                    />
                    <datalist id="exercises-options">
                      {exercises.map(ex => (
                        <option key={ex.ExerciseID} value={ex.ExerciseName} />
                      ))}
                    </datalist>
                  </div>

                  {/* Muscle Group */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Primary Target Muscle</label>
                    <select
                      id="form-muscle"
                      value={muscleGroup}
                      onChange={(e) => setMuscleGroup(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                    >
                      {muscles.map(m => (
                        <option key={m} value={m}>{m}</option>
                      ))}
                    </select>
                  </div>

                  {/* Weight */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Working Load (kg)</label>
                    <input 
                      id="form-weight"
                      type="number" 
                      min={0}
                      max={600}
                      value={weight}
                      onChange={(e) => setWeight(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                      required
                    />
                  </div>

                  {/* Sets */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Sets</label>
                    <input 
                      id="form-sets"
                      type="number" 
                      min={1}
                      max={20}
                      value={sets}
                      onChange={(e) => setSets(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                      required
                    />
                  </div>

                  {/* Reps */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Reps per Set</label>
                    <input 
                      id="form-reps"
                      type="number" 
                      min={1}
                      max={100}
                      value={reps}
                      onChange={(e) => setReps(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                      required
                    />
                  </div>

                  {/* Duration */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Duration (mins)</label>
                    <input 
                      id="form-duration"
                      type="number" 
                      min={1}
                      max={180}
                      value={duration}
                      onChange={(e) => setDuration(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                      required
                    />
                  </div>

                  {/* Difficulty */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Difficulty Rating</label>
                    <select
                      id="form-difficulty"
                      value={difficulty}
                      onChange={(e) => setDifficulty(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                    >
                      <option value="Easy">Easy (Light accessory)</option>
                      <option value="Medium">Medium (Controlled sets)</option>
                      <option value="Hard">Hard (RPE 8-9 heavy sets)</option>
                      <option value="Very Hard">Very Hard (To muscular failure)</option>
                    </select>
                  </div>

                  {/* Date */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Workout Date</label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"><Calendar className="h-4 w-4" /></span>
                      <input 
                        id="form-date"
                        type="date" 
                        value={workoutDate}
                        onChange={(e) => setWorkoutDate(e.target.value)}
                        className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                        required
                      />
                    </div>
                  </div>

                  {/* Notes */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Biomechanical Notes (Optional)</label>
                    <textarea 
                      id="form-notes"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="e.g. Felt slight lower back compression, chest felt tight at bottom-range lockout."
                      rows={2}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-xs focus:outline-none focus:border-indigo-500"
                    ></textarea>
                  </div>

                </div>

                {/* Submit button bar */}
                <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100 dark:border-slate-850">
                  <button
                    id="form-cancel-btn"
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg text-xs font-bold text-slate-600 dark:text-slate-400 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    id="form-submit-btn"
                    type="submit"
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-all shadow-lg shadow-indigo-500/10"
                  >
                    {editingId ? 'Save Changes' : 'Record Log'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
