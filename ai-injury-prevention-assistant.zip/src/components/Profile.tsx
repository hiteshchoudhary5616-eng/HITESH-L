// Profile Sub-Component (Module 2)
import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { User, FitnessProfile } from '../types.js';
import { User as UserIcon, Scale, Target, Compass, RefreshCw, AlertCircle, ShieldAlert } from 'lucide-react';

interface ProfileProps {
  apiBase: string;
  token: string;
  onProfileUpdated: () => void;
}

export default function Profile({ apiBase, token, onProfileUpdated }: ProfileProps) {
  const [age, setAge] = useState<number>(25);
  const [gender, setGender] = useState<string>('Male');
  const [height, setHeight] = useState<number>(175); // in cm
  const [weight, setWeight] = useState<number>(70); // in kg
  const [experience, setExperience] = useState<'Beginner' | 'Intermediate' | 'Advanced'>('Beginner');
  const [goal, setGoal] = useState<string>('General Fitness');

  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Load existing profile from API
  const fetchProfile = async () => {
    setFetching(true);
    setError(null);
    try {
      const res = await fetch(`${apiBase}/profile`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data: FitnessProfile | null = await res.json();
        if (data) {
          setAge(data.Age || 25);
          setGender(data.Gender || 'Male');
          setHeight(data.Height || 175);
          setWeight(data.Weight || 70);
          setExperience(data.Experience || 'Beginner');
          setGoal(data.Goal || 'General Fitness');
        }
      }
    } catch (err: any) {
      console.error('Failed to load profile', err);
    } finally {
      setFetching(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, [token]);

  // Live BMI Calculation
  const calculateBmi = () => {
    if (height > 0 && weight > 0) {
      const heightInMeters = height / 100;
      return (weight / (heightInMeters * heightInMeters)).toFixed(2);
    }
    return "0.00";
  };

  const getBmiCategory = (bmi: number) => {
    if (bmi < 18.5) return { label: 'Underweight', color: 'text-amber-500' };
    if (bmi >= 18.5 && bmi < 25) return { label: 'Healthy Weight', color: 'text-emerald-500 font-semibold' };
    if (bmi >= 25 && bmi < 30) return { label: 'Overweight', color: 'text-amber-500' };
    return { label: 'Obese', color: 'text-rose-500 font-bold' };
  };

  const currentBmi = parseFloat(calculateBmi());
  const bmiCategory = getBmiCategory(currentBmi);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      const res = await fetch(`${apiBase}/profile`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          age,
          gender,
          height,
          weight,
          experience,
          goal
        })
      });

      if (!res.ok) {
        throw new Error('Failed to save profile on the server.');
      }

      setSuccess('Your biomechanical and fitness profile has been successfully updated.');
      onProfileUpdated();
    } catch (err: any) {
      setError(err.message || 'Profile save failed.');
    } finally {
      setLoading(false);
    }
  };

  if (fetching) {
    return (
      <div id="profile-loading" className="min-h-[50vh] flex flex-col items-center justify-center">
        <RefreshCw className="h-8 w-8 text-indigo-600 dark:text-indigo-400 animate-spin mb-3" />
        <p className="text-xs text-slate-500">Loading profile configurations...</p>
      </div>
    );
  }

  return (
    <div id="profile-section-root" className="max-w-3xl mx-auto space-y-6">
      
      {/* Profile Header */}
      <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl p-6 shadow-sm transition-all">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <UserIcon className="h-5 w-5 text-indigo-500" />
          Fitness & Biomechanical Profile
        </h2>
        <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
          Complete your physical measurements to power our injury prevention formulas and customize Gemini AI diagnostics.
        </p>
      </div>

      {/* Profile Update Status Alert */}
      {error && (
        <div id="profile-error-alert" className="p-3 bg-rose-50 dark:bg-rose-950/20 border border-rose-200/50 dark:border-rose-900/30 rounded-xl text-rose-600 dark:text-rose-400 text-xs flex gap-2">
          <ShieldAlert className="h-4 w-4 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div id="profile-success-alert" className="p-3 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200/50 dark:border-emerald-900/30 rounded-xl text-emerald-600 dark:text-emerald-400 text-xs flex gap-2">
          <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
          <span>{success}</span>
        </div>
      )}

      {/* Main Multi-Column Split Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Form Panel */}
        <form id="profile-form" onSubmit={handleSubmit} className="lg:col-span-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl p-6 shadow-sm space-y-4 transition-all">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Age */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Age</label>
              <input 
                id="profile-age"
                type="number" 
                min={12}
                max={100}
                value={age}
                onChange={(e) => setAge(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                required
              />
            </div>

            {/* Gender */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Gender</label>
              <select 
                id="profile-gender"
                value={gender}
                onChange={(e) => setGender(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
              >
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Non-Binary">Non-Binary</option>
                <option value="Prefer Not To Say">Prefer Not To Say</option>
              </select>
            </div>

            {/* Height */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Height (cm)</label>
              <input 
                id="profile-height"
                type="number" 
                min={50}
                max={250}
                value={height}
                onChange={(e) => setHeight(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                required
              />
            </div>

            {/* Weight */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Weight (kg)</label>
              <input 
                id="profile-weight"
                type="number" 
                min={20}
                max={300}
                value={weight}
                onChange={(e) => setWeight(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                required
              />
            </div>

            {/* Experience Level */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Experience Level</label>
              <select 
                id="profile-experience"
                value={experience}
                onChange={(e) => setExperience(e.target.value as any)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
              >
                <option value="Beginner">Beginner (under 1 year)</option>
                <option value="Intermediate">Intermediate (1-3 years)</option>
                <option value="Advanced">Advanced (3+ years)</option>
              </select>
            </div>

            {/* Goal */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Primary Fitness Goal</label>
              <select 
                id="profile-goal"
                value={goal}
                onChange={(e) => setGoal(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
              >
                <option value="General Fitness">General Fitness</option>
                <option value="Muscle Gain">Muscle Gain (Hypertrophy)</option>
                <option value="Strength">Strength Powerlifting</option>
                <option value="Weight Loss">Weight Loss / Cardio</option>
                <option value="Endurance">Athletic Endurance</option>
              </select>
            </div>

          </div>

          <div className="pt-4 border-t border-slate-100 dark:border-slate-850">
            <button 
              id="profile-save-btn"
              type="submit" 
              disabled={loading}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold transition-colors shadow-lg shadow-indigo-500/10 disabled:opacity-50"
            >
              {loading ? 'Saving Profile...' : 'Save Configuration'}
            </button>
          </div>
        </form>

        {/* Right Live BMI Diagnostics Box */}
        <div id="bmi-display-panel" className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl p-6 shadow-sm flex flex-col justify-between transition-all">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider font-mono text-indigo-600 dark:text-indigo-400 block mb-1">
              Live Biometrics
            </span>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">Body Mass Index (BMI)</h3>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-1 leading-relaxed">
              Calculated live using standard metric values: <code className="font-mono bg-slate-100 dark:bg-slate-900 px-1 py-0.5 rounded">weight / height²</code>.
            </p>
          </div>

          <div className="my-8 text-center">
            <span id="bmi-value-display" className="text-5xl font-extrabold font-mono text-slate-900 dark:text-white block tracking-tight">
              {calculateBmi()}
            </span>
            <span id="bmi-category-display" className={`text-sm font-bold mt-2 block uppercase tracking-wider ${bmiCategory.color}`}>
              {bmiCategory.label}
            </span>
          </div>

          <div className="p-3 bg-slate-50 dark:bg-slate-900/60 rounded-xl border border-slate-200/40 dark:border-slate-800/40 text-[11px] text-slate-500 dark:text-slate-400 leading-normal">
            <strong className="text-slate-700 dark:text-slate-300">Biomechanical Warning:</strong> While BMI is an informative generic baseline, our AI uses your experience level and workout intensity to evaluate kinetic strain.
          </div>
        </div>

      </div>

    </div>
  );
}
