// Exercise Library Sub-Component (Module 6)
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Library, Search, Filter, ShieldAlert, Dumbbell, 
  ChevronRight, RefreshCw, X, HelpCircle, CheckCircle2 
} from 'lucide-react';
import { Exercise } from '../types.js';

interface ExerciseLibraryProps {
  apiBase: string;
  token: string;
}

export default function ExerciseLibrary({ apiBase, token }: ExerciseLibraryProps) {
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Search & Filtering States
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  // Selected exercise detail modal
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null);

  // Add Exercise Form States
  const [showAddModal, setShowAddModal] = useState(false);
  const [newExerciseName, setNewExerciseName] = useState('');
  const [newMuscleGroup, setNewMuscleGroup] = useState('Chest');
  const [newDescription, setNewDescription] = useState('');
  const [newSafetyTips, setNewSafetyTips] = useState('');
  const [newDifficulty, setNewDifficulty] = useState('Intermediate');
  const [newEquipment, setNewEquipment] = useState('Dumbbell');
  const [newAlternativesString, setNewAlternativesString] = useState('');
  const [addLoading, setAddLoading] = useState(false);

  const categories = ['All', 'Chest', 'Back', 'Shoulders', 'Legs', 'Arms', 'Core'];

  const fetchExercises = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`${apiBase}/exercises`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!res.ok) throw new Error('Failed to retrieve exercise library.');
      const data = await res.json();
      setExercises(data);
    } catch (err: any) {
      setError(err.message || 'Data sync error.');
    } finally {
      setLoading(false);
    }
  };

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExerciseName.trim() || !newMuscleGroup) return;

    setAddLoading(true);
    setError(null);
    try {
      const res = await fetch(`${apiBase}/exercises`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          exerciseName: newExerciseName.trim(),
          muscleGroup: newMuscleGroup,
          description: newDescription.trim() || 'Custom user-created workout.',
          safetyTips: newSafetyTips.trim() || 'Maintain steady biomechanics and proper form.',
          difficulty: newDifficulty,
          equipment: newEquipment,
          alternatives: newAlternativesString.split(',').map(s => s.trim()).filter(Boolean)
        })
      });

      if (!res.ok) {
        throw new Error('Failed to create custom exercise entry.');
      }

      await fetchExercises();
      setShowAddModal(false);

      // Reset form fields
      setNewExerciseName('');
      setNewMuscleGroup('Chest');
      setNewDescription('');
      setNewSafetyTips('');
      setNewDifficulty('Intermediate');
      setNewEquipment('Dumbbell');
      setNewAlternativesString('');
    } catch (err: any) {
      setError(err.message || 'Failed to save custom exercise.');
    } finally {
      setAddLoading(false);
    }
  };

  useEffect(() => {
    fetchExercises();
  }, [token]);

  // Handle alternative click linkage to swap focused detailed exercise
  const handleAlternativeClick = (altName: string) => {
    const matched = exercises.find(e => e.ExerciseName.toLowerCase() === altName.toLowerCase());
    if (matched) {
      setSelectedExercise(matched);
    } else {
      alert(`The alternative "${altName}" was not found in the seeded library, but constitutes a safer joint-loading alternative.`);
    }
  };

  const filteredExercises = exercises.filter(e => {
    const matchesSearch = e.ExerciseName.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          e.Description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = selectedCategory === 'All' || e.MuscleGroup.toLowerCase() === selectedCategory.toLowerCase();
    return matchesSearch && matchesCat;
  });

  if (loading) {
    return (
      <div id="exercises-loading" className="min-h-[50vh] flex flex-col items-center justify-center">
        <RefreshCw className="h-8 w-8 text-indigo-600 dark:text-indigo-400 animate-spin mb-3" />
        <p className="text-xs text-slate-500">Loading kinetic dictionary...</p>
      </div>
    );
  }

  return (
    <div id="exercise-library-root" className="space-y-6">
      
      {/* Page Header */}
      <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl p-6 shadow-sm transition-all flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Library className="h-5 w-5 text-indigo-500" />
            Gym Biomechanical Library
          </h2>
          <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
            Explore safer biomechanical movement techniques, critical safety precautions, and alternative exercises to substitute when injured.
          </p>
        </div>
        <button
          id="add-workout-btn"
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-all shadow-md shadow-indigo-500/10 flex items-center gap-1.5 shrink-0"
        >
          <Dumbbell className="h-4 w-4" />
          Add Workout
        </button>
      </div>

      {error && (
        <div className="p-3 bg-rose-50 dark:bg-rose-950/20 border border-rose-200/50 rounded-xl text-rose-600 text-xs">
          {error}
        </div>
      )}

      {/* Advanced Filtering bar */}
      <div className="flex flex-col md:flex-row gap-4 items-stretch md:items-center bg-white dark:bg-slate-950 p-4 border border-slate-200 dark:border-slate-850 rounded-xl shadow-sm transition-all">
        
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input 
            id="lib-search-input"
            type="text" 
            placeholder="Search exercises or mechanical terms..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-lg border border-slate-200 dark:border-slate-850 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-xs focus:outline-none focus:border-indigo-500"
          />
        </div>

        {/* Categories slider */}
        <div className="flex gap-1.5 overflow-x-auto scrollbar-none pb-1 md:pb-0">
          {categories.map((cat) => (
            <button
              key={cat}
              id={`cat-btn-${cat}`}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat 
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/10' 
                  : 'bg-slate-50 dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

      </div>

      {/* Grid of Exercise Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredExercises.map((ex) => (
          <div
            key={ex.ExerciseID}
            id={`exercise-card-${ex.ExerciseID}`}
            onClick={() => setSelectedExercise(ex)}
            className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-5 rounded-2xl shadow-sm hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group"
          >
            <div>
              <div className="flex justify-between items-start mb-2">
                <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-900 rounded font-semibold text-[10px] text-slate-500 dark:text-slate-400 uppercase tracking-wide">
                  {ex.MuscleGroup}
                </span>
                <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
                  ex.Difficulty === 'Hard' ? 'bg-rose-500/10 text-rose-500' :
                  ex.Difficulty === 'Medium' ? 'bg-amber-500/10 text-amber-500' :
                  'bg-emerald-500/10 text-emerald-500'
                }`}>
                  {ex.Difficulty}
                </span>
              </div>

              <h3 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                {ex.ExerciseName}
              </h3>
              
              <p className="text-xs text-slate-400 dark:text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                {ex.Description}
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-900 flex justify-between items-center text-[10px]">
              <span className="text-slate-400">Equipment: <strong>{ex.Equipment}</strong></span>
              <span className="text-indigo-600 dark:text-indigo-400 font-bold flex items-center gap-0.5">
                View Techniques
                <ChevronRight className="h-3 w-3" />
              </span>
            </div>
          </div>
        ))}

        {filteredExercises.length === 0 && (
          <div className="col-span-full text-center py-12 bg-white dark:bg-slate-950 border border-dashed border-slate-200 dark:border-slate-850 rounded-2xl">
            <HelpCircle className="h-8 w-8 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
            <p className="text-xs text-slate-500 font-medium">No exercises match your search terms.</p>
          </div>
        )}
      </div>

      {/* Detailed Technical Card Overlay Modal */}
      <AnimatePresence>
        {selectedExercise && (
          <div id="exercise-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div
              id="exercise-modal-card"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-2xl shadow-2xl p-6"
            >
              
              {/* Modal Header */}
              <div className="flex justify-between items-start border-b border-slate-100 dark:border-slate-850 pb-3 mb-4">
                <div>
                  <span className="px-2 py-0.5 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 rounded font-bold text-[9px] uppercase tracking-wider block w-fit mb-1.5">
                    {selectedExercise.MuscleGroup} Group
                  </span>
                  <h3 id="exercise-detail-title" className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <Dumbbell className="h-5 w-5 text-indigo-500" />
                    {selectedExercise.ExerciseName}
                  </h3>
                </div>
                <button
                  id="exercise-modal-close"
                  onClick={() => setSelectedExercise(null)}
                  className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Modal Body */}
              <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
                
                {/* Description */}
                <div>
                  <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Biomechanics & Movement Path</h4>
                  <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                    {selectedExercise.Description}
                  </p>
                </div>

                {/* Equipment & Level */}
                <div className="grid grid-cols-2 gap-4 py-3 border-y border-slate-100 dark:border-slate-850 text-xs">
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase">Required Equipment</span>
                    <strong className="text-slate-800 dark:text-slate-200 font-medium">{selectedExercise.Equipment}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase">Mechanical Difficulty</span>
                    <strong className="text-slate-800 dark:text-slate-200 font-medium">{selectedExercise.Difficulty}</strong>
                  </div>
                </div>

                {/* Safety Warnings / Injury Prevention Tips */}
                <div id="safety-warning-tips" className="p-4 bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200/40 rounded-xl space-y-2">
                  <h4 className="text-[10px] font-bold text-rose-500 dark:text-rose-400 uppercase tracking-widest flex items-center gap-1">
                    <ShieldAlert className="h-4 w-4 shrink-0" />
                    Critical Injury Prevention Guidance
                  </h4>
                  <p className="text-xs text-slate-700 dark:text-slate-300 font-medium leading-relaxed italic">
                    "{selectedExercise.SafetyTips}"
                  </p>
                </div>

                {/* alternatives linkages (SPECIFIED requirement) */}
                <div>
                  <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Safer Biomechanical Alternatives</h4>
                  {selectedExercise.Alternatives && selectedExercise.Alternatives.length > 0 ? (
                    <div id="alternatives-linkages" className="flex flex-wrap gap-2">
                      {selectedExercise.Alternatives.map((alt, i) => (
                        <button
                          key={i}
                          id={`alt-link-${i}`}
                          onClick={() => handleAlternativeClick(alt)}
                          className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:hover:bg-indigo-950 rounded-lg text-xs font-bold text-indigo-600 dark:text-indigo-400 transition-colors border border-indigo-100 dark:border-indigo-900 flex items-center gap-1 text-left"
                        >
                          <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
                          <span>{alt}</span>
                        </button>
                      ))}
                    </div>
                  ) : (
                    <p className="text-[11px] text-slate-400 italic">No alternative movements required; this accessory constitutes a low-impact safe posture repair choice.</p>
                  )}
                </div>

              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Add Custom Exercise Form Overlay Modal */}
      <AnimatePresence>
        {showAddModal && (
          <div id="add-exercise-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div
              id="add-exercise-modal-card"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-2xl shadow-2xl p-6"
            >
              {/* Modal Header */}
              <div className="flex justify-between items-start border-b border-slate-100 dark:border-slate-850 pb-3 mb-4">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <Dumbbell className="h-5 w-5 text-indigo-500" />
                    Add Custom Workout Entry
                  </h3>
                  <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5">
                    Contribute a new exercise or compound movement pattern to the local biomechanics directory.
                  </p>
                </div>
                <button
                  id="add-exercise-modal-close"
                  onClick={() => setShowAddModal(false)}
                  className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Modal Form */}
              <form onSubmit={handleAddSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Name */}
                  <div className="sm:col-span-2">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Exercise Name</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Incline DB Bench Press"
                      value={newExerciseName}
                      onChange={(e) => setNewExerciseName(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-xs focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  {/* Muscle Group */}
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Muscle Group Group</label>
                    <select
                      value={newMuscleGroup}
                      onChange={(e) => setNewMuscleGroup(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-xs focus:outline-none focus:border-indigo-500"
                    >
                      {categories.filter(c => c !== 'All').map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>

                  {/* Difficulty */}
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Mechanical Difficulty</label>
                    <select
                      value={newDifficulty}
                      onChange={(e) => setNewDifficulty(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-xs focus:outline-none focus:border-indigo-500"
                    >
                      <option value="Beginner">Beginner</option>
                      <option value="Intermediate">Intermediate</option>
                      <option value="Advanced">Advanced</option>
                    </select>
                  </div>

                  {/* Equipment */}
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Equipment Required</label>
                    <input
                      type="text"
                      placeholder="e.g. Dumbbell, Barbell"
                      value={newEquipment}
                      onChange={(e) => setNewEquipment(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-xs focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  {/* Safer Alternatives */}
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Alternatives (Comma-Separated)</label>
                    <input
                      type="text"
                      placeholder="e.g. Pushups, Chest Press"
                      value={newAlternativesString}
                      onChange={(e) => setNewAlternativesString(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-xs focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  {/* Description */}
                  <div className="sm:col-span-2">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Biomechanics & Movement Description</label>
                    <textarea
                      rows={2}
                      placeholder="Explain correct biomechanical form and joint pathways..."
                      value={newDescription}
                      onChange={(e) => setNewDescription(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-xs focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  {/* Safety Tips */}
                  <div className="sm:col-span-2">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Injury Prevention Tips</label>
                    <textarea
                      rows={2}
                      placeholder="Detail safety precautions, core-bracing advices, and failure risks..."
                      value={newSafetyTips}
                      onChange={(e) => setNewSafetyTips(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-xs focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>

                {/* Form Actions */}
                <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100 dark:border-slate-850">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg text-xs font-bold text-slate-600 dark:text-slate-400 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={addLoading}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-all shadow-lg shadow-indigo-500/10 disabled:opacity-50"
                  >
                    {addLoading ? 'Saving...' : 'Add Exercise'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
