// Notifications Center Sub-Component (Module 10)
import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Bell, Check, ShieldAlert, Sparkles, RefreshCw, Calendar, AlertCircle } from 'lucide-react';
import { Notification } from '../types.js';

interface NotificationsProps {
  apiBase: string;
  token: string;
  onNotificationsRead: () => void;
}

export default function Notifications({ apiBase, token, onNotificationsRead }: NotificationsProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchNotifications = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`${apiBase}/notifications`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!res.ok) throw new Error('Failed to retrieve notification stream.');
      const data = await res.json();
      setNotifications(data);
    } catch (err: any) {
      setError(err.message || 'Failed to download notifications.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, [token]);

  const handleMarkAsRead = async (id: number) => {
    try {
      const res = await fetch(`${apiBase}/notifications/${id}/read`, {
        method: 'PATCH',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!res.ok) throw new Error('Failed to update state.');
      
      // Update local state instantly
      setNotifications(prev => prev.map(n => n.NotificationID === id ? { ...n, IsRead: true } : n));
      onNotificationsRead();
    } catch (err) {
      console.error(err);
    }
  };

  const handleMarkAllAsRead = async () => {
    const unread = notifications.filter(n => !n.IsRead);
    if (unread.length === 0) return;

    try {
      await Promise.all(unread.map(n => 
        fetch(`${apiBase}/notifications/${n.NotificationID}/read`, {
          method: 'PATCH',
          headers: { 'Authorization': `Bearer ${token}` }
        })
      ));
      
      setNotifications(prev => prev.map(n => ({ ...n, IsRead: true })));
      onNotificationsRead();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div id="notifications-root" className="max-w-2xl mx-auto space-y-6">
      
      {/* Header card */}
      <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-6 rounded-2xl shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 transition-all">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Bell className="h-5 w-5 text-indigo-500 animate-pulse" />
            Safety Notifications & Warnings
          </h2>
          <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
            Systemic indicators of high-risk volume, active recovery states, and site-wide safety bulletins.
          </p>
        </div>
        {notifications.some(n => !n.IsRead) && (
          <button
            id="mark-all-read-btn"
            onClick={handleMarkAllAsRead}
            className="px-3 py-1.5 bg-slate-50 hover:bg-slate-100 dark:bg-slate-900 dark:hover:bg-slate-850 text-indigo-600 dark:text-indigo-400 rounded-lg text-xs font-bold border border-slate-250 transition-colors flex items-center gap-1 shrink-0"
          >
            <Check className="h-3.5 w-3.5" />
            Mark All as Read
          </button>
        )}
      </div>

      {loading ? (
        <div className="min-h-[30vh] flex flex-col items-center justify-center">
          <RefreshCw className="h-6 w-6 text-indigo-500 animate-spin mb-2" />
          <p className="text-xs text-slate-400">Loading alerts...</p>
        </div>
      ) : (
        <div id="notifications-list" className="space-y-3">
          {notifications.map((n) => {
            const isAnnouncement = n.IsAnnouncement;
            return (
              <div
                key={n.NotificationID}
                id={`notification-card-${n.NotificationID}`}
                className={`p-4 rounded-xl border text-left flex gap-3 items-start transition-all ${
                  n.IsRead 
                    ? 'bg-white dark:bg-slate-950 border-slate-100 dark:border-slate-900 opacity-70' 
                    : 'bg-indigo-50/15 dark:bg-indigo-950/20 border-indigo-100 dark:border-indigo-950 shadow-sm'
                }`}
              >
                {/* Icon based on notification style */}
                <div className={`p-2 rounded-lg shrink-0 ${
                  isAnnouncement 
                    ? 'bg-amber-100 text-amber-700 dark:bg-amber-950/20 dark:text-amber-400' 
                    : n.Title.includes('High') || n.Title.includes('Warning')
                    ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/20 dark:text-rose-400' 
                    : 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950/20 dark:text-indigo-400'
                }`}>
                  {isAnnouncement ? <AlertCircle className="h-4 w-4" /> : <ShieldAlert className="h-4 w-4" />}
                </div>

                <div className="flex-1">
                  <div className="flex justify-between items-start mb-0.5">
                    <h3 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                      {n.Title}
                      {!n.IsRead && (
                        <span className="h-1.5 w-1.5 bg-rose-500 rounded-full animate-ping"></span>
                      )}
                    </h3>
                    <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono">
                      {n.CreatedAt ? n.CreatedAt.split('T')[0] : 'Today'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed font-sans">
                    {n.Message}
                  </p>
                  
                  {/* Mark as read button */}
                  {!n.IsRead && (
                    <button
                      id={`mark-read-btn-${n.NotificationID}`}
                      onClick={() => handleMarkAsRead(n.NotificationID)}
                      className="text-[10px] text-indigo-600 dark:text-indigo-400 hover:underline font-bold mt-2 flex items-center gap-0.5"
                    >
                      <Check className="h-3 w-3" />
                      Dismiss
                    </button>
                  )}
                </div>
              </div>
            );
          })}

          {notifications.length === 0 && (
            <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl p-12 text-center">
              <Check className="h-8 w-8 text-emerald-500 mx-auto mb-2" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Alert Log Clear</h3>
              <p className="text-xs text-slate-400 mt-1">No pending warnings or overreaching notifications logged. Keep training safely!</p>
            </div>
          )}
        </div>
      )}

    </div>
  );
}
