// Authentication Sub-Component
// Handles Register, Login, Forgot Password (visual OTP), and Password Reset
import React, { useState } from 'react';
import { motion } from 'motion/react';
import { KeyRound, Mail, User as UserIcon, ShieldAlert, ArrowRight, Activity, Eye, EyeOff } from 'lucide-react';
import { User } from '../types.js';

interface AuthProps {
  onLoginSuccess: (token: string, user: User) => void;
  apiBase: string;
}

export default function Auth({ onLoginSuccess, apiBase }: AuthProps) {
  const [mode, setMode] = useState<'login' | 'register' | 'forgot' | 'reset'>('login');
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  
  // Forgot Password / OTP states
  const [otp, setOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [otpDisplay, setOtpDisplay] = useState<string | null>(null);

  // Status & Error indicators
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const resetMessages = () => {
    setError(null);
    setMessage(null);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();
    if (!email || !password) {
      setError('Please enter both your email and password.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(`${apiBase}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Invalid credentials');
      }
      onLoginSuccess(data.token, data.user);
    } catch (err: any) {
      setError(err.message || 'Login failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();
    if (!name || !email || !password || !confirmPassword) {
      setError('All fields are required.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(`${apiBase}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Registration failed');
      }
      onLoginSuccess(data.token, data.user);
    } catch (err: any) {
      setError(err.message || 'Registration failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();
    if (!email) {
      setError('Please provide your registered email address.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(`${apiBase}/auth/forgot-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Operation failed');
      }
      setOtpDisplay(data.otp);
      setMessage('A reset OTP code has been generated for your session!');
      setMode('reset');
    } catch (err: any) {
      setError(err.message || 'Failed to trigger reset.');
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();
    if (!otp || !newPassword) {
      setError('Please provide the OTP code and a new password.');
      return;
    }
    if (newPassword.length < 6) {
      setError('New password must be at least 6 characters.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(`${apiBase}/auth/reset-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, otp, newPassword })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to reset password');
      }
      setMessage('Password reset successfully. You can now log in.');
      setMode('login');
      setPassword('');
      setNewPassword('');
      setOtp('');
      setOtpDisplay(null);
    } catch (err: any) {
      setError(err.message || 'Reset failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="auth-container" className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-slate-50 via-slate-100 to-indigo-50 dark:from-slate-950 dark:via-slate-900 dark:to-indigo-950 transition-colors duration-300">
      <motion.div 
        id="auth-card"
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-md bg-white/80 dark:bg-slate-900/80 backdrop-blur-md rounded-2xl border border-slate-200/50 dark:border-slate-800/50 p-8 shadow-2xl shadow-indigo-100/30 dark:shadow-none"
      >
        {/* App Logo / Heading */}
        <div className="text-center mb-8">
          <div className="inline-flex p-3 bg-indigo-600 dark:bg-indigo-500 rounded-xl text-white mb-3 shadow-lg shadow-indigo-500/20">
            <Activity className="h-6 w-6 animate-pulse" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
            Injury Prevention AI
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Academic Capstone Fitness Safety Assistant
          </p>
        </div>

        {/* Dynamic Alerts */}
        {error && (
          <div id="auth-error-alert" className="mb-4 p-3 bg-rose-50 dark:bg-rose-950/30 border border-rose-200/50 dark:border-rose-900/30 rounded-lg text-rose-600 dark:text-rose-400 text-xs flex gap-2 items-start">
            <ShieldAlert className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {message && (
          <div id="auth-success-alert" className="mb-4 p-3 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200/50 dark:border-emerald-900/30 rounded-lg text-emerald-600 dark:text-emerald-400 text-xs flex gap-2 items-start">
            <Activity className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{message}</span>
          </div>
        )}

        {/* Demo OTP On-Screen Banner (Academic Spec requirement) */}
        {otpDisplay && (
          <div id="otp-demo-display" className="mb-6 p-4 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 rounded-xl text-center">
            <p className="text-xs text-indigo-500 dark:text-indigo-400 font-medium uppercase tracking-wider mb-1">
              Demo OTP Notification (SMTP Simulator)
            </p>
            <p className="text-3xl font-bold font-mono tracking-widest text-indigo-600 dark:text-indigo-400">
              {otpDisplay}
            </p>
            <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1.5">
              Copy this 6-digit verification code to complete the password reset form.
            </p>
          </div>
        )}

        {/* Forms Switcher */}
        {mode === 'login' && (
          <form id="login-form" onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1">Email Address</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"><Mail className="h-4 w-4" /></span>
                <input 
                  id="login-email"
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@domain.com"
                  className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white placeholder-slate-400 text-sm focus:outline-none focus:border-indigo-500 dark:focus:border-indigo-400 transition-colors"
                  required
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider">Password</label>
                <button 
                  id="goto-forgot-btn"
                  type="button" 
                  onClick={() => { setMode('forgot'); resetMessages(); }}
                  className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"><KeyRound className="h-4 w-4" /></span>
                <input 
                  id="login-password"
                  type={showPassword ? "text" : "password"} 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-10 py-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white placeholder-slate-400 text-sm focus:outline-none focus:border-indigo-500 dark:focus:border-indigo-400 transition-colors"
                  required
                />
                <button 
                  id="login-password-toggle"
                  type="button" 
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <button 
              id="login-submit-btn"
              type="submit" 
              disabled={loading}
              className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium text-sm transition-colors shadow-lg shadow-indigo-500/15 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? 'Authenticating...' : 'Sign In'}
              <ArrowRight className="h-4 w-4" />
            </button>

            <div className="text-center mt-6 pt-4 border-t border-slate-200/50 dark:border-slate-800/50">
              <span className="text-xs text-slate-500 dark:text-slate-400">New to the platform? </span>
              <button 
                id="goto-register-btn"
                type="button" 
                onClick={() => { setMode('register'); resetMessages(); }}
                className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                Create Account
              </button>
            </div>
          </form>
        )}

        {mode === 'register' && (
          <form id="register-form" onSubmit={handleRegister} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1">Full Name</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"><UserIcon className="h-4 w-4" /></span>
                <input 
                  id="register-name"
                  type="text" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="John Doe"
                  className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white placeholder-slate-400 text-sm focus:outline-none focus:border-indigo-500 dark:focus:border-indigo-400 transition-colors"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1">Email Address</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"><Mail className="h-4 w-4" /></span>
                <input 
                  id="register-email"
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@domain.com"
                  className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white placeholder-slate-400 text-sm focus:outline-none focus:border-indigo-500 dark:focus:border-indigo-400 transition-colors"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1">Password</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"><KeyRound className="h-4 w-4" /></span>
                <input 
                  id="register-password"
                  type={showPassword ? "text" : "password"} 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="•••••••• (Min 6 chars)"
                  className="w-full pl-10 pr-10 py-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white placeholder-slate-400 text-sm focus:outline-none focus:border-indigo-500 dark:focus:border-indigo-400 transition-colors"
                  required
                />
                <button 
                  id="register-password-toggle"
                  type="button" 
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1">Confirm Password</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"><KeyRound className="h-4 w-4" /></span>
                <input 
                  id="register-confirm"
                  type={showPassword ? "text" : "password"} 
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white placeholder-slate-400 text-sm focus:outline-none focus:border-indigo-500 dark:focus:border-indigo-400 transition-colors"
                  required
                />
              </div>
            </div>

            <button 
              id="register-submit-btn"
              type="submit" 
              disabled={loading}
              className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium text-sm transition-colors shadow-lg shadow-indigo-500/15 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? 'Creating Account...' : 'Get Started'}
              <ArrowRight className="h-4 w-4" />
            </button>

            <div className="text-center mt-6 pt-4 border-t border-slate-200/50 dark:border-slate-800/50">
              <span className="text-xs text-slate-500 dark:text-slate-400">Already registered? </span>
              <button 
                id="goto-login-btn"
                type="button" 
                onClick={() => { setMode('login'); resetMessages(); }}
                className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                Sign In Instead
              </button>
            </div>
          </form>
        )}

        {mode === 'forgot' && (
          <form id="forgot-form" onSubmit={handleForgotPassword} className="space-y-4">
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4 leading-relaxed">
              Enter your registered email address below, and we will simulate sending an OTP verification code directly to your screen to secure your credentials.
            </p>
            
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1">Email Address</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"><Mail className="h-4 w-4" /></span>
                <input 
                  id="forgot-email"
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@domain.com"
                  className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white placeholder-slate-400 text-sm focus:outline-none focus:border-indigo-500 dark:focus:border-indigo-400 transition-colors"
                  required
                />
              </div>
            </div>

            <button 
              id="forgot-submit-btn"
              type="submit" 
              disabled={loading}
              className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium text-sm transition-colors shadow-lg shadow-indigo-500/15 disabled:opacity-50"
            >
              {loading ? 'Requesting Code...' : 'Request Verification OTP'}
            </button>

            <div className="text-center mt-6 pt-4 border-t border-slate-200/50 dark:border-slate-800/50">
              <button 
                id="forgot-back-btn"
                type="button" 
                onClick={() => { setMode('login'); resetMessages(); }}
                className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                Back to Sign In
              </button>
            </div>
          </form>
        )}

        {mode === 'reset' && (
          <form id="reset-form" onSubmit={handleResetPassword} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1">Enter Verification OTP</label>
              <input 
                id="reset-otp"
                type="text" 
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                placeholder="6-Digit Code"
                className="w-full px-4 py-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white text-center font-mono text-lg tracking-widest focus:outline-none focus:border-indigo-500 dark:focus:border-indigo-400 transition-colors"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1">New Password</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"><KeyRound className="h-4 w-4" /></span>
                <input 
                  id="reset-newpassword"
                  type={showPassword ? "text" : "password"} 
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-10 py-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white placeholder-slate-400 text-sm focus:outline-none focus:border-indigo-500 dark:focus:border-indigo-400 transition-colors"
                  required
                />
                <button 
                  id="reset-password-toggle"
                  type="button" 
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <button 
              id="reset-submit-btn"
              type="submit" 
              disabled={loading}
              className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium text-sm transition-colors shadow-lg shadow-indigo-500/15 disabled:opacity-50"
            >
              {loading ? 'Updating Password...' : 'Save and Update Password'}
            </button>

            <div className="text-center mt-6 pt-4 border-t border-slate-200/50 dark:border-slate-800/50">
              <button 
                id="reset-back-btn"
                type="button" 
                onClick={() => { setMode('login'); resetMessages(); }}
                className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                Back to Sign In
              </button>
            </div>
          </form>
        )}

        {/* Demo Users Quick Help panel */}
        <div id="demo-quick-help" className="mt-8 pt-4 border-t border-slate-200/40 dark:border-slate-800/40 text-center">
          <p className="text-[10px] text-slate-400 dark:text-slate-500 font-medium tracking-wider uppercase mb-1.5">
            Demo Tester Accounts
          </p>
          <div className="flex justify-center gap-4 text-[11px] text-slate-500 dark:text-slate-400">
            <div>
              <span className="font-semibold text-indigo-600 dark:text-indigo-400">User:</span> demo@user.com / demo123
            </div>
            <div>
              <span className="font-semibold text-emerald-600 dark:text-emerald-400">Admin:</span> admin@demo.com / admin123
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
