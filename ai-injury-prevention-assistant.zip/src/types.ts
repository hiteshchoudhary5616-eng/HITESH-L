// Shared TypeScript Types and Interfaces
// AI Injury Prevention Assistant

export type UserRole = 'user' | 'admin';

export interface User {
  UserID: number;
  Name: string;
  Email: string;
  Role: UserRole;
  CreatedAt?: string;
}

export interface FitnessProfile {
  ProfileID?: number;
  UserID: number;
  Age: number;
  Gender: string;
  Height: number; // in cm
  Weight: number; // in kg
  BMI: number;
  Experience: 'Beginner' | 'Intermediate' | 'Advanced';
  Goal: string;
}

export interface Exercise {
  ExerciseID: number;
  ExerciseName: string;
  MuscleGroup: string;
  Description: string;
  SafetyTips: string;
  Difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  Equipment: string;
  Alternatives?: string[];
}

export interface ExerciseAlternative {
  AlternativeID: number;
  ExerciseID: number;
  AlternativeExercise: string;
}

export interface WorkoutHistory {
  WorkoutID: number;
  UserID: number;
  Exercise: string;
  MuscleGroup: string;
  Weight: number;
  Sets: number;
  Reps: number;
  Duration: number; // in mins
  Difficulty: string; // e.g. Easy, Medium, Hard, Very Hard
  WorkoutDate: string; // YYYY-MM-DD
  Notes?: string;
}

export interface PainReport {
  PainID: number;
  UserID: number;
  BodyPart: string;
  Exercise: string;
  PainLevel: number; // 1-10
  PainType: string; // e.g. Sharp, Dull, Burning, Stiffness
  Duration: string; // e.g. '2 days', '1 week'
  Notes?: string;
  ReportDate: string; // YYYY-MM-DD
}

export interface AIRecommendation {
  RecommendationID: number;
  UserID: number;
  PainID: number | null;
  Recommendation: string;
  RiskLevel: 'Low' | 'Medium' | 'High';
  CreatedAt: string;
}

export interface RecoveryPlan {
  RecoveryID: number;
  UserID: number;
  Advice: string;
  RecoveryDays: number;
  Status: string;
}

export interface ChatMessage {
  ChatID: number;
  UserID: number;
  Question: string;
  Response: string;
  Timestamp: string;
}

export interface Notification {
  NotificationID: number;
  UserID: number | null; // null represents all users/announcements
  Title: string;
  Message: string;
  Status: 'unread' | 'read';
  IsAnnouncement: boolean;
  CreatedAt: string;
}

export interface PasswordReset {
  ResetID: number;
  UserID: number;
  OTP: string;
  Expiry: string;
}

export interface ActivityLog {
  LogID: number;
  UserID: number | null;
  Activity: string;
  Time: string;
}

export interface RiskAssessment {
  score: number;
  level: 'Low' | 'Medium' | 'High';
  factors: { factor: string; scoreContribution: number }[];
}

export interface DashboardPayload {
  user: User;
  profile: FitnessProfile | null;
  recentWorkouts: WorkoutHistory[];
  recentPainReports: PainReport[];
  riskAssessment: RiskAssessment;
  recentRecommendations: AIRecommendation[];
  unreadNotificationsCount: number;
  weeklyVolumeData: { day: string; volume: number }[];
  muscleDistributionData: { muscle: string; count: number }[];
  painTrendData: { date: string; level: number }[];
}
